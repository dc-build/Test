<?php

namespace App\Exceptions;

class ImageTypeNotFoundException extends \Exception
{
}