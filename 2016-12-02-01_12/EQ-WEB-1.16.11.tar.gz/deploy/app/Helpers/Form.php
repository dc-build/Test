<?php

namespace App\Helpers;

use Log;
use Illuminate\Http\Request;

/**
 * This helper provides helper functions for forms on the site.
 *
 * Class Form
 * @package App\Helpers
 */
class Form
{
    /**
     * @param Request $request
     * @param $fieldNameArray
     * @return array
     */
    public static function getFormData(Request $request, $fieldNameArray)
    {
        $formData = array();

        foreach ($fieldNameArray as $fieldName)
        {
            $formData[$fieldName] = $request->input($fieldName);
        }

        return $formData;
    }

    public static function booleanToString($boolean)
    {
        if (isset($boolean))
        {
            return $boolean ? "true" : "false";
        }
        else
        {
            return NULL;
        }
    }

    public static function stringToBoolean($string)
    {
        if (isset($string))
        {
            return $string == "true" ? true : false;
        }
        else
        {
            return NULL;
        }
    }
}