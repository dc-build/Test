<?php // Code within app\Helpers\Helper.php

function convert_date($date, $timezone = 'Australia/Sydney') {
    return \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $date)->setTimezone($timezone);
}

function set_active($path, $active = 'active')
{
    $currentPath = explode('/', request()->route()->uri());
    if (!is_array($path))
    {
        $path = explode('/', trim($path, '/'));
    }

    return
        $path === array_intersect($path, $currentPath) ||
        call_user_func_array('Route::is', (array) $path) ? $active : '';
}

function get_comp_func($comp)
{
    $comparators = [
        '>' => function($a, $b) { return $a > $b; },
        '<' => function($a, $b) { return $a < $b; },
        '>=' => function($a, $b) { return $a >= $b; },
        '<=' => function($a, $b) { return $a <= $b; },
        '===' => function($a, $b) { return $a === $b; },
        '!==' => function($a, $b) { return $a !== $b; }
    ];

    $func = isset($comparators[$comp]) ? $comparators[$comp] : $comp;
    if (!is_callable($func))
    {
        throw new App\Services\Exceptions\ComparisonNotPossibleException("Cannot execute the specified comparator: {$comp}.");
    }
    return $func;
}

function exists_attribute_with_value($data, $attrPattern, $value, $comp = '===')
{
    $compare = get_comp_func($comp);
    // are there any columns whose names match the $attrPattern and are match the value?
    return !empty(array_filter(
        array_map(
            function ($attr, $item) use ($attrPattern, $value, $compare)
            {
                $item = get_bool_string($item);
                $value = get_bool_string($value);
                // Is this attribute one we care about and does its value, compared with the expected return true?
                return preg_match($attrPattern, $attr) > 0 && $compare($item, $value);
            },
            array_keys($data),
            array_values($data)
        )
    ));
}

/**
 * Check if the $value is boolean and return a "boolean" string i.e. 'true' or 'false'.
 * Otherwise return the $value unchanged
 *
 * @param $value
 *
 * @return string
 */
function get_bool_string($value)
{
    if (is_bool($value))
    {
        return $value ? 'true' : 'false';
    }
    return $value;
}

