<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 13/10/2016
 * Time: 4:10 PM
 */

namespace App\Http\Controllers;

/***
 * Base Controller for admin stuff
 * Class AdminBaseController
 * @package App\Http\Controllers
 */
class AdminBaseController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin');
    }

}