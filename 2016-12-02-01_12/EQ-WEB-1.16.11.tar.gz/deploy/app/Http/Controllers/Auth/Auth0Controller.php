<?php 

namespace App\Http\Controllers\Auth;

use Auth0\Login\Contract\Auth0UserRepository;
use \Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\URL;

class Auth0Controller extends Controller {

    /**
     * @var Auth0UserRepository
     */
    protected $userRepository;

    public function __construct(Auth0UserRepository $userRepository) {
        $this->userRepository = $userRepository;
    }

    /**
     * Callback action that should be called by auth0, logs the user in
     */
    public function callback(Request $request) {
        //Get URL referrer
        if ($request->input('ref')) {
            $referrer = $request->input('ref');
        }
        else {
            $referrer = URL::previous();
        }
        if ($referrer == route('login')) {
            $referrer = route('home');
        }
        // Get a handle of the Auth0 service (we don't know if it has an alias)
        $service = \App::make('auth0');

        // Try to get the user information
        $profile = $service->getUser();
        
        //Prevent inactive users from logging in
        $user = User::where("email", $profile['profile']['email'])->where("isActive", false)->first();
        if ($user!==null) {
            \Auth::logout();
            return redirect()->back()->with('auth_error', 'Your account is inactive. Please contact your administrator.');
        }
        
        //Email Verification logic
        /*
        if ($profile['profile']['email_verified']==false) {
            \Auth::logout();
            return redirect()->back()->with('auth0_not_verified', 'Please check and verify your email before logging in.');
        }
        else {
            $user = User::where("email", $profile['profile']['email'])->where("isVerified", false)->first();
            if ($user!==null) {
                $user->isVerified = $profile['profile']['email_verified'];
                $user->save();
            }
        }
        */

        
        // Get the user related to the profile
        $auth0User = $this->userRepository->getUserByUserInfo($profile);

        if ($auth0User) {
            // If we have a user, we are going to log him in, but if
            // there is an onLogin defined we need to allow the Laravel developer
            // to implement the user as he wants an also let him store it.
            if ($service->hasOnLogin()) {
                $user = $service->callOnLogin($auth0User);
            } else {
                // If not, the user will be fine
                $user = $auth0User;
            }
            \Auth::login($user);
        }
        //dd($referrer);

        if ($user->role_id=="1") {
            //return redirect()->route('admin.home');
            return  \Redirect::to($referrer);
        }
        else {
            return  \Redirect::to($referrer);
        }
    }
    /**
     * Auth0 Login form
     */
    public function login() {
        $referrer = URL::previous();
        $referrer = str_replace(env('APP_URL'),'', $referrer);
        return view('auth.login', ['referrer' => $referrer]);
    }
}
