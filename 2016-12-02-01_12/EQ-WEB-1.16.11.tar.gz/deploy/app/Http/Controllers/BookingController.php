<?php


namespace App\Http\Controllers;

use App\Models\Popo\BookingDetail;
use App\Models\Space;
use App\Models\Spacebooking;
use App\Models\Building;
use App\Models\Host;
use App\Services\Exceptions\BookingContainsAtLeastOneExistingBookingException;
use App\Services\Exceptions\BookingException;
use App\Services\Exceptions\HourlyBookingContainsAtLeastOneBlacklistDateException;
use App\Services\IBookingEngineService;
use App\Services\IDateService;
use App\Services\IRateEngineService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Log\Writer;
use App\Repository\ISpacebookingRepository;
use Validator;

/**
 * Class BookingController
 * @package App\Http\Controllers
 */
class BookingController extends Controller
{
    protected $bookingService;
    protected $dateService;
    private $logger = null;
    private $spacebookingRepo;
    
    /**
     * 
     * @param IBookingEngineService $bookingService
     * @param IDateService $dateService
     * @param IRateEngineService $rateEngine
     */
    public function __construct(Writer $logger, ISpacebookingRepository $spacebookingRepo, IBookingEngineService $bookingService, IDateService $dateService, IRateEngineService $rateEngine)
    {
        $this->logger = $logger;
        $this->bookingService = $bookingService;
        $this->dateService = $dateService;
        $this->spacebookingRepo = $spacebookingRepo;
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(Request $request)
    {
        /**
         * Get space details
         */
        $this->logger->debug('Start show my bookings');

        $spaceBookings = collect($this->bookingService->getSpaceBookingsByUserId(Auth::user()->id));

        $spaceBookings->transform(function ($item) { //convert timezone
            $getDates = $this->convertDatesAndGetDetails($item->start_datetime, $item->end_datetime);
            foreach ($getDates as $key => $val) {
                $item->$key = $val;
            }
            $item->month = $getDates['month'];
            $item->sort = $getDates['sort'];
            return $item;
        });
        
        /*
         * Get events where End Date is greater than the current datetime (future events)
         */
        $spaceBookingsFilter = $spaceBookings->filter(function ($item) {
            return $item->dtstring_enddate >= $item->now;
        });
        
        /*
         * Get events where End Date is less than the current datetime (past events)
         */
        $spaceBookingsArchiveFilter = $spaceBookings->filter(function ($item) {
            return $item->dtstring_enddate <= $item->now;
        });

        $this->logger->debug('Spacebooking Transformed!');
        $spaceBookings = $spaceBookingsFilter->sortBy('sort');
        $spaceBookings = $spaceBookings->groupBy('month');
        $spaceBookings->toArray();
        
        $spaceBookingsArchive = $spaceBookingsArchiveFilter->sortBy('sort');
        $spaceBookingsArchive = $spaceBookingsArchive->groupBy('month');
        $spaceBookingsArchive->toArray();
        
        return view('bookings',['spacebookings' => $spaceBookings, 'spacebookingsarchive' => $spaceBookingsArchive]);
    }
    
    public function viewSpaceBookingDetails(Request $request, $building_slug, $id)
    {
        $spaceBooking = $this->bookingService->getSpaceBookingById($id);
        $space = Space::find($spaceBooking->space_id);
        
        $request->user()->can('showUser', $spaceBooking);
        
        $getDates = $this->convertDatesAndGetDetails($spaceBooking->start_datetime, $spaceBooking->end_datetime);
        foreach ($getDates as $key => $val) {
            $spaceBooking->$key = $val;
        }
        return view('bookings_view',['spacebookings' => $spaceBooking, 'space' => $space]);
    }
    
    public function editSpaceBookingDetails(Request $request, $building_slug, $id)
    {
        $spaceBooking = $this->bookingService->getSpaceBookingById($id);
        $space = Space::find($spaceBooking->space_id);
        
        $request->user()->can('showUser', $spaceBooking);
        
        $getDates = $this->convertDatesAndGetDetails($spaceBooking->start_datetime, $spaceBooking->end_datetime);
        foreach ($getDates as $key => $val) {
            $spaceBooking->$key = $val;
        }
        
        if ($request->isMethod('post')) {
            $getAllRequest = $request->except('_token');
            
            $this->logger->debug('Start Edit');          

            $this->logger->debug('Validate');
            $validator = Validator::make($getAllRequest, ['event_title' => 'required']);

            if ($validator->fails()) {
                return redirect()->back()->withErrors($validator)->withInput();
            }
            
            try {
                $saveSpaceBooking = Spacebooking::find($id);
                foreach ($getAllRequest as $key => $val) {
                    $saveSpaceBooking->$key = $val;
                }
                
                $this->logger->debug('Save to Space Booking Repo');
                $updatedSpacebooking = $this->spacebookingRepo->save($saveSpaceBooking);

                return redirect()->back()->with('success', 'Booking details have been updated.');
            }
            catch(\Exception $e) {
                return redirect()->back()->withErrors($e->getMessage())->withInput();
            }
        }
        else {
            return view('bookings_edit',['spacebookings' => $spaceBooking, 'space' => $space]);
        }
    }
    
    /**
     * 
     * @param Request $request
     * @param string $space_private_slug
     * @return mixed
     */
    public function postPaymentForm(Request $request, $building_private_slug, $space_private_slug)
    {
        $widgetSource = $request->input('widgetSource');
        $num_attendees = $request->input('num_attendees');
        $space_configuration = $request->input('space_configuration');
        $event_title = $request->input('event_title');
        $event_description = $request->input('event_description');
        $contact_name = $request->input('contact_name');
        $company_name = $request->input('company_name');
        $company_address = $request->input('company_address');
        $company_city = $request->input('company_city');
        $company_postcode = $request->input('company_postcode');
        $company_state = $request->input('company_state');
        $company_country = $request->input('company_country');
        $purchase_order = $request->input('purchase_order');
        $payment_type = $request->input('payment_type');
        $stripeToken = $request->input('stripeToken');
        
        $startDateTime = null;
        $endDateTime = null;
        
        if ($widgetSource=="hourly") {
            $this->logger->debug('Hourly Data');
            $validator = Validator::make($request->all(), Spacebooking::$BOOKING_HOURLY_VALIDATION_RULES);
            $date = $request->input('date');
            $time_from = $request->input('time_from');
            $time_to = $request->input('time_to');
            $startTime = $date." ".$time_from.":00";
            $endTime = $date." ".$time_to.":00";
            $startDateTime = Carbon::createFromFormat('Y-m-d H:i:s', $startTime, 'Australia/Sydney');
            $endDateTime = Carbon::createFromFormat('Y-m-d H:i:s', $endTime, 'Australia/Sydney');
        }
        elseif ($widgetSource=="daily") {
            $this->logger->debug('Daily Data');
            $validator = Validator::make($request->all(), Spacebooking::$BOOKING_DAILY_VALIDATION_RULES);
            $date_from = $request->input('date_from');
            $date_to = $request->input('date_to');
            $startDateTime = Carbon::createFromFormat('Y-m-d', $date_from, 'Australia/Sydney');
            $endDateTime = Carbon::createFromFormat('Y-m-d', $date_to, 'Australia/Sydney');
        }
        
        /**
         * Get space details
         */
        $this->logger->debug('Get Space Details');
        $space = Space::active()->where('private_slug', $space_private_slug)
                ->with('capacityprices')
                ->with('building')
                ->with('host')
                ->with('spaceconfigurations')
                ->get()
                ->first();
        
        $host = Host::find($space->host->id);
        
        $this->logger->debug('Create Booking Detail');
        $bookingDetail = new BookingDetail();
        $bookingDetail->event_title = $event_title;
        $bookingDetail->event_description = $event_description;
        
        /**
         * Add company details request for invoice type
         */
        if ($payment_type=="INVOICE") {
            $bookingDetail->contact_name = $contact_name;
            $bookingDetail->company_name = $company_name;
            $bookingDetail->company_address = $company_address;
            $bookingDetail->company_city = $company_city;
            $bookingDetail->company_postcode = $company_postcode;
            $bookingDetail->company_state = $company_state;
            $bookingDetail->company_country = $company_country;
            $bookingDetail->purchase_order = $purchase_order;
            
            $validator_payment = Validator::make($request->all(), Spacebooking::$BOOKING_INVOICE_VALIDATION_RULES);
        }
        elseif ($payment_type=="CREDITCARD") {
            $validator_payment = Validator::make($request->all(), Spacebooking::$BOOKING_CREDITCARD_VALIDATION_RULES);
        }

        $processBooking = null;
        try {
            if ($validator->passes() && $validator_payment->passes())
            {
                $bookingRequest = null;
                if ($widgetSource=="hourly") {
                    $this->logger->debug('Call Booking Engine Hourly');
                    $bookingRequest = $this->bookingService->bookSpaceByHourly($space, $bookingDetail, $num_attendees, $startDateTime, $endDateTime, Auth::user()->id, $payment_type, $space_configuration, $stripeToken, $host);
                }
                elseif ($widgetSource=="daily") {
                    $this->logger->debug('Call Booking Engine Daily');
                    $bookingRequest = $this->bookingService->bookSpaceByDaily($space, $bookingDetail, $num_attendees, $startDateTime, $endDateTime, Auth::user()->id, $payment_type, $space_configuration, $stripeToken, $host);
                }
                $data['details'] = $bookingRequest;
                $data['status'] = "success";
                $this->logger->debug('End Booking Engine');
                
                ////send notification emails
            }
            else {
                $response = [
                    'status' => 'error',
                    'message' => ($validator->messages()->toArray()) ? $validator->messages()->toArray() : $validator_payment->messages()->toArray()
                ];
                return response()->json($response);
            }
        }
        catch (BookingContainsAtLeastOneExistingBookingException $bbe)
        {
            throw $bbe;
        }
        catch(HourlyBookingContainsAtLeastOneBlacklistDateException $hbc) {
            throw $hbc;
        }
        catch(BookingException $be) {
            throw $be;
        }
        catch(\Exception $e) {
            throw $e;
        }
        return response()->json($data);
    }
    
    public function validateBookingHourly(Request $request, $id)
    {
        //Convert to Carbon format
        $startDateTime = Carbon::createFromFormat('Y-m-d H:i:s', $request->input('time_from'), 'Australia/Sydney');
        $endDateTime = Carbon::createFromFormat('Y-m-d H:i:s', $request->input('time_to'), 'Australia/Sydney');
        
        //Get request details
        $num_attendees = $request->input('num_attendees');
        $space = Space::find($id);
        
        $bookingDetail = new BookingDetail();
        $bookingDetail->event_title = "";
        $bookingDetail->event_description = "";
        
        try {
            // Call bookingEngine for everything, including rates
            $bookingRequest = $this->bookingService->bookSpaceByHourly($space, $bookingDetail, $num_attendees, $startDateTime, $endDateTime);
            $rateDetail = $bookingRequest->getBookingRateDetail();

            $data['hourlyTotalCost'] = number_format($rateDetail->hourlyTotalCost(),2);
            $data['halfDayTotalCost'] = number_format($rateDetail->halfDayTotalCost(),2);
            $data['dayTotalCost'] = number_format($rateDetail->dayTotalCost(),2);
            $data['monthTotalCost'] = number_format($rateDetail->monthTotalCost(),2);
            $data['afterHoursTotalCost'] = number_format($rateDetail->afterHoursTotalCost(),2);
            $data['totalCost'] = number_format($rateDetail->totalCost(),2);
            $data['totalHours'] = $rateDetail->totalHours();
            $data['totalAfterHoursHours'] = $rateDetail->totalAfterHoursHours();
        }
        catch(HourlyBookingContainsAtLeastOneBlacklistDateException $bl_e) {
            $data['error'] = $bl_e->getMessage();
            $data['blacklistdates'] = collect($bl_e->getBlacklistDates());
            $data['blacklistdates']->transform(function ($item) { //convert timezone
                $item['start_datetime'] = $this->dateService->convertDateToTimezone($item['start_datetime']);
                $item['end_datetime'] = $this->dateService->convertDateToTimezone($item['end_datetime']);
                return $item;
            });
        }
        catch(BookingException $be) {
            throw $be;
        }
        catch(\Exception $e) {
            throw $e;
        }
        return response()->json($data); 
    }
    
    /*
     * Get daily space rates
     * 
     * @param  \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function validateBookingDaily(Request $request, $id)
    {
        //Convert to Carbon format
        $startDateTime = Carbon::createFromFormat('Y-m-d', $request->input('date_from'));
        $endDateTime = Carbon::createFromFormat('Y-m-d', $request->input('date_to'));
        
        //Get request details
        $num_attendees = $request->input('num_attendees');
        $space = Space::find($id);
        
        $bookingDetail = new BookingDetail();
        $bookingDetail->event_title = "";
        $bookingDetail->event_description = "";
        
        try {
            // Call bookingEngine for everything, including rates
            $bookingRequest = $this->bookingService->bookSpaceByDaily($space, $bookingDetail, $num_attendees, $startDateTime, $endDateTime);
            $rateDetail = $bookingRequest->getBookingRateDetail();
            $data['dayTotalCost'] = number_format($rateDetail->dayTotalCost(),2);
            $data['monthTotalCost'] = number_format($rateDetail->monthTotalCost(),2);
            $data['totalCost'] = number_format($rateDetail->totalCost(),2);
            $data['totalDays'] = $rateDetail->totalDays();
            $data['totalMonths'] = $rateDetail->totalMonths();
        }
        catch(BookingException $be) {
            throw $be;
        }
        catch(\Exception $e) {
            throw $e;
        }
        return response()->json($data); 
    }
    
    public function convertDatesAndGetDetails($startdate, $endDate) 
    {
        $this->logger->debug('Convert dates and get more details');
        $item_startDateTime = Carbon::createFromFormat("Y-m-d H:i:s", $this->dateService->convertDateToTimezone($startdate));
        $item_endDateTime = Carbon::createFromFormat("Y-m-d H:i:s", $this->dateService->convertDateToTimezone($endDate));
        $item_startDate = $item_startDateTime->format('F j, Y');
        $item_endDate = $item_endDateTime->format('F j, Y');
        if ($item_startDate == $item_endDate) { //hourly
            $item['widgetSource'] = "hourly";
            $item['date'] = $item_startDate;
            $item['start_time'] = $item_startDateTime->format('g:i a');
            $item['end_time'] = $item_endDateTime->format('g:i a');
        }
        else { //daily
            $item['widgetSource'] = "daily";
            $item['start_datetime'] = $item_startDateTime->format('j F Y');
            $item['end_datetime'] = $item_endDateTime->format('j F Y');
            $item['start_time'] = $item_startDateTime->format('g:i a');
            $item['end_time'] = $item_endDateTime->format('g:i a');
        }
        $item['month'] = $item_startDateTime->format('F Y');
        $item['sort'] = $item_startDateTime->format('Ymd');
        $item['dtstring_startdate'] = $item_startDateTime->format('YmdHis');
        $item['dtstring_enddate'] = $item_endDateTime->format('YmdHis');
        $item['now'] = Carbon::now('Australia/Sydney')->format('YmdHis');
        return $item;
    }
    
    public function getBuildingDetails($building_id)
    {
        $building = Building::where('id', $building_id)->with('locality')->with('region')->with('country')->first();
        return $building;
    }
    
    public function getSpaceBookingDetails($id=null, $spaces=null)
    {
        $spaceBookingDetails = Spacebooking::with('spaces')->with('thumbImage')->with('transaction')->where('payment_received', true)->where('booked_by_id', Auth::user()->id);
        if ($spaces) {
            $spaceBookingDetails = $spaceBookingDetails->whereIn('space_id', $spaces);
        }
        else {
            $spaceBookingDetails = $spaceBookingDetails->where('id', $id);
        }
        $spaceBookingDetails = $spaceBookingDetails->get();
        return $spaceBookingDetails;
    }
}