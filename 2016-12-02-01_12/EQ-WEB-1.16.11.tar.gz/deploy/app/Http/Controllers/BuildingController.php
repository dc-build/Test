<?php

namespace App\Http\Controllers;

use App\Models\Host;
use App\Services\IAuthorisedModelAccessService;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Models\Building;
use App\Models\Locality;
use App\Models\Region;
use App\Models\Country;
use App\Models\Image;
use Validator;
use Illuminate\Support\Facades\File;
use App\Services\IImageService;
use App\Services\IUuidService;


class BuildingController extends AdminBaseController
{
    protected $imageService;
    protected $uuidService;
    
    public function __construct(IImageService $imageService, IUuidService $uuidService)
    {
        parent::__construct();
        $this->imageService = $imageService;
        $this->uuidService = $uuidService;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize($this);
        $buildings = Building::with('country')
            ->with('region')
            ->with('locality')
            ->with('logoImage')
            ->with('headerImage')
            ->with('createdby')
            ->with('updatedby')
            ->get();
        $buildings->transform(function ($item) { 
            $item['other_services'] = str_limit(strip_tags($item['other_services']), 100);
            $item['direct_url'] = url('buildings', $item->private_slug);
            return $item;
        });

        return response()->json(['data' => $buildings]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);
        $data = Building::getInputValues($request);
        
        $logo_file = $data['logo_image'];
        $header_file = $data['header_image'];
        
        $validator = Validator::make($data, Building::$BUILDING_VALIDATION_RULES);
        
        if ($validator->fails())
        {
            $response = array(
                'status' => 'error',
                'message' => $validator->messages()->toArray(),
                'statuscode' => "402"
            );
            return response()->json($response);
        }
        
        try {
            $path = base_path('public/images/uploads/');
            
            if(!File::exists($path)) {
                 $this->createUploadDirectories($path); 
            }
            $data["private_slug"] = $this->uuidService->generateUUID();
            $building = Building::create($data);

            $hostIds = ($request->input('hosts') == null) ? [] : $request->input('hosts');
            $building->hosts()->sync($hostIds);
            
            if($logo_file) {
                $additional_fields["caption"] = NULL;
                $image_id = $this->imageService->uploadImage($logo_file, $additional_fields, $path, New Image);
                if ($image_id) {
                    $this->upsertBuildingImagePivot($building->id, $image_id, '1');
                }
            }

            if($header_file) {
                $additional_fields["caption"] = NULL;
                $image_id = $this->imageService->uploadImage($header_file, $additional_fields, $path, New Image);
                if ($image_id) {
                    $this->upsertBuildingImagePivot($building->id, $image_id, '2');
                }
            }
            
            $response = array(
                'status' => 'success',
                'message' => 'Building has been added',
                'statuscode' => "200"
            );
        }
        catch(\Exception $e) {
            $response = array(
                'status' => 'error',
                'message' => $e->getMessage(),
                'statuscode' => "400"
            );
        }
        return $response;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        $buildings = Building::where('id',$id)->with('country')->with('region')->with('locality')->with('logoImage')->with('headerImage')->with(array('hosts'=>function($query){
            $query->select('hosts.id','hosts.company_name');
        }))->first();
        return response()->json($buildings);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);
        $data = Building::getInputValues($request);
        
        $logo_file = $data['logo_image'];
        $header_file = $data['header_image'];

        $validator = Validator::make($data, Building::$BUILDING_VALIDATION_RULES);

        $building = Building::find($id);

        try {
            if ($validator->passes())
            {
                $path = base_path('public/images/uploads/');

                if($logo_file) {
                    $additional_fields["caption"] = NULL;
                    $image_id = $this->imageService->uploadImage($logo_file, $additional_fields, $path, New Image);
                    if ($image_id) {
                        $this->upsertBuildingImagePivot($id, $image_id, '1');
                    }
                }

                if($header_file) {
                    $additional_fields["caption"] = NULL;
                    $image_id = $this->imageService->uploadImage($header_file, $additional_fields, $path, New Image);
                    if ($image_id) {
                        $this->upsertBuildingImagePivot($id, $image_id, '2');
                    }
                }

                $building->update($data);

                $hostIds = ($request->input('hosts') == null) ? [] : $request->input('hosts');
                $building->hosts()->sync($hostIds);
                
                $response = [
                    'status' => 'success',
                    'message' => 'Building details has been updated.'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch(\Exception $e) {
            return response()->json(
            [
                'status' => 'error',
                'message' => 'Unable to create Building. Please try again.'
            ], 400);
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        $building = Building::find($id);
        try {
            $building = Building::find($id);
            $building_image = Building::LeftJoinBuildingImage($id)->get();
            if (!is_null($building_image)) {
                $building->images()->detach();
            }
            $building->delete();
            
            $response = array(
                'status' => 'success',
                'message' => 'Building has been deleted',
                'statuscode' => "200"
            );
        }
        catch(\Exception $e) {
            
            if ($e->getCode()) {
                $message = 'There are other tables associated with this Building. Please delete these associations and try again';
            }
            else {
                $message = 'Building not found!';
            }
            
            $response = array(
                'status' => 'error',
                'message' => $message,
                'statuscode' => "400"
            );
        }
        return response()->json($response);
    }

    /**
     * Get request to the building listing page
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function buildings(Request $request)
    {
        $this->authorize($this);
        $localities = Locality::all();
        $regions = Region::all();
        $countries = Country::all();

        $hosts = Host::lists('company_name', 'id')->all();
        return view('admin.buildings',['localities' => $localities, 'regions' => $regions, 'countries' => $countries, 'hosts' => $hosts]);
    }

    /**
     * List of buildings for use in dropdowns and similar things
     * @param \Illuminate\Http\Request $request
     */
    public function apiList(Request $request)
    {
        $this->authorize($this);

        $user = $request->user();

        $buildings = Building::getAllAuthorised($user)->get();

        return response()->json($buildings->toArray());
    }
    
    protected function upsertBuildingImagePivot($id, $image_id, $imagetype) 
    {
        $building = Building::find($id);
        $building_image = Building::LeftJoinBuildingImageWithImageType($id,$imagetype)->first();

        if (!is_null($building_image)) {
             $building->images()->detach($building_image->image_id);
        }

        $building->images()->attach($image_id, ['imagetype_id' => $imagetype]);
    }
}
