<?php

namespace App\Http\Controllers;

use App\Models\Blacklistdate;
use App\Models\Whitelistdate;
use App\Models\Spacebooking;
use App\Models\Space;
use Illuminate\Http\Request;
use App\Services\IDateService;
use App\Services\IBookingEngineService;
use Carbon\Carbon;

class CalendarController extends AdminBaseController
{
    protected $dateService;
    protected $bookingService;
    
    public function __construct(IBookingEngineService $bookingService, IDateService $dateService)
    {
        parent::__construct();
        $this->dateService = $dateService;
        $this->bookingService = $bookingService;
    }

    /**
     * Display all calendar dates (Space Booking, Blacklist, Whitelist)
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $this->authorize($this);
        $dates = $this->getCalendars($request->user());
        return response()->json($dates);
    }
    
    /**
     * Display all calendar dates by space (Space Booking, Blacklist, Whitelist)
     *
     * @param  int $space_id
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function getDatesBySpace(Request $request, $space_id)
    {
        $this->authorize($this);
        $dates = $this->getCalendars($request->user(), $space_id);
        return response()->json($dates);
    }
    
    /**
     * Get calendar details
     *
     * @param int $space_id
     * @return this
     */
    public function getCalendars($user, $space_id = null)
    {
        $this->authorize($this);
    
        //get blacklist dates
        $black = $this->getBlacklistDetails($user, $space_id);
        
        //get whitelist dates
        $white = $this->getWhitelistDetails($user, $space_id);
        
        //get space bookings dates
        $spacebooking = $this->getSpaceBookingDetails($user, $space_id);
        
        //merge everything into one json
        $dates = array_merge($black->toArray(), $white->toArray(), $spacebooking->toArray());
        return $dates;
    }
    
    /**
     * Display all calendar space booking dates by space
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function getSpaceBookingDates(Request $request)
    {
        $this->authorize($this);
        $space_id = null;
        $spacebooking = $this->getSpaceBookingDetails($request->user(), $space_id);
        return response()->json($spacebooking);
    }
    
    /**
     * Display all calendar space booking dates by space
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $space_id
     * @return \Illuminate\Http\Response
     */
    public function getSpaceBookingDatesBySpace(Request $request, $space_id)
    {
        $this->authorize($this);
        $spacebooking = $this->getSpaceBookingDetails($request->user(), $space_id);
        return response()->json($spacebooking);
    }
    
    /**
     * Display all calendar blacklist dates
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function getBlacklistDates(Request $request)
    {
        $this->authorize($this);
        $space_id = null;
        $dates = $this->getBlacklistDetails($request->user(), $space_id);
        return response()->json($dates);
    }
    
    /**
     * Display all calendar blacklist dates by space
     * 
     * @param  \Illuminate\Http\Request $request
     * @param  int $space_id
     * @return \Illuminate\Http\Response
     */
    public function getBlacklistDatesBySpace(Request $request, $space_id)
    {
        $this->authorize($this);
        $dates = $this->getBlacklistDetails($request->user(), $space_id);
        return response()->json($dates);
    }
    
    /**
     * Display all calendar whitelist dates
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function getWhitelistDates(Request $request)
    {
        $this->authorize($this);
        $space_id = null;
        $dates = $this->getWhitelistDetails($request->user(), $space_id);
        return response()->json($dates);
    }
    
    /**
     * Display all calendar whitelist dates by space
     * 
     * @param  \Illuminate\Http\Request $request
     * @param  int $space_id
     * @return \Illuminate\Http\Response
     */
    public function getWhitelistDatesBySpace(Request $request, $space_id)
    {
        $this->authorize($this);
        $dates = $this->getWhitelistDetails($request->user(), $space_id);
        return response()->json($dates);
    }
    
    /**
     * Get whitelist dates
     * 
     * @param type $user
     * @param type $space_id
     * @return type
     */
    public function getBlacklistDetails($user, $space_id) {
        $black = Blacklistdate::getAllAuthorised($user, array("blacklistdates.id","blacklistdates.name AS title","blacklistdates.start_datetime AS start","blacklistdates.end_datetime AS end"));
        if ($space_id) {
            $black = $black->where('space_id',$space_id);
        }
        $black = $black->get();

        $black->transform(function ($item) { //convert timezone
            $item['start'] = $this->dateService->convertDateToTimezone($item['start']);
            $item['end'] = $this->dateService->convertDateToTimezone($item['end']);
            return $item;
        });
        $black->map(function ($item) { //add additional data to collection using fullcalendar event source data
            $item['backgroundColor'] = '#000000';
            $item["textColor"] = '#ffffff';
            $item["title"] = "[Blacklist] ".$item["title"];
            return $item;
        });
        return $black;
    }
    
    /**
     * Get blacklist dates
     * 
     * @param type $user
     * @param type $space_id
     * @return type
     */
    public function getWhitelistDetails($user, $space_id) {
        $white = Whitelistdate::getAllAuthorised($user, array("whitelistdates.id","whitelistdates.name AS title","whitelistdates.start_datetime AS start","whitelistdates.end_datetime AS end"));
        if ($space_id) {
            $white = $white->where('space_id',$space_id);
        }
        $white = $white->get();
        $white->transform(function ($item) { //convert timezone
            $item['start'] = $this->dateService->convertDateToTimezone($item['start']);
            $item['end'] = $this->dateService->convertDateToTimezone($item['end']);
            return $item;
        });
        $white->map(function ($item) { //add additional data to collection using fullcalendar event source data
            $item['backgroundColor'] = '#dddddd';
            $item["textColor"] = '#000000';
            $item["title"] = "[Whitelist] ".$item["title"];
            return $item;
        });
        return $white;
    }
    
    /**
     * Get space booking dates
     * 
     * @param type $user
     * @param type $space_id
     * @return type
     */
    public function getSpaceBookingDetails($user, $space_id) {

        $booking = Spacebooking::getAllAuthorised($user, array("spacebookings.id","spacebookings.event_title AS title","spacebookings.start_datetime AS start","spacebookings.end_datetime AS end","spacebookings.booked_by_id AS bookedById","space_id"));
        if ($space_id) {
            $booking = $booking->where('space_id',$space_id);
        }
        $booking = $booking->get();
        
        $booking->transform(function ($item) { 
            $item['start'] = $this->dateService->convertDateToTimezone($item['start']);
            if ($item['end']) {
                $item['end'] = $this->dateService->convertDateToTimezone($item['end']);
            }
            return $item;
        });

        $booking->map(function ($item) { 
            $item['backgroundColor'] = '#3c8dbc';
            $item["textColor"] = '#ffffff';
            $item["title"] = "[Booking] ".$item["title"];
            
            if ($item['end']) {
                $item['allDay'] = false;
                
                //Add prep time
                $space = Space::find($item["space_id"]);
                
                $preptimebefore = $space->prep_time_before;
                $preptimeafter = $space->prep_time_after;
                
                $newStartTime = New Carbon($item['start']);
                $newEndTime = New Carbon($item['end']);
                $item['start'] = $newStartTime->subMinutes($preptimebefore)->toDateTimeString();
                $item['end'] = $newEndTime->addMinutes($preptimeafter)->toDateTimeString();
                
                $startDateTime = New Carbon($item['start']);
                $startDate = $startDateTime->toDateString();
                $endDateTime = New Carbon($item['end']);
                $endDate = $endDateTime->toDateString();
                
                if($startDate != $endDate) {
                    $item['allDay'] = true;
                }
            }
            else {
                $item['allDay'] = true;
                $item["title"] = "[All Day] ".$item["title"];
            }
            return $item;
        });
        
        return $booking;
    }
    
    /**
     * Calendar view
     * 
     * @param  \Illuminate\Http\Request $request
     * @return mixed
     */
    public function calendar(Request $request)
    {
        $this->authorize($this);
        $spaces = Space::getAllAuthorised($request->user())->get();

        return view('admin.calendar',['spaces' => $spaces]);
    }
}