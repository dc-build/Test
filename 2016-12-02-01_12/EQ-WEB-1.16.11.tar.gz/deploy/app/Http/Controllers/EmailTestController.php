<?php

namespace App\Http\Controllers;

use App\Models\Spacebooking;
use App\Models\User;
use Illuminate\Http\Request;
use Mail;


class EmailTestController extends AdminBaseController
{

    protected $data;
    protected $template = 'emails.booking.security-refund';
    protected $subject = 'New booking';

    public function __construct()
    {
        parent::__construct();

        $this->data =
            [
                'logo_url' => asset('images/building/logo.png'),
                'booking' => Spacebooking::with('spaces')
                                         ->with('spaces.building')
                                         ->with('spaces.host')
                                         ->with('users')
                                         ->with('transaction')
                                         ->find(1),
                'subject' => $this->subject,
                'message' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce eget dui non diam dignissim pretium sit amet non massa. Phasellus aliquet enim non augue laoreet ultrices. Etiam fringilla aliquet ullamcorper. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ultricies gravida tincidunt. Sed sodales aliquet nulla, ut pharetra elit mollis et. Donec lorem eros, vestibulum non lacus ac, pharetra consectetur neque.'
            ];
    }
    
    /**
     * Send a test email
     *
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request)
    {
        return view($this->template, $this->data);
    }


    public function send(Request $request)
    {

        $user = User::find(1);

        Mail::send($this->template, $this->data, function ($m) use ($user) {
            $m->from('hello@app.com', $this->data['booking']->spaces->host->contact_name);

            $m->to('john.c.quintal@digitalcarpenter.com.au', $user->name)->subject($this->subject);
        });
        return response()->json(['data' => 'Done']);
    }
}
