<?php


namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class HomeController extends Controller
{
    public function __construct()
    {

    }

    public function index(Request $request)
    {
        return view('home-blank');
    }
    
    public function detail(Request $request)
    {
        return view('detail');
    }
    
    public function payment(Request $request)
    {
        return view('payment');
    }
    
    public function bookings(Request $request)
    {
        return view('bookings');
    }
}