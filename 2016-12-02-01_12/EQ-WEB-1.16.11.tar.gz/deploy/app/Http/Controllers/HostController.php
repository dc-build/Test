<?php

namespace App\Http\Controllers;

use App\Models\Creditcard;
use App\Models\Host;
use App\Models\User;
use App\Services\Exceptions\CreditCardCreationFailedException;
use App\Services\Exceptions\CreditCardDeletionFailedException;
use App\Services\IAuthorisedModelAccessService;
use App\Services\IPaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class HostController extends AdminBaseController
{

    protected $paymentService;

    public function __construct(IPaymentService $paymentService)
    {
        parent::__construct();
        $this->paymentService = $paymentService;
        $this->paymentService->init();
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $this->authorize($this);
        $user = $request->user();

        $hosts = Host::getAllAuthorised($user)->with('country')->with('region')->with('locality')->get();

        return response()->json(['data' => $hosts]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Host::$VALIDATION_RULES, Host::$VALIDATION_MESSAGES);

        try
        {
            if ($validator->passes())
            {
                $host = Host::create($request->all());

                $hostAdminIds = ($request->input('hostadmins') == null) ? [] : $request->input('hostadmins');
                $host->hostadmins()->sync($hostAdminIds);

                $this->handleCreditcardData($request->all(), $host);

                $response = [
                    'status' => 'success',
                    'message' => 'Host has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            \Debugbar::addMessage($e);
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create Host. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $this->authorize($this);
        try
        {
            //get the host with it's related buildings and hostadmins
            $host = Host::with('country')->with('region')->with('locality')->with('logoImage')->with('profileImage')->with('creditcard')
                    ->with(array('buildings'=>function($query){$query->select('buildings.id','buildings.name');}))
                    ->with(array('hostadmins' => function($query) use ($id)
                            {
                                $query->with(array('buildings' => function($query) use ($id)
                                {
                                    $query->where('building_user.host_id', $id)->select('buildings.id','buildings.name');
                                }))->select('users.id','users.email');
                            }))->findOrFail($id);

            //check that the user has permission to see this specific host
            $this->authorize($host);

            // Create an array to store which buildings the hosts admins are in
            $buildingAdmins = $host->buildings->keyBy('id')->each(function ($item, $key) {
                //create an array to hold the admins and remove the pivot
                $item->admins = [];
                array_except($item, ['pivot']);
            })->toArray();

            //loop over all the hostadmins and assign them to any buildings they belong to
            foreach($host->hostadmins as $hostadmin)
            {
                foreach($hostadmin->buildings as $building)
                {
                    array_push($buildingAdmins[$building->id]['admins'], $building->pivot->user_id);
                }
            }

            $host->buildingadmins = $buildingAdmins;
            return response()->json($host);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Host not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Host::$VALIDATION_RULES, Host::$VALIDATION_MESSAGES);

        try
        {
            $host = Host::with('buildings')->with('hostadmins')->findOrFail($id);

            //check that the user has permission to see this specific host
            $this->authorize($host);

            if ($validator->passes())
            {
                //update the standard data
                $host->update($request->all());

                //Get the hostbuildingadmin data
                $hostAdminData = $request->input('hostadmindata');
                $hostBuildingAdmins = json_decode($hostAdminData);

                if($hostBuildingAdmins->changed == true)
                {
                    //Key the admins and buildings so we can easily access them in the loop below
                    $hostAdminsById = $host->hostadmins->keyBy('id');
                    $hostBuildingsById = $host->buildings->keyBy('id');
                    foreach($hostBuildingAdmins->data as $buildingAdmin)
                    {
                        //create the values to sync
                        $syncValues = [];
                        foreach($buildingAdmin->admins as $admin)
                        {
                            //we are linking up the ID's of the pivot tables that link the building and user to this host
                            $syncValues[$admin] = ['user_id' => $admin, 'host_user_id' => $hostAdminsById[$admin]->pivot->id, 'building_host_id' => $hostBuildingsById[$buildingAdmin->id]->pivot->id, 'host_id' => $host->id];
                        }
                        //do the sync
                        $hostBuildingsById[$buildingAdmin->id]->hostadmins($host->id)->sync($syncValues);
                    }
                }

                //Only admins can add or delete host admins
                if($request->user()->can('assignHostAdmin', $this))
                {
                    $hostAdminIds = ($request->input('hostadmins') == null) ? [] : $request->input('hostadmins');
                    $host->hostadmins()->sync($hostAdminIds);
                }

                $this->handleCreditcardData($request->all(), $host);

                $response = [
                    'status' => 'success',
                    'message' => 'Host has been updated'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Host not saved! ' . $e->getMessage()
                ], 404);
        }
        return response()->json($response);
    }

    private function handleCreditcardData($cardData, Host $host)
    {
        // We are posting credit card details
        if(in_array('creditcard_id', array_keys($cardData)) && in_array('delete_card', array_keys($cardData)))
        {
            if ($cardData['delete_card'] === 'true')
            {
                try
                {
                    $host->update(['creditcard_id' => null]);
                    $creditcard = Creditcard::find($cardData['creditcard_id']);
                    $this->paymentService->deleteCreditCard($creditcard->gateway_customer_id, $creditcard->gateway_card_id);
                    $creditcard->delete();
                }
                catch (CreditCardDeletionFailedException $e)
                {
                    throw $e;
                }
            }
        }

        if(in_array('card_name', array_keys($cardData)))
        {

            try
            {
                $gatewayResponse = $this->paymentService->createCreditCard(
                    [
                        'name'          => $cardData['name_on_card'],
                        'number'        => $cardData['card_number'],
                        'expiryMonth'   => $cardData['expiry_month'],
                        'expiryYear'    => $cardData['expiry_year'],
                        'cvv'           => $cardData['cvv']
                    ]
                );
                $cardData['gateway_customer_id'] = $gatewayResponse['id'];
                $cardData['gateway_card_id'] = $gatewayResponse['default_source'];

                $cardValidator = Validator::make($cardData, Creditcard::$VALIDATION_RULES, Creditcard::$VALIDATION_MESSAGES);

                if ($cardValidator->passes())
                {
                    $cardData['last_four'] = substr(trim($cardData['card_number']), -4, 4);
                    $creditcard = Creditcard::create($cardData);
                    $host->update(['creditcard_id' => $creditcard->id]);
                }
            }
            catch (CreditCardCreationFailedException $e)
            {
                throw $e;
            }

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try
        {
            $host = Host::findOrFail($id);

            //check that the user has permission to deletethis specific host
            $this->authorize($host);

            $deleted = $host->delete();
            $message = $deleted ? 'Host has been successfully deleted' : 'There was an error attempting to delete the Host';
            return response()->json(
                [
                    'status' => $deleted ? 'success' : 'error',
                    'message' => $message
                ]);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Host not found!'
                ], 404);
        }
    }

    /**
     * List of hosts for use in dropdowns and similar things
     * @param \Illuminate\Http\Request $request
     */
    public function apiList(Request $request, $building_id)
    {
        $this->authorize($this);
        $user = $request->user();
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            $hosts = Host::getAllAuthorised($user)->with('country')->with('region')->with('locality')
                ->join('building_host', 'building_host.host_id', '=', 'hosts.id')->where('building_host.building_id', $building_id)
                ->get();
        }
        else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
        {
            $hosts = Host::getAllAuthorised($user)->with('country')->with('region')->with('locality')
                ->join('building_user', 'host_user.id', '=', 'building_user.host_user_id')->where('building_user.building_id', $building_id)
                ->get();
        }


        return response()->json($hosts->toArray());
    }

    public function hosts(Request $request)
    {
        $this->authorize($this);

        $hostadmins = User::where('role_id', User::$ACCOUNT_ROLE_HOST )->select(\DB::raw("CONCAT(first_name, ' ', last_name, ' (', email, ')') as value, id"))->lists('value', 'id')->all();

        return view('admin.hosts',['hostadmins' => $hostadmins]);
    }
}
