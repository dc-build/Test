<?php

namespace App\Http\Controllers;

use App\Models\Imagetype;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ImagetypeController extends AdminBaseController
{
    public function __construct()
    {
        parent::__construct();
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize($this);
        $imagetypes = Imagetype::all();
        return response()->json(['data' => $imagetypes]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Imagetype::$VALIDATION_RULES, Imagetype::$VALIDATION_MESSAGES);
        
        try
        {
            if ($validator->passes())
            {
                Imagetype::create($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Image Type has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create Image Type. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        try
        {
            $imagetypes = Imagetype::findOrFail($id);
            return response()->json($imagetypes);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Image Type not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Imagetype::$VALIDATION_RULES, Imagetype::$VALIDATION_MESSAGES);

        try
        {
            $imagetypes = Imagetype::findOrFail($id);
            if ($validator->passes())
            {
                $imagetypes->update($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Image Type has been updated'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Image Type not found!'
                ], 404);
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try {
            $imagetypes = Imagetype::findOrFail($id);
            $imagetypes->delete();
            $message = 'Image Type has been successfully deleted';
            
            return response()->json(
                [
                    'status' => 'success',
                    'message' => $message
                ]);
        }
        catch (\Exception $e)
        {
            if ($e->getCode()) {
                $message = 'There are images associated with this Image Type. Please delete these images and try again';
            }
            else {
                $message = 'Image Type not found!';
            }
            
            return response()->json(
                [
                    'status' => 'error',
                    'message' => $message
                ], 404);
        }
    }

    public function imagetypes(Request $request)
    {
        $this->authorize($this);
        return view('admin.imagetypes');
    }
}