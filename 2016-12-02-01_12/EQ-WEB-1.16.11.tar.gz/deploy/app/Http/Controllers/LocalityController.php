<?php

namespace App\Http\Controllers;

use App\Models\Locality;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class LocalityController extends AdminBaseController
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $localities = Locality::with('region')
            ->with('region.country')
            ->with('createdby')
            ->with('updatedby')
            ->get();
        return response()->json(['data' => $localities]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);
        $validator = Validator::make($request->all(), Locality::$LOCALITY_VALIDATION_RULES);

        try
        {
            if ($validator->passes())
            {
                Locality::create($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Locality has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create Locality. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        try
        {
            $locality = Locality::with('region')->with('region.country')->findOrFail($id);
            return response()->json($locality);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Locality not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);
        $validator = Validator::make($request->all(), Locality::$LOCALITY_VALIDATION_RULES);

        try
        {
            $host = Locality::findOrFail($id);
            if ($validator->passes())
            {
                $host->update($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Locality has been updated'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Locality not saved! ' . $e->getMessage()
                ], 404);
        }
        return response()->json($response);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function localities()
    {
        $this->authorize($this);
        return view('admin.localities');
    }
}
