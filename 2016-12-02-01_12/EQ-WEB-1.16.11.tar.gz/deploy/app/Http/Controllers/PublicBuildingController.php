<?php

namespace App\Http\Controllers;

use App\Models\Building;
use App\Models\Floor;
use App\Models\Spacefacility;
use App\Models\Spacetype;
use Illuminate\Http\Request;

class PublicBuildingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $buildings = Building::with('country')
                             ->with('region')
                             ->with('locality')
                             ->with('logoImage')
                             ->with('headerImage')
                             ->get();

        $statusCode = $buildings->count() > 0 ? 200 : 404;
        return $request->ajax() ? response()->json($buildings, $statusCode) : view('home', ['buildings' => $buildings]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, $id)
    {
        $building = Building::with('country')
                            ->with('region')
                            ->with('locality')
                            ->with('logoImage')
                            ->with('headerImage')
                            ->with('activeSpaces')
                            ->where('id', $id)
                            ->orWhere('private_slug', $id)
                            ->orWhere('public_slug', $id)
                            ->firstOrFail();

        $spaceTypesList = Spacetype::all()->lists('name', 'id');
        $spaceFeatures = Spacefacility::where('shared', false)->orderBy('name')->get();
        $sharedFacilities = Spacefacility::where('shared', true)->orderBy('name')->get();
        $floors = Floor::where('building_id', $building->id)->lists('name', 'id');

        $pricingTypes = ['pricing_hourly' => 'HOURLY', 'pricing_daily' => 'DAILY', 'pricing_monthly' => 'MONTHLY'];
        return $request->ajax() ?
            response()->json(['data' => $building]) :
            view('building', [
                'building' => $building,
                'id' => $id,
                'typesList' => $spaceTypesList,
                'spaceFeatures' => $spaceFeatures,
                'sharedFacilities' => $sharedFacilities,
                'pricingTypes' => $pricingTypes,
                'floors' => $floors,
                'floor' => $request->input('floor')
            ]);
    }

}
