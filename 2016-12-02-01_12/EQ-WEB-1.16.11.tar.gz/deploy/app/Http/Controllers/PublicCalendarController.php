<?php

namespace App\Http\Controllers;

use App\Models\Blacklistdate;
use App\Models\Whitelistdate;
use App\Models\Spacebooking;
use App\Models\Space;
use Illuminate\Http\Request;
use App\Services\IDateService;
use App\Services\IBookingEngineService;
use Carbon\Carbon;

class PublicCalendarController extends Controller
{
    protected $dateService;
    protected $bookingService;
    protected $selectArr;
    protected $colorBlack;
    protected $colorWhite;
    protected $colorBlue;
    protected $colorGray;
    
    public function __construct(IBookingEngineService $bookingService, IDateService $dateService)
    {
        $this->dateService = $dateService;
        $this->bookingService = $bookingService;
        $this->selectArr = array("id","name AS title","start_datetime AS start","end_datetime AS end");
        $this->selectArrBooking = array("id","event_title AS title","start_datetime AS start","end_datetime AS end","booked_by_id AS bookedById");
        $this->colorBlack = '#000000';
        $this->colorWhite = '#ffffff';
        $this->colorGray = '#dddddd';
        $this->colorBlue = '000000';
    }

    /**
     * Display all calendar space booking dates by space
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $space_id
     * @return \Illuminate\Http\Response
     */
    public function getSpaceBookingDatesBySpace(Request $request, $space_id)
    {
        $space = Space::find($space_id);
        $spacebookings = $this->bookingService->getSpaceBookings($space);

        $spacebookings->transform(function ($item) { //convert timezone
            $item['start'] = $this->dateService->convertDateToTimezone($item['resolved_start_datetime']);
            if ($item['resolved_end_datetime']) {
                $item['allDay'] = false;
                $item['end'] = $this->dateService->convertDateToTimezone($item['resolved_end_datetime']);
                $item["title"] = $item["event_title"];
            }
            else {
                $item['AllDay'] = true;
                $item["title"] = "[All Day] ".$item["event_title"];
                $dateStartChunks = explode(" ",$item['start']);
                $item['start'] = $dateStartChunks[0]." ".$space['day_start_time'];
                $startTime = New Carbon($item['start']);
                $item['end'] = $startTime->addMinutes($space['day_duration'])->toDateTimeString();
            }
            $item['backgroundColor'] = $this->colorBlue;
            $item["textColor"] = $this->colorWhite;
            $item["bookedById"] = $item["booked_by_id"];

            return collect($item->toArray())
                ->only(['id', 'title', 'allDay', 'AllDay', 'start', 'end', 'backgroundColor', 'textColor', 'bookedById'])
                ->all();
        });
        return response()->json($spacebookings);
    }
    
    /**
     * Display all calendar blacklist dates by space
     * 
     * @param  \Illuminate\Http\Request $request
     * @param  int $space_id
     * @return \Illuminate\Http\Response
     */
    public function getBlacklistDatesBySpace(Request $request, $space_id)
    {
        $dates = Blacklistdate::where('space_id',$space_id)->get($this->selectArr);
        $dates->transform(function ($item) { //convert timezone
            $item['start'] = $this->dateService->convertDateToTimezone($item['start']);
            $item['end'] = $this->dateService->convertDateToTimezone($item['end']);
            return $item;
        });
        return response()->json($dates);
    }
    
}