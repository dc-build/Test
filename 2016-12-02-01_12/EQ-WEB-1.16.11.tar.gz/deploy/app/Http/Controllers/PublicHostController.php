<?php

namespace App\Http\Controllers;

use App\Models\Host;
use App\Models\Space;
use Auth;
use Illuminate\Http\Request;
use Mail;

class PublicHostController extends Controller
{
    public function postMessage(Request $request, $hostId)
    {
        $host = Host::find($hostId);
        $space = Space::with('building')->find($request->input('space_id'));
        $subject = sprintf("Message from %s at %s room of %s", $request->input('name'), $space->room_name, $space->building->display_name);

        $data = array_merge(['host' => $host, 'space' => $space], $request->all());

        $sent = Mail::send('emails.admin.message', $data, function ($mail) use ($host, $subject)
        {
            $mail->from(env('APP_EMAIL_ADDRESS'), env('APP_EMAIL_NAME'));
            // TODO: change to Host id when ready
            $mail->to('john.c.quintal@digitalcarpenter.com.au', $host->contact_name)
                 ->subject($subject);
        });

        $message = $sent === 0 ?
            "Your message could not be sent, please try again." :
            sprintf("Thank you, your message has been sent to %s.", $host->contact_name);

        return response()->json(['message' => $message], $sent === 0 ? 500 : 200);
    }
}
