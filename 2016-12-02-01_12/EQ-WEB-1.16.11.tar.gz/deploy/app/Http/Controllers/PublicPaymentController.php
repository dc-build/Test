<?php


namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Space;
use App\Models\Building;
use App\Models\Spacebooking;
use App\Models\Capacityprice;
use App\Models\Host;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Cookie;

class PublicPaymentController extends Controller
{
    public function __construct()
    {
        
    }
    
    /**
     * 
     * @param Request $request
     * @param string $building_private_slug
     * @param string $space_private_slug
     * @return mixed
     */
    public function index(Request $request, $building_private_slug, $space_private_slug)
    {
        $space = null;
        $retrievebookingDetails = null;
        $widgetSource = $request->input('widgetSource');
        
        /**
         * Get space details
         */
        $space = Space::active()->where('private_slug', $space_private_slug)
                ->with('capacityprices')
                ->with('building')
                ->with('host')
                ->with('spaceconfigurations')
                ->with('galleryImages')
                ->first();
        
        /**
         * Get minimum and maximum attendees - needed to populate and validate number of attendees
         */
        $getMinAttendees = \DB::table('capacityprices')->where('space_id',$space->id)->min('attendees_min');
        $getMaxAttendees = \DB::table('capacityprices')->where('space_id',$space->id)->max('attendees_max');
        $minmaxAttendees = 'required|integer|between:'.$getMinAttendees.','.$getMaxAttendees;
        
        //Retrieve cookie
        $retrievebookingDetails = $request->cookie('booking_details');

        /**
         * Assign cookies as variables if not a new request and if cookie exists.
         */
        if (is_null($widgetSource) && !is_null($retrievebookingDetails)) {
            $widgetSource = $retrievebookingDetails['widgetSource'];
            if ($widgetSource=='hourly') {
                $bookingRequestArr = array(
                    'widgetSource'  => $retrievebookingDetails['widgetSource'],
                    'date'          => $retrievebookingDetails['date'],
                    'num_attendees' => $retrievebookingDetails['num_attendees'],
                    'time_from'     => $retrievebookingDetails['time_from'],
                    'time_to'       => $retrievebookingDetails['time_to']
                );
            }
            elseif ($widgetSource=='daily') {
                $bookingRequestArr = array(
                    'widgetSource'  => $retrievebookingDetails['widgetSource'],
                    'date_from'     => $retrievebookingDetails['date_from'],
                    'date_to'       => $retrievebookingDetails['date_to'],
                    'num_attendees' => $retrievebookingDetails['num_attendees']
                );
            }
            
            $bookingRequest = $bookingRequestArr;
        }
        else {
            $bookingRequest = $request->all();
        }
        
        /**
         * Validate request
         */
        if ($widgetSource=='hourly') {
            $validator = Validator::make($bookingRequest, [
                'date' => 'required|date',
                'num_attendees' => $minmaxAttendees,
                'time_from' => 'required',
                'time_to' => 'required'
            ], Spacebooking::$VALIDATION_MESSAGES);
        }
        elseif ($widgetSource=='daily') {
            $validator = Validator::make($bookingRequest, [
                'date_from' => 'required|date',
                'date_to' => 'required|date|after:date_from',
                'num_attendees' => $minmaxAttendees,
            ], Spacebooking::$VALIDATION_MESSAGES);
        }
        
        try
        {
            if ($validator->passes())
            {
                $host = Host::with('logoImage')->find($space->host_id);
                
                /**
                 * Set cookies if not logged in and if there's no new request - cookies needed to be set before Auth0 login
                 */
                if (!Auth::check() && $request->input('widgetSource'))  {
                    if ($widgetSource=='hourly') {
                        $cookiebookingDetails['widgetSource'] =  $widgetSource;
                        $cookiebookingDetails['date'] =  $request->input('date');
                        $cookiebookingDetails['time_from'] =  $request->input('time_from');
                        $cookiebookingDetails['time_to'] =  $request->input('time_to');
                    }
                    elseif ($widgetSource=='daily') {
                        $cookiebookingDetails['widgetSource'] =  $widgetSource;
                        $cookiebookingDetails['date_from'] =  $request->input('date_from');
                        $cookiebookingDetails['date_to'] =  $request->input('date_to');
                    }
                    $cookiebookingDetails['num_attendees'] =  $request->input('num_attendees');
                    Cookie::queue('booking_details', $cookiebookingDetails, 3600);
                }
                
                return response()->view('payment',['space' => $space, 'bookingDetails' => $bookingRequest, 'host' => $host, 'getMinAttendees' => $getMinAttendees, 'getMaxAttendees' => $getMaxAttendees]);
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
                return response()->json($response);
            }
        }
        catch (\Exception $e)
        {

            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to process your request. Please try again.'
                ], 400);
        }

        if (is_null($space)) {
            return redirect()->route('home');
        }
    }
}