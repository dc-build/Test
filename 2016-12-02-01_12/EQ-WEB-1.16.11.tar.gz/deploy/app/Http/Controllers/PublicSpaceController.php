<?php


namespace App\Http\Controllers;

use App\Models\Building;
use App\Models\Space;
use App\Services\IRateEngineService;
use Carbon\Carbon;
use App\Models\Host;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class PublicSpaceController extends Controller
{
    protected $rateEngine;

    public function __construct(IRateEngineService $rateEngine)
    {
        $this->rateEngine = $rateEngine;
    }

    public function index(Request $request, $buildingId)
    {
        $building = Building::where('id', $buildingId)
                            ->orWhere('private_slug', $buildingId)
                            ->orWhere('public_slug', $buildingId)->first();

        $query = Space::active()->with('building')
                      ->with('floor')
                      ->with('capacityprices')
                      ->with('blacklistdates')
                      ->with('host.logoImage')
                      ->with('headerImage')
                      ->with('thumbImage')
                      ->with('spacetypes')
                      ->with('spacefacilities')
                      ->where('building_id', $building->id);

        if (!empty($request->input('spacetype_id')))
        {
            $query->hasSpacetype($request->input('spacetype_id'));
        }

        $attendees = 1;
        if (!empty($request->input('max_capacity')))
        {
            $attendees = $request->input('max_capacity');
            $query->where('max_capacity', '>=', $request->input('max_capacity'));
        }

        if (!empty($request->input('pricing')))
        {
            $query->hasPricingEnabled($request->input('pricing'));
        }

        if (!empty($request->input('search')))
        {
            $query->search($request->input('search'));
        }

        if (!empty($request->input('facilities')))
        {
            $query->hasFacilities($request->input('facilities'), $request->input('facilities_cardinality'));
        }

        $startDateTime = !empty($request->input('start_date')) ? Carbon::createFromFormat('Y-m-d H:i:s',  strtolower($request->input('start_date') . ":00"), 'Australia/Sydney')  : Carbon::today('Australia/Sydney');
        $endDateTime = !empty($request->input('end_date')) ? Carbon::createFromFormat('Y-m-d H:i:s', strtolower($request->input('end_date') . ":00"), 'Australia/Sydney')  : Carbon::tomorrow('Australia/Sydney');
        $todaysDateTime = Carbon::now('Australia/Sydney');
        $startDif = $todaysDateTime->diffInMinutes($startDateTime);
        $endDif = $todaysDateTime->diffInMinutes($endDateTime);

        //Check the booking window
        if (!empty($request->input('start_date')))
        {
            $query->where(function($query) use($todaysDateTime, $startDif){
                $query->whereNull('booking_window_min');
                $query->orWhere('booking_window_min', '=', 0);
                $query->orWhere('booking_window_min', '<=', $startDif);
            });

            $query->where(function($query) use($todaysDateTime, $startDif){
                $query->whereNull('booking_window_max');
                $query->orWhere('booking_window_max', '=', 0);
                $query->orWhere('booking_window_max', '>=', $startDif);
            });
        }

        if (!empty($request->input('end_date')))
        {
            $query->where(function($query) use($todaysDateTime, $endDif){
                $query->whereNull('booking_window_min');
                $query->orWhere('booking_window_min', '=', 0);
                $query->orWhere('booking_window_min', '<=', $endDif);
            });

            $query->where(function($query) use($todaysDateTime, $endDif){
                $query->whereNull('booking_window_max');
                $query->orWhere('booking_window_max', '=', 0);
                $query->orWhere('booking_window_max', '>=', $endDif);
            });
        }

        if (!empty($request->input('floor')))
        {
            $query->where('floor_id', $request->input('floor'));
        }

        $spaces = $query->get();

        $spaces = $this->rateEngine->calculateSpaceRatesForCollection($spaces, $attendees, $startDateTime, $endDateTime);

        $statusCode = $spaces->count() > 0 ? 200 : 404;

        return response()->json($spaces, $statusCode);
    }
    
    /*
     * Get daily space rates
     * 
     * @param  \Illuminate\Http\Request $request
     * @param string $building_private_slug
     * @param string $space_private_slug
     * @return mixed
     */
    public function detail(Request $request, $building_private_slug, $space_private_slug)
    {
        //Get space details
        $space = Space::active()->where('private_slug', $space_private_slug)
                        ->with('capacityprices')
                        ->with('building')
                        ->with('host')
                        ->with('spacetypes')
                        ->with('spacefacilities')
                        ->with('galleryImages')
                        ->with('headerImage')
                        ->first();
        
        //Get host details
        $host = Host::with('logoImage')->find($space->host_id);
        
        //Get max attendees of space
        $getMaxAttendees = \DB::table('capacityprices')->where('space_id',$space->id)->max('attendees_max');
        
        //Convert minutes to hours
        //$space['day_duration'] = $space['day_duration'] / 60;
        //$space['after_hours_duration'] = $space['after_hours_duration'] / 60;

        $urlData = Input::only('people', 'start_date', 'start_time', 'end_date', 'end_time', 'duration', 'floor');
        \Debugbar::addMessage($urlData);

        if (is_null($space)) {
            return redirect()->route('home');
        }
        else {
            return view('detail',['space' => $space, 'host' => $host, 'getMaxAttendees' => $getMaxAttendees, 'urlData' => $urlData]);
        }
    }

}