<?php
namespace App\Http\Controllers;

use App\Models\Space;
use App\Services\IRateEngineService;
use App\Services\ISpaceManagerService;
use Illuminate\Http\Request;
use Carbon\Carbon;


class RateController extends Controller
{
    protected $rateEngine;

    public function __construct(IRateEngineService $rateEngine) {
        $this->rateEngine = $rateEngine;
    }
    
    /*
     * Get hourly space rates
     * 
     * @param  \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function calculateSpaceRatesHourly(Request $request, $id)
    {
        //Convert to Carbon format
        $startDate = Carbon::createFromFormat('Y-m-d H:i:s', $request->input('time_from'));
        $endDate = Carbon::createFromFormat('Y-m-d H:i:s', $request->input('time_to'));
        
        //Get request details
        $attendees = $request->input('num_attendees');
        $space = Space::find($id);
        
        try {
            //Call RateServiceEngine to calculate rates
            $rateDetail = $this->rateEngine->calculateSpaceRates($space, $attendees, $startDate, $endDate);
            $rates['hourlyTotalCost'] = number_format($rateDetail->hourlyTotalCost(),2);
            $rates['halfDayTotalCost'] = number_format($rateDetail->halfDayTotalCost(),2);
            $rates['dayTotalCost'] = number_format($rateDetail->dayTotalCost(),2);
            $rates['monthTotalCost'] = number_format($rateDetail->monthTotalCost(),2);
            $rates['afterHoursTotalCost'] = number_format($rateDetail->afterHoursTotalCost(),2);
            $rates['totalCost'] = number_format($rateDetail->totalCost(),2);
            $rates['totalHours'] = $rateDetail->totalHours();
            $rates['totalAfterHoursHours'] = $rateDetail->totalAfterHoursHours();
        }
        catch(\Exception $e) {
            if (empty($attendees)) {
                $rates['error'] = "Number of attendees is required.";
            }
            else {
                $rates['error'] = "Invalid Selection";
            }
        }
        return response()->json($rates); 
    }
    
    /*
     * Get daily space rates
     * 
     * @param  \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function calculateSpaceRatesDaily(Request $request, $id)
    {
        //Convert to Carbon format
        $startDate = Carbon::createFromFormat('Y-m-d', $request->input('date_from'));
        $endDate = Carbon::createFromFormat('Y-m-d', $request->input('date_to'));
        
        //Get request details
        $attendees = $request->input('num_attendees');
        $space = Space::find($id);
        
        try {
            //Call RateServiceEngine to calculate rates
            $rateDetail = $this->rateEngine->calculateSpaceRates($space, $attendees, $startDate, $endDate);
            $rates['dayTotalCost'] = number_format($rateDetail->dayTotalCost(),2);
            $rates['monthTotalCost'] = number_format($rateDetail->monthTotalCost(),2);
            $rates['totalCost'] = number_format($rateDetail->totalCost(),2);
            $rates['totalDays'] = $rateDetail->totalDays();
            $rates['totalMonths'] = $rateDetail->totalMonths();
        }
        catch(\Exception $e) {
            if (empty($attendees)) {
                $rates['error'] = "Number of attendees is required.";
            }
            else {
                $rates['error'] = "Invalid Selection";
            }
        }
        return response()->json($rates); 
    }
    
    /*
     * Get minimum space rates
     * 
     * @param  \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function calculateSpaceRatesMinimum(Request $request, $id)
    {
        $attendees = 1;
        $space = Space::find($id);

        $startDate = Carbon::create(2016, 10, 27, 9, 0, 0);
        $endDate = Carbon::create(2016, 10, 28, 10, 0, 0);
        $rateDetail = $this->rateEngine->calculateSpaceRates($space, $attendees, $startDate, $endDate);
        $rates['maxHourPrice'] = $rateDetail->maxHourPrice();
        $rates['maxHalfDayPrice'] = $rateDetail->maxHalfDayPrice();
        $rates['maxFullDayPrice'] = $rateDetail->maxFullDayPrice();
        $rates['maxMonthPrice'] = $rateDetail->maxMonthPrice();
        
        return response()->json($rates); 
    }
}