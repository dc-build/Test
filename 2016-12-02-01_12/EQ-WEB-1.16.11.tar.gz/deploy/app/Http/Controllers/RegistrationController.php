<?php


namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;

class RegistrationController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest');
    }

    public function index(Request $request, $invitation_code)
    {
        $user = User::where('invitation_code', $invitation_code)->first();
        return view('register',['user' => $user]);
    }
    
    public function postRegister(Request $request, $invitation_code)
    {
        $password = $request->input("password");
        $first_name = $request->input("first_name");
        $last_name = $request->input("last_name");
        $mobile_number = $request->input("mobile_number");
        $isActive = $request->input("isActive");
        
        $validator = Validator::make($request->all(), [
            'password' => 'required',
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $user = User::where('invitation_code', $invitation_code)->first();
        $email = $user->email;
        
        if ($isActive=="1") {
            $isActive = "true";
        }
        else {
            $isActive = "false";
        }
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://".env("AUTH0_DOMAIN")."/dbconnections/signup",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => "{\n  \"client_id\":   \"".env("AUTH0_CLIENT_ID")."\", \n  \"email\":    \"".$email."\",\n  \"password\":    \"".$password."\",\n  \"connection\":  \"mysql\",\n  \"user_metadata\": {\n    \"first_name\": \"".$first_name."\",\n    \"last_name\": \"".$last_name."\",\n    \"mobile_number\": \"".$mobile_number."\",\n    \"isActive\": \"".$isActive."\"\n\t}\n}",
            CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        
        $response = json_decode($response);
        $err_msg = 'There was an error processing your request.';

        if (isset($response->statusCode) || $err) {
            if ($response->statusCode=="400") {
                return redirect()->back()->with('error', $response->description);
            }
            else {
                return redirect()->back()->with('error', $err_msg);
            }
        }
        elseif (isset($response->error)) {
            return redirect()->back()->with('error', $response->error);
        }
        else {
            //Automatically redirect to login page on successful registration
            return redirect()->route('login');
        }
        
    }
}