<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Role;
use Validator;


class RoleController extends AdminBaseController
{
    public function __construct()
    {
        parent::__construct();
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize($this);
        $roles = Role::all();
        return response()->json(['data' => $roles]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);
        $data = Role::getInputValues($request);
        $validator = Validator::make($data, Role::$ROLE_VALIDATION_RULES);
        
        if ($validator->fails())
        {
            $response = array(
                'status' => 'error',
                'message' => $validator->messages()->toArray(),
                'statuscode' => "402"
            );
            return response()->json($response);
        }
        
        try {
            Role::create($data);
            $response = array(
                'status' => 'success',
                'message' => 'Role has been added',
                'statuscode' => "200"
            );
        }
        catch(\Exception $e) {
            $response = array(
                'status' => 'error',
                'message' => $e->getMessage(),
                'statuscode' => "400"
            );
        }
        return $response;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        $roles = Role::where('id',$id)->first();
        return response()->json($roles);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);
        $data = Role::getInputValues($request);
        $validator = Validator::make($data, Role::$ROLE_VALIDATION_RULES);
 
        $role = Role::find($id);
       
        if ($validator->fails())
        {
            $response = array(
                'status' => 'error',
                'message' => $validator->messages()->toArray(),
                'statuscode' => "402"
            );
            return response()->json($response);
        }
        
        try {
            $role->update($data);
            $response = array(
                'status' => 'success',
                'message' => 'Role details has been updated',
                'statuscode' => "200"
            );
        }
        catch(\Exception $e) {
            $response = array(
                'status' => 'error',
                'message' => $e->getMessage(),
                'statuscode' => "400"
            );
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        $role = Role::find($id);
        try {
            $role->delete();
            $response = array(
                'status' => 'success',
                'message' => 'Role has been deleted',
                'statuscode' => "200"
            );
        }
        catch(\Exception $e) {
            $response = array(
                'status' => 'error',
                'message' => $e->getMessage(),
                'statuscode' => "400"
            );
        }
        return response()->json($response);
    }
    
    public function roles(Request $request)
    {
        $this->authorize($this);
        return view('admin.roles');
    }
}
