<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 13/10/2016
 * Time: 3:39 PM
 */
namespace App\Http\Controllers;

use App\Models\Capacityprice;
use App\Models\Space;
use App\Models\Spacefacility;
use App\Models\Spacetype;
use App\Models\User;
use App\Services\IAuthorisedModelAccessService;
use App\Services\IImageService;
use Illuminate\Database\Connection;
use Illuminate\Http\Request;
use Illuminate\Log\Writer;
use Illuminate\Validation\Factory;

error_reporting(E_ALL);

/***
 * API Controller for Spaces
 * Class SpacesController
 * @package App\Http\Controllers
 */
class SpaceController extends AdminBaseController
{
    protected $log = NULL;
    protected $validator = NULL;
    protected $db = NULL;
    protected $imageService = NULL;

    public function __construct(
        Writer $log,
        Factory $validator,
        Connection $db,
        IImageService $imageService) {

        $this->log = $log;
        $this->validator = $validator;
        $this->db = $db;
        $this->imageService = $imageService;

        parent::__construct();
    }

    /***
     * Default index page
     */
    public function index(Request $request)
    {
        $this->authorize($this);
        $user = $request->user();

        //Get the spaces that his user can see
        $spaces = Space::getAllAuthorised($user)->with('host')->get();

        foreach ($spaces as $space)
        {
            $space['description'] = str_limit(strip_tags($space['description']), 100);
            $space['terms'] = str_limit(strip_tags($space['terms']), 100);
        }
        return response()->json(['data' => $spaces]);
    }

    public function spaces(Request $request)
    {
        $this->authorize($this);

        $spaceTypesList = Spacetype::all()->lists('name', 'id');
        $spaceFeatures = Spacefacility::where('shared', false)->orderBy('name')->get();
        $sharedFacilities = Spacefacility::where('shared', true)->orderBy('name')->get();

        return view('admin.spaces',
                    [
                        'spaceTypesList' => $spaceTypesList,
                        'spaceFeatures' => $spaceFeatures,
                        'sharedFacilities' => $sharedFacilities
                    ]
        );
    }

    /**
     * API Spaces/create/GET
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /***
     * API Spaces show/GET
     * @param $id
     */
    public function show($id)
    {
        $this->authorize($this);
        $space = Space::where('id', $id)
            ->with('capacityprices')
            ->with('galleryImages')
            ->with('thumbImage')
            ->with('sharedfacilities')
            ->with('spacefeatures')
            ->with('spacetypes')
            ->first();
        return response()->json($space);
    }

    /***
     * API Spaces/POST
     * @param Request $request
     */
    public function store(Request $request)
    {
        $this->authorize($this);
        $data = Space::getInputValues($request);

        $validation = $this->validator->make($data, Space::$SPACE_VALIDATION_RULES, Space::$SPACE_VALIDATION_MESSAGES);

        if ($validation->fails())
        {
            $response = array(
                'status' => 'error',
                'message' => $validation->messages()->toArray(),
                'statuscode' => "402"
            );
            return response()->json($response);
        }

        try {
            $this->db->transaction(function() use(&$data, $request)
            {
                $space = Space::create($data);
                $capacitypriceData = $request->input('capacityprices');
                if (!is_null($capacitypriceData)) {
                    foreach ($capacitypriceData as $item)
                    {
                        $capacityprice = new Capacityprice($item);
                        $space->capacityprices()->save($capacityprice);
                    }
                }
                $space->spacefacilities()->detach();
                $space->sharedfacilities()->attach($request->input('sharedfacilities'));
                $space->spacefeatures()->attach($request->input('spacefeatures'));

                $space->spacetypes()->detach();
                $space->spacetypes()->attach($request->input('spacetypes'));
            });

            $response = array(
                'status' => 'success',
                'message' => 'Space has been added',
                'statuscode' => "200"
            );
        }
        catch(\Exception $e) {
            $this->log->error($e);
            $response = array(
                'status' => 'error',
                'message' => $e->getMessage(),
                'statusText' => $e->getMessage(),
                'statuscode' => "400"
            );
        }
        return response()->json($response);
    }

    /**
     * API Sapces/edit/GET
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    }

    /***
     * API Spaces/update/PUT
     * @param Request $request
     * @param $id
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);

        $data = array_merge(Space::$DEFAULT_VALUES, $request->all(), Space::$OVERRIDE_VALUES);
        $validation = $this->validator->make($data, Space::$SPACE_VALIDATION_RULES, Space::$SPACE_VALIDATION_MESSAGES);

        if ($validation->fails())
        {
            $response = array(
                'status' => 'error',
                'message' => $validation->messages()->toArray(),
                'statuscode' => "402"
            );
            return response()->json($response);
        }

        \Debugbar::addMessage($data);
        $space = Space::find($id);
        try {
            $cpValid = true;
            $this->db->transaction(function() use($space, $data, $request, &$cpValid) {
                $space->update($data);
                $capacitypriceData = $request->input('capacityprices');
                if (!is_null($capacitypriceData)) {
                    foreach ($capacitypriceData as $item)
                    {
                        $capacityprice = new Capacityprice($item);
                        $space->capacityprices()->save($capacityprice);
                    }
                }
                Capacityprice::destroy(explode(',', trim($request->input('deleted_capacityprices'), ',')));

                $space->spacefacilities()->detach();
                $space->sharedfacilities()->attach($request->input('sharedfacilities'));
                $space->spacefeatures()->attach($request->input('spacefeatures'));

                $space->spacetypes()->detach();
                $space->spacetypes()->attach($request->input('spacetypes'));

                //Check that the capacity pricing is valid
                $sortedCp = $space->capacityprices->sortBy('attendees_min');

                $prevMin = null;
                $prevMax = null;

                foreach($sortedCp as $cp)
                {
                    if($prevMin == null)
                    {
                        //the first iteration must start at 1
                        if($cp->attendees_min == 1 && $cp->attendees_max > $cp->attendees_min)
                        {
                            $prevMin = $cp->attendees_min;
                            $prevMax = $cp->attendees_max;
                        }
                        else
                        {
                            $cpValid = false;
                            break;
                        }
                    }
                    else
                    {
                        //Check that the next min attendees is 1 greater than the previous max
                        if($cp->attendees_min == ($prevMax + 1) && $cp->attendees_max > $cp->attendees_min)
                        {
                            $prevMin = $cp->attendees_min;
                            $prevMax = $cp->attendees_max;
                        }
                        else
                        {
                            $cpValid = false;
                            break;
                        }
                    }
                }

                if($cpValid == false)
                {
                    $this->db->rollBack();
                }
            });

            if($cpValid == false)
            {
                return response()->json(
                    [
                        'status' => 'error',
                        'message' => 'The Minimum and Maximum attendees must be consecutive, without any gaps.'
                    ], 400);
            }

            $response = [
                'status' => 'success',
                'message' => 'Space details have been updated.'
            ];

            return response()->json($response);
        }
        catch (\Exception $e)
        {
            $this->log->error($e);
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create the Space. Please try again.'
                ], 400);
        }
    }

    /***
     * API Spaces/delete
     * @param $id
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try {
            $space = Space::find($id);
            $space->delete();

            $response = array(
                'status' => 'success',
                'message' => 'Space has been deleted',
                'statuscode' => "200"
            );
        }
        catch(\Exception $e) {

            $this->log->error($e);

            if ($e->getCode()) {
                $message = 'There wwas an issue attempting to remove this space, please try again later.';
            }
            else {
                $message = 'Space was not found!';
            }

            $response = array(
                'status' => 'error',
                'message' => $message,
                'statuscode' => "400"
            );
        }
        return response()->json($response);
    }

}