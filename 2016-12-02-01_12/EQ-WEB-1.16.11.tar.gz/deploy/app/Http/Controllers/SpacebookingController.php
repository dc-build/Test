<?php

namespace App\Http\Controllers;

use App\Models\Spacebooking;
use App\Models\Space;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Services\IDateService;
use Illuminate\Support\Facades\Auth;

class SpacebookingController extends AdminBaseController
{
    protected $dateService;
    
    public function __construct(IDateService $dateService)
    {
        parent::__construct();
        $this->dateService = $dateService;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $this->authorize($this);
        $user = $request->user();

        $spacebookings = Spacebooking::getAllAuthorised($user)->with('spaces')->with('users')->with('spaceconfigurations')->get();

        $spacebookings->transform(function ($item) {
            $item['start_datetime'] = $this->dateService->convertDateToTimezone($item['start_datetime']);
            return $item;
        });
        return response()->json(['data' => $spacebookings]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Spacebooking::$VALIDATION_RULES, Spacebooking::$VALIDATION_MESSAGES);
        
        try
        {
            if ($validator->passes())
            {
                Spacebooking::create($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Space Booking has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create Space Booking. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        try
        {
            $spacebookings = Spacebooking::findOrFail($id);

            $this->authorize($spacebookings);

            return response()->json($spacebookings);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Space Booking not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);
        
        $spacebookings = Spacebooking::findOrFail($id);

        $this->authorize($spacebookings);

        $space_id = $spacebookings->space_id;
        $booked_by_id = Auth::user()->id;
        
        $request->request->add(['space_id' => $space_id, 'booked_by_id' => $booked_by_id]);
        $validator = Validator::make($request->all(), Spacebooking::$EDIT_VALIDATION_RULES, Spacebooking::$VALIDATION_MESSAGES);

        try
        {
            if ($validator->passes())
            {
                $spacebookings->update($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Space Booking has been updated'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Space Booking not found!'
                ], 404);
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try {
            $spacebookings = Spacebooking::findOrFail($id);

            $this->authorize($spacebookings);

            $spacebookings->delete();
            $message = 'Space Booking has been successfully deleted';
            
            return response()->json(
                [
                    'status' => 'success',
                    'message' => $message
                ]);
        }
        catch (\Exception $e)
        {
           
            $message = 'Space Booking not found!';
            
            return response()->json(
                [
                    'status' => 'error',
                    'message' => $message
                ], 404);
        }
    }

    public function spacebookings(Request $request)
    {
        $this->authorize($this);
        $spaces = Space::getAllAuthorised($request->user())->get();
        return view('admin.spacebookings',['spaces' => $spaces]);
    }
}