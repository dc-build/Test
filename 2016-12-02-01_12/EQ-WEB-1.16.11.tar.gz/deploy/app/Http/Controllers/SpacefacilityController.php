<?php

namespace App\Http\Controllers;

use App\Models\Spacefacility;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SpacefacilityController extends AdminBaseController
{
    public function __construct()
    {
        parent::__construct();
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize($this);
        $spacefacilities = Spacefacility::all();
        return response()->json(['data' => $spacefacilities]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Spacefacility::$VALIDATION_RULES, Spacefacility::$VALIDATION_MESSAGES);
        
        try
        {
            if ($validator->passes())
            {
                Spacefacility::create($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Space Facility has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create Space Facility. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        try
        {
            $spacefacilities = Spacefacility::findOrFail($id);
            return response()->json($spacefacilities);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Space Facility not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Spacefacility::$VALIDATION_RULES, Spacefacility::$VALIDATION_MESSAGES);

        try
        {
            $spacefacilities = Spacefacility::findOrFail($id);
            if ($validator->passes())
            {
                $spacefacilities->update($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Space Facility has been updated'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Space Facility not found!'
                ], 404);
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try {
            $spacefacilities = Spacefacility::findOrFail($id);
            $spacefacilities->delete();
            $message = 'Space Facility has been successfully deleted';
            
            return response()->json(
                [
                    'status' => 'success',
                    'message' => $message
                ]);
        }
        catch (\Exception $e)
        {
            
            $message = 'Space Facility not found!';
            
            
            return response()->json(
                [
                    'status' => 'error',
                    'message' => $message
                ], 404);
        }
    }

    public function spacefacilities(Request $request)
    {
        $this->authorize($this);
        return view('admin.spacefacilities');
    }
}