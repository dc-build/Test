<?php

namespace App\Http\Controllers;

use App\Models\Spacetype;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SpacetypeController extends AdminBaseController
{
    public function __construct()
    {
        parent::__construct();
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize($this);
        $spacetypes = Spacetype::with('createdby')
                               ->with('updatedby')
                               ->get();
        return response()->json(['data' => $spacetypes]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Spacetype::$VALIDATION_RULES, Spacetype::$VALIDATION_MESSAGES);
        
        try
        {
            if ($validator->passes())
            {
                Spacetype::create($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Space Type has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create Space Type. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        try
        {
            $spacetypes = Spacetype::findOrFail($id);
            return response()->json($spacetypes);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Space Type not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Spacetype::$VALIDATION_RULES, Spacetype::$VALIDATION_MESSAGES);

        try
        {
            $spacetypes = Spacetype::findOrFail($id);
            if ($validator->passes())
            {
                $spacetypes->update($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Space Type has been updated'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Space Type not found!'
                ], 404);
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try {
            $spacetypes = Spacetype::findOrFail($id);
            $spacetypes->delete();
            $message = 'Space Type has been successfully deleted';
            
            return response()->json(
                [
                    'status' => 'success',
                    'message' => $message
                ]);
        }
        catch (\Exception $e)
        {
            
            $message = 'Space Type not found!';
            
            
            return response()->json(
                [
                    'status' => 'error',
                    'message' => $message
                ], 404);
        }
    }

    public function spacetypes(Request $request)
    {
        $this->authorize($this);
        return view('admin.spacetypes');
    }
}