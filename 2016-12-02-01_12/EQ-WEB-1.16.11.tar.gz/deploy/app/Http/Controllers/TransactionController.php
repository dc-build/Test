<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TransactionController extends AdminBaseController
{
    public function __construct()
    {
        parent::__construct();
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize($this);
        $transactions = Transaction::with('spacebookings')->get();
        return response()->json(['data' => $transactions]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Transaction::$VALIDATION_RULES, Transaction::$VALIDATION_MESSAGES);
        
        try
        {
            if ($validator->passes())
            {
                Transaction::create($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Transaction has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create Transaction. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        try
        {
            $transactions = Transaction::findOrFail($id);
            return response()->json($transactions);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Transaction not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int                      $id
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);

        $validator = Validator::make($request->all(), Transaction::$VALIDATION_RULES, Transaction::$VALIDATION_MESSAGES);

        try
        {
            $transactions = Transaction::findOrFail($id);
            if ($validator->passes())
            {
                $transactions->update($request->all());
                $response = [
                    'status' => 'success',
                    'message' => 'Transaction has been updated'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Transaction not found!'
                ], 404);
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     *
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try {
            $transactions = Transaction::findOrFail($id);
            $transactions->delete();
            $message = 'Transaction has been successfully deleted';
            
            return response()->json(
                [
                    'status' => 'success',
                    'message' => $message
                ]);
        }
        catch (\Exception $e)
        {
           
            $message = 'Transaction not found!';
            
            return response()->json(
                [
                    'status' => 'error',
                    'message' => $message
                ], 404);
        }
    }

    public function transactions(Request $request)
    {
        $this->authorize($this);
        return view('admin.transactions');
    }
}