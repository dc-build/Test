<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Role;
use Validator;


class UserController extends AdminBaseController
{
    public function __construct()
    {
        parent::__construct();
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $this->authorize($this);
        $users = User::with('roles')->get();
        return response()->json(['data' => $users]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->authorize($this);
        $data = User::getUserAddInputValues($request);
        $data["invitation_code"] = bin2hex(openssl_random_pseudo_bytes(16));
        $validator = Validator::make($data, User::$USER_ADD_VALIDATION_RULES);
        
        try
        {
            if ($validator->passes())
            {
                User::create($data);
                $response = [
                    'status' => 'success',
                    'message' => 'User has been added'
                ];
            }
            else
            {
                $response = [
                    'status' => 'error',
                    'message' => $validator->messages()->toArray()
                ];
            }
            return response()->json($response);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'Unable to create User. Please try again.'
                ], 400);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->authorize($this);
        try
        {
            $user = User::where('id',$id)->first();
            return response()->json($user);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'User not found'
                ], 404);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->authorize($this);
        $data = User::getUserEditInputValues($request);
        $validator = Validator::make($data, User::$USER_EDIT_VALIDATION_RULES);
 
        $user = User::find($id);
        $auth0_id = $user->auth0_id;
        if ($validator->fails())
        {
            $response = array(
                'status' => 'error',
                'message' => $validator->messages()->toArray(),
                'statuscode' => "402"
            );
            return response()->json($response);
        }
        
        if ($data["isActive"]=="1") {
            $data["isActive"] = true;
            $active = "true";
        }
        else {
            $data["isActive"] = false;
            $active = "false";
        }
       
        
        try {
            if ($user->auth0id!=null) {
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => "https://".env("AUTH0_DOMAIN")."/api/v2/users/".urlencode($user->auth0id),
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "PATCH",
                    CURLOPT_POSTFIELDS => "{\n  \"email\": \"".$data["email"]."\",\n  \"user_metadata\": {\n        \"mobile_number\": \"".$data["mobile_number"]."\",\n        \"first_name\":\"".$data["first_name"]."\",\n        \"last_name\":\"".$data["last_name"]."\",\n        \"isActive\":".$active."\n  }\n}",
                    CURLOPT_HTTPHEADER => array(
                        "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJNdlhlS0NCNkRSa1Fya3pWZEFNUXg2RnpVTFNOSXRXaSIsInNjb3BlcyI6eyJ1c2VycyI6eyJhY3Rpb25zIjpbInVwZGF0ZSJdfX0sImlhdCI6MTQ3NTYyOTA0OSwianRpIjoiMjM2ODNlYjgzNTliMGMyMzA1YjUwYjE3NjE0NjcwMTYifQ.tJ60QrkgByg6Ndrpo61AmthTpOrbk9MlqQgE3r1Whrs",
                        "cache-control: no-cache",
                        "content-type: application/json"
                    ),
                ));

                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);

                $response = json_decode($response);
                $err_msg = 'There was an error processing your request.';
            }

            if (isset($response->statusCode)) {
                if (isset($response->message)) {
                    return response()->json(
                    [
                        'status' => 'error',
                        'message' => $response->message
                    ], 404);
                }
                else {
                    return response()->json(
                    [
                        'status' => 'error',
                        'message' => $response->description
                    ], 404);
                }
            }
            elseif (!empty($err)) {
                return response()->json(
                    [
                        'status' => 'error',
                        'message' => $err_msg
                    ], 404);
            }
            else {
                $user->update($data);
                $response = [
                    'status' => 'success',
                    'message' => 'User details has been updated'
                ];
            }
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'User not found!'
                ], 404);
        }
        return response()->json($response);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->authorize($this);
        try
        {
            $user = User::findOrFail($id);
            $deleted = $user->delete();
            $message = $deleted ? 'User has been successfully deleted' : 'There was an error attempting to delete the User';
            return response()->json(
                [
                    'status' => $deleted ? 'success' : 'error',
                    'message' => $message
                ]);
        }
        catch (\Exception $e)
        {
            return response()->json(
                [
                    'status' => 'error',
                    'message' => 'User not found!'
                ], 404);
        }
    }
    
    public function users(Request $request)
    {
        $this->authorize($this);
        $roles = Role::all();
        return view('admin.users',['roles' => $roles]);
    }
}
