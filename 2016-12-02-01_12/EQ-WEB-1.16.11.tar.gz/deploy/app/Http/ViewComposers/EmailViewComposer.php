<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 23/11/2016
 * Time: 09:38
 */

namespace App\Http\ViewComposers;

use App\Models\Building;
use App\Models\Space;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class EmailViewComposer
{
    public function compose(View $view)
    {
        $request = request();
        if (!empty($request->input('space_id')))
        {
            $buildingId = Space::with('building')->find($request->input('space_id'))->building_id;
        }
        else if (!empty($request->input('building_id')))
        {
            $buildingId = $request->input('building_id');
        }
        else
        {
            $buildingId = null;
        }

        if ($buildingId)
        {
            $building = Building::with('logoImage')->find($buildingId);
            $logoImage = $building->logoImage->first();
            $view->with('logo_url', $logoImage->url);
        }
    }
}