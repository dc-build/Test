<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/********************************************************
* PUBLIC ROUTES
*/
use App\Models\Host;

Route::get('/', [
    'as' => 'home',
    'uses' => 'HomeController@index'
]);

Route::get('/buildings/{building_private_slug}/spaces/{space_private_slug}', [
    'as' => 'detail',
    'uses' => 'PublicSpaceController@detail'
]);

Route::get('/buildings/{building_private_slug}/spaces/{space_private_slug}/payment', [
    'as' => 'payment',
    'middleware' => 'cors',
    'uses' => 'PublicPaymentController@index'
]);

Route::post('/buildings/{building_private_slug}/spaces/{space_private_slug}/payment', [
    'as' => 'payment',
    'middleware' => 'cors',
    'uses' => 'PublicPaymentController@index'
]);

Route::post('/buildings/{building_private_slug}/spaces/{space_private_slug}/booking', [
    'as' => 'payment.post',
    'middleware' => 'cors',
    'uses' => 'BookingController@postPaymentForm'
]);

Route::get('/mybookings', [
    'as' => 'my.bookings',
    'middleware' => 'auth',
    'uses' => 'BookingController@index'
]);

Route::get('/buildings/{building_private_slug}/mybookings/view/{id}', [
    'as' => 'my.bookings.view',
    'middleware' => 'auth',
    'uses' => 'BookingController@viewSpaceBookingDetails'
]);

Route::get('/buildings/{building_private_slug}/mybookings/edit/{id}', [
    'as' => 'my.bookings.edit',
    'middleware' => 'auth',
    'uses' => 'BookingController@editSpaceBookingDetails'
]);

Route::post('/buildings/{building_private_slug}/mybookings/edit/{id}', [
    'as' => 'my.bookings.edit.post',
    'middleware' => 'auth',
    'uses' => 'BookingController@editSpaceBookingDetails'
]);


Route::resource('buildings', 'PublicBuildingController', ['only' => ['index', 'show']]);

Route::get('/buildings/{idOrSlug}/spaces', [
    'as' => 'buildings.spaces',
    'uses' => 'PublicSpaceController@index'
]);

Route::post('/hosts/{host_id}/spaces/{space_id}/message', [
    'as' => 'hosts.message',
    'uses' => 'PublicHostController@postMessage'
]);

/********************************************************
* AUTHENTICATION ROUTES - DEFAULT LARAVEL
*/
/*
Route::post('/login', [
    'as' => 'login.post', 
    'uses' => 'Auth\AuthController@postLogin'
]);
*/
Route::get('/logout', [
    'as' => 'logout',
    'uses' => 'Auth\AuthController@getLogout'
]);

// Password reset link request routes...
Route::get('/password/email', [
    'as' => 'password-reset.request',
    'uses' => 'Auth\PasswordController@getEmail'
]);

Route::post('/password/email', [
    'as' => 'password-reset.request.post',
    'uses' => 'Auth\PasswordController@postEmail'
]);

// Password reset routes...
Route::get('/password/reset/{token}', [
    'as' => 'password-reset.complete',
    'uses' => 'Auth\PasswordController@getReset'
]);

Route::post('/password/reset', [
    'as' => 'password-reset.complete.post',
    'uses' => 'Auth\PasswordController@postReset'
]);

/********************************************************
* ADMIN ROUTES
*/
Route::get('/admin', [
    'as' => 'admin.home',
    'uses' => 'AdminController@index'
]);

Route::get('/admin/users', [
    'as' => 'admin.users',
    'uses' => 'UserController@users'
]);

Route::get('/admin/roles', [
    'as' => 'admin.roles',
    'uses' => 'RoleController@roles'
]);

Route::get('/admin/buildings', [
    'as' => 'admin.buildings',
    'uses' => 'BuildingController@buildings'
]);

Route::get('/admin/hosts', [
    'as' => 'admin.hosts',
    'uses' => 'HostController@hosts'
]);

Route::get('/admin/imagetypes', [
    'as' => 'admin.imagetypes',
    'uses' => 'ImagetypeController@imagetypes'
]);

Route::get('/admin/spaces', [
    'as' => 'admin.spaces',
    'uses' => 'SpaceController@spaces'
]);

Route::get('/admin/spaces/bookings', [
    'as' => 'admin.spacebookings',
    'uses' => 'SpacebookingController@spacebookings'
]);

Route::get('/admin/payments', [
    'as' => 'admin.transactions',
    'uses' => 'TransactionController@transactions'
]);

Route::get('/admin/spaces/configurations', [
    'as' => 'admin.spaceconfigurations',
    'uses' => 'SpaceconfigurationController@spaceconfigurations'
]);

Route::get('/admin/floors', [
    'as' => 'admin.floors',
    'uses' => 'FloorController@floors'
]);

Route::get('/admin/payments/cards', [
    'as' => 'admin.cards',
    'uses' => 'CardController@cards'
]);

Route::get('/admin/spaces/facilities', [
    'as' => 'admin.spacefacilities',
    'uses' => 'SpacefacilityController@spacefacilities'
]);

Route::get('/admin/spaces/types', [
    'as' => 'admin.spacetypes',
    'uses' => 'SpacetypeController@spacetypes'
]);

Route::get('/admin/spaces/uses', [
    'as' => 'admin.spaceuses',
    'uses' => 'SpaceuseController@spaceuses'
]);

Route::get('/admin/localities', [
    'as' => 'admin.localities',
    'uses' => 'LocalityController@localities'
]);


Route::get('/admin/blacklistdates', [
    'as' => 'admin.blacklistdates',
    'uses' => 'BlacklistdateController@blacklistdates'
]);

Route::get('/admin/whitelistdates', [
    'as' => 'admin.whitelistdates',
    'uses' => 'WhitelistdateController@whitelistdates'
]);

Route::get('/admin/calendar', [
    'as' => 'admin.calendar',
    'uses' => 'CalendarController@calendar'
]);

Route::get('/admin/emailtest/send', [
    'as' => 'email.test.send',
    'uses' => 'EmailTestController@send'
]);

Route::get('/admin/emailtest/view', [
    'as' => 'email.test.view',
    'uses' => 'EmailTestController@view'
]);
/********************************************************
* AUTH0
*/

Route::get('/auth0/callback', [
    'as' => 'auth0.callback',
    'uses' => 'Auth\Auth0Controller@callback'
    //'uses' => '\Auth0\Login\Auth0Controller@callback'
]);

Route::get('/login', [
    'as' => 'login',
    'uses' => 'Auth\Auth0Controller@login'
]);

/********************************************************
* REGISTRATION
*/

Route::get('/register/{invitation_code}', [
    'as' => 'register',
    'uses' => 'RegistrationController@index'
]);

Route::post('/register/{invitation_code}', [
    'as' => 'register.post',
    'uses' => 'RegistrationController@postRegister'
]);

/********************************************************
* API
*/

Route::group(['prefix' => 'api', 'middleware' => 'cors'], function()
{
    Route::get('public/calendars/spacebookings/{space_id}', [
        'as' => 'public.calendar.spacebookings.space',
        'uses' => 'PublicCalendarController@getSpaceBookingDatesBySpace'
    ]);
    
    Route::get('public/calendars/blacklist/{space_id}', [
        'as' => 'public.calendar.blacklist.space',
        'uses' => 'PublicCalendarController@getBlacklistDatesBySpace'
    ]);
    
    Route::get('calendars/spacebookings', [
        'as' => 'calendar.spacebookings',
        'uses' => 'CalendarController@getSpaceBookingDates'
    ]);
    
    Route::get('calendars/spacebookings/{space_id}', [
        'as' => 'calendar.spacebookings.space',
        'uses' => 'CalendarController@getSpaceBookingDatesBySpace'
    ]);
    
    Route::get('calendars/blacklist', [
        'as' => 'calendar.blacklist',
        'uses' => 'CalendarController@getBlacklistDates'
    ]);
    
    Route::get('calendars/blacklist/{space_id}', [
        'as' => 'calendar.blacklist.space',
        'uses' => 'CalendarController@getBlacklistDatesBySpace'
    ]);
    
    Route::get('calendars/whitelist', [
        'as' => 'calendar.whitelist',
        'uses' => 'CalendarController@getWhitelistDates'
    ]);
    
    Route::get('calendars/whitelist/{space_id}', [
        'as' => 'calendar.whitelist.space',
        'uses' => 'CalendarController@getWhitelistDatesBySpace'
    ]);
    
    Route::get('calendars/spaces/{space_id}', [
        'as' => 'calendar.spaces',
        'uses' => 'CalendarController@getDatesBySpace'
    ]);

    Route::get('buildings/list', [
        'as' => 'api.buildings.list',
        'uses' => 'BuildingController@apiList'
    ]);

    Route::get('buildings/{building_id}/floors', function($building_id) {
        $floors = \App\Models\Floor::where('building_id', $building_id)->get();
        return response()->json($floors->toArray());
//        return response()->json($floors->lists('name', 'id'));
    });

    Route::get('buildings/{building_id}/hosts', [
        'as' => 'api.host.list',
        'uses' => 'HostController@apiList'
    ]);

    Route::resource('users', 'UserController');
    Route::resource('roles', 'RoleController');
    Route::resource('buildings', 'BuildingController');
    Route::resource('spaces', 'SpaceController');
    Route::resource('hosts', 'HostController');
    Route::resource('imagetypes', 'ImagetypeController');
    Route::resource('spacebookings', 'SpacebookingController');
    Route::resource('transactions', 'TransactionController');
    Route::resource('spaceconfigurations', 'SpaceconfigurationController');
    Route::resource('floors', 'FloorController');
    Route::resource('cards', 'CardController');
    Route::resource('spacefacilities', 'SpacefacilityController');
    Route::resource('spacetypes', 'SpacetypeController');
    Route::resource('spaceuses', 'SpaceuseController');
    Route::resource('blacklistdates', 'BlacklistdateController');
    Route::resource('whitelistdates', 'WhitelistdateController');
    Route::resource('localities', 'LocalityController');
    Route::resource('calendars', 'CalendarController');
    Route::resource('public_calendars', 'PublicCalendarController');

    Route::get('countries/{with_regions_only?}', function($withRegionsOnly = null)
    {
        $countries = \App\Models\Country::withRegions($withRegionsOnly);
        return response()->json($countries->lists('countries.nicename', 'countries.id'));
    });

    Route::get('countries/{country_id}/regions/{with_localities_only?}', function ($country_id = null, $withLocalitiesOnly = null)
    {
        $regions = \App\Models\Region::regionsForCountry($country_id)->withLocalities($withLocalitiesOnly);
        return response()->json($regions->lists('regions.name', 'regions.id'));
    });

    Route::get('regions/{region_id}/localities', function ($region_id = null)
    {
        $localities = \App\Models\Locality::localitiesForRegion($region_id);
        return response()->json($localities->lists('name', 'id'));
    });

    Route::get('images/{image_uuid}/{type}', function ($uuid, $type)
    {
        $image = \App\Models\Image::where('image_uuid', $uuid)->first();
        return response()->json($image->filePath($type));
    });
    
    //Rates (RateEngine)
    Route::post('/rates/total/hourly/{space_id}', [
        'as' => 'rates.calculate.hourly.total',
        'uses' => 'RateController@calculateSpaceRatesHourly'
    ]);
    
    Route::post('/rates/total/daily/{space_id}', [
        'as' => 'rates.calculate.daily.total',
        'uses' => 'RateController@calculateSpaceRatesDaily'
    ]);
    
    Route::get('/rates/minimum/{space_id}', [
        'as' => 'rates.calculate.minimum',
        'uses' => 'RateController@calculateSpaceRatesMinimum'
    ]);
    
    //Booking (BookingEngine)
    Route::post('/booking/hourly/{space_id}', [
        'as' => 'booking.hourly',
        'uses' => 'BookingController@validateBookingHourly'
    ]);
    
    Route::post('/booking/daily/{space_id}', [
        'as' => 'booking.daily',
        'uses' => 'BookingController@validateBookingDaily'
    ]);

    Route::get('spaces/{space_id?}/capacityprices', function($spaceId = null)
    {
        $capacityPrices = !is_null($spaceId) || is_numeric($spaceId) ?
            \App\Models\Capacityprice::where('space_id', $spaceId)->get() :
            [];
        return response()->json(['data' => $capacityPrices]);
    });
});