<?php

namespace App\Models;

/**
 * App\Models\Addon
 *
 * @property-read \App\Models\User $createdby
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @mixin \Eloquent
 */
class Addon extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'Addon';
}
