<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 22/09/2016
 * Time: 1:30 PM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Traits\Auditable;
use OwenIt\Auditing\AuditingTrait;

/***
 * Base Model class so we can inherit extra features
 * Class BaseModel
 * @package App\Models
 */
/**
 * App\Models\BaseModel
 *
 * @property-read \App\Models\User $createdby
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @mixin \Eloquent
 */
class BaseModel extends Model
{
    use Auditable, AuditingTrait;

    /**
     * Fields which have to be convert to null in case of empty input
     */
    protected $nullable = [];


    /**
     * For Auditable trait
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function createdby()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }

    /**
     * For Auditable trait
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function updatedby()
    {
        return $this->belongsTo(User::class, 'updated_by_id');
    }

    /**
     * Listen for save event.
     */
    protected static function boot()
    {
        parent::boot();
        static::saving(function ($model) {
            $model->setNullables();
        });
    }

    /**
     * Set empty nullable fields to null
     *
     * @param object $model
     */
    protected function setNullables()
    {
        foreach ($this->nullable as $field) {
            if (!is_numeric($this->attributes[$field]) && empty($this->attributes[$field])) {
                $this->attributes[$field] = null;
            }
        }
    }
}