<?php

namespace App\Models;

use App\Models\Interfaces\IAuthorisedModelAccess;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Http\Request;

/**
 * App\Models\Building
 *
 * @property integer $id
 * @property string $name
 * @property string $street_address_1
 * @property string $street_address_2
 * @property integer $locality_id
 * @property integer $region_id
 * @property integer $country_id
 * @property string $postcode
 * @property string $public_slug
 * @property string $private_slug
 * @property string $other_services
 * @property string $direct_url
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $logoImage
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $headerImage
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Building[] $floors
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $images
 * @property-read \App\Models\Country $country
 * @property-read \App\Models\Region $region
 * @property-read \App\Models\Locality $locality
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Space[] $spaces
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereStreetAddress1($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereStreetAddress2($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereLocalityId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereRegionId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereCountryId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building wherePostcode($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building wherePublicSlug($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building wherePrivateSlug($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereCateringInformation($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building leftJoinBuildingImage($id)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building leftJoinBuildingImageWithImageType($id, $imagetype)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Building findSimilarSlugs($model, $attribute, $config, $slug)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space getAllAuthorised($user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Host[] $hosts
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\User[] $hostadmins
 * @property-read \App\Models\User $createdby
 */
class Building extends BaseModel implements IAuthorisedModelAccess
{
    use Sluggable;
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'buildings';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name','street_address_1','street_address_2','locality_id','region_id','country_id','postcode','public_slug','private_slug','other_services','direct_url'];

    protected $appends = ['display_name', 'full_address'];

    public function sluggable()
    {
        return [
            'public_slug' => [
                'source' => ['name', 'street_address_1', 'locality.name', 'locality.region.name', 'locality.region.country.name']
            ]
        ];
    }

    public static $BUILDING_VALIDATION_RULES = [
        'name' => 'required',
        'street_address_1' => 'required',
        'postcode' => 'required',
        'locality_id' => 'required',
        'region_id' => 'required',
        'country_id' => 'required',
        'direct_url' => 'required'
    ];

    public static function getInputValues(Request $request) {
        $input = array(
            'name' => $request->input('name'),
            'street_address_1' => $request->input('street_address_1'),
            'street_address_2' => $request->input('street_address_2'),
            'locality_id' => $request->input('locality_id'),
            'region_id' => $request->input('region_id'),
            'country_id' => $request->input('country_id'),
            'postcode' => $request->input('postcode'),
            'logo_image' => $request->file('logo_image'),
            'header_image' => $request->file('header_image'),
            'other_services' => $request->input('other_services'),
            'direct_url' => $request->input('direct_url')
        );
        return $input;
    }

    public function scopeLeftJoinBuildingImage($query, $id)
    {
        return $query->leftJoin('building_image', 'buildings.id', '=', 'building_image.building_id')->where('building_id',$id);
    }

    public function scopeLeftJoinBuildingImageWithImageType($query, $id, $imagetype)
    {
        return $query->leftJoin('building_image', 'buildings.id', '=', 'building_image.building_id')->where('building_id',$id)->where('imagetype_id',$imagetype);
    }


    public function logoImage()
    {
        return $this->belongsToMany('App\Models\Image', "building_image")->wherePivot("imagetype_id", '1');
    }

    public function headerImage()
    {
        return $this->belongsToMany('App\Models\Image', "building_image")->wherePivot("imagetype_id", '2');
    }

    public function images()
    {
        return $this->belongsToMany('App\Models\Image', 'building_image', 'building_id', 'image_id')->withPivot('imagetype_id')->withTimestamps();
    }

    public function country()
    {
        return $this->belongsTo('App\Models\Country');
    }

    public function region()
    {
        return $this->belongsTo('App\Models\Region');
    }

    public function locality()
    {
        return $this->belongsTo('App\Models\Locality');
    }

    public function spaces()
    {
        return $this->hasMany('App\Models\Space');
    }

    public function activeSpaces()
    {
        return $this->hasMany('App\Models\Space')->where('active', true);
    }

    /**
     * Hosts assigned to this building
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function hosts()
    {
        return $this->belongsToMany('App\Models\Host')->withPivot('id')->withTimestamps();
    }

    /**
     * Users assigned to this building
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function hostadmins($host_id)
    {
        return $this->belongsToMany('App\Models\User', 'building_user', 'building_id', 'user_id')->wherePivot('host_id', $host_id)->withPivot('host_user_id', 'building_host_id')->withTimestamps();
    }

    public function floors()
    {
        return $this->hasMany('App\Models\Floor');
    }


    /**
     * Returns a query builder that constrains the query to return all records of the model that the $user has access to, based on the $context of the query.
     * The query context can be either PUBLIC or ADMIN, and refers to the section of the site that the query is being run for.
     * @param $query
     * @param $user
     * @param int $context
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeGetAllAuthorised($query, $user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
    {
        $columnArray = $columnArray == null ? ['buildings.*'] : $columnArray;

        //In the public context or if the user is an admin, don't constrain the query at all
        if($context == IAuthorisedModelAccess::CONTEXT_PUBLIC)
        {
            $queryBuilder = Building::newQuery()->select($columnArray);
        }
        else if($context == IAuthorisedModelAccess::CONTEXT_ADMIN)
        {
            if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
            {
                $queryBuilder = Building::newQuery()->select($columnArray);
            }
            else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
            {
                //Join spaces to the building_host pivot and the building_user pivot and check that the user is assigned to the building through a host
                $queryBuilder = Building::join('building_user', function($join) {
                    $join->on('buildings.id', '=', 'building_user.building_id');
                })->where('building_user.user_id', $user->id)->select($columnArray);
            }
        }

        return $queryBuilder;
    }

    public function getDisplayNameAttribute()
    {
        return !empty($this->name) ? $this->name : $this->full_address;
    }

    public function getFullAddressAttribute()
    {
        return sprintf(
            "%s%s, %s %s",
            $this->street_address_1,
            !empty($this->street_address_2) ? ' ' . $this->street_address_2 : '',
            isset($this->locality) ? $this->locality->name : '',
            $this->postcode
        );
    }
}
