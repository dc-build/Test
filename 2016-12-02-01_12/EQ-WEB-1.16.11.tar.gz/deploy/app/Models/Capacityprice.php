<?php

namespace App\Models;

/**
 * App\Models\Capacityprice
 *
 * @property integer $id
 * @property integer $space_id
 * @property integer $attendees_min
 * @property integer $attendees_max
 * @property float $rate_hour
 * @property float $rate_halfday
 * @property float $rate_day
 * @property float $rate_month
 * @property float $rate_afterhours
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereSpaceId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereAttendeesMin($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereAttendeesMax($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereRateHour($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereRateHalfday($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereRateDay($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereRateMonth($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereRateAfterhours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Capacityprice whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property-read \App\Models\User $createdby
 */
class Capacityprice extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'capacityprices';

    protected $fillable = [
        'attendees_min',
        'attendees_max',
        'rate_hour',
        'rate_halfday',
        'rate_day',
        'rate_month',
        'rate_afterhours'
    ];


    public static $CAPACITY_PRICE_VALIDATION_RULES = [
        'attendees_min' => 'required|integer|min:1',
        'attendees_max' => 'required|integer|min:1',
        'rate_hour' => 'numeric',
        'rate_halfday' => 'numeric',
        'rate_day' => 'numeric',
        'rate_month' => 'numeric',
        'rate_afterhours' => 'numeric'
    ];
}
