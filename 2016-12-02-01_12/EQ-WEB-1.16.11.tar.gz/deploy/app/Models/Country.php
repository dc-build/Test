<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * App\Models\Country
 *
 * @property integer $id
 * @property string $name
 * @property string $nicename
 * @property string $iso_code
 * @property string $iso3
 * @property integer $numcode
 * @property integer $phonecode
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property boolean $preferred
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereNicename($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereIsoCode($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereIso3($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereNumcode($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country wherePhonecode($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country wherePreferred($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Country withRegions($withRegionsOnly = false)
 * @mixin \Eloquent
 */
class Country extends Model
{

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'countries';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'iso_code'];

    public static $COUNTRY_VALIDATION_RULES = [
        'name' => 'required',
        'iso_code' => 'required'
    ];

    public static function getInputValues(Request $request)
    {
        $input = [
            'name' => $request->input('name'),
            'iso_code' => $request->input('iso_code')
        ];
        return $input;
    }


    public function scopeWithRegions($query, $withRegionsOnly = false)
    {
        if ($withRegionsOnly)
        {
            $query = $query->join('regions', 'countries.id', '=', 'regions.country_id')->distinct();
        }

        return  $query->orderBy('preferred', 'desc')->orderBy('nicename', 'asc');
    }

}
