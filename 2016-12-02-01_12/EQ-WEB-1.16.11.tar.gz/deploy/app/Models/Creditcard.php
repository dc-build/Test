<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Creditcard
 *
 * @property-read \App\Models\User $user
 * @mixin \Eloquent
 * @property integer $id
 * @property integer $user_id
 * @property string $card_name
 * @property string $name_on_card
 * @property string $last_four
 * @property string $expiry_month
 * @property string $expiry_year
 * @property string $gateway_customer_id
 * @property string $gateway_card_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereUserId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereCardName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereNameOnCard($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereLastFour($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereExpiryMonth($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereExpiryYear($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereGatewayCustomerId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Creditcard whereUpdatedAt($value)
 */
class Creditcard extends Model
{
    protected $table = 'creditcards';
    
    protected $fillable = [
        'user_id',
        'card_name',
        'name_on_card',
        'last_four',
        'expiry_month',
        'expiry_year',
        'gateway_customer_id',
        'gateway_card_id'
    ];
    
    public static $VALIDATION_RULES = [
        'card_name' => 'required',
        'name_on_card' => 'required',
        'expiry_month' => 'required',
        'expiry_year' => 'required',
        'gateway_customer_id' => 'required'
    ];

    public static $VALIDATION_MESSAGES = [
        
    ];

    public function user()
    {
        return $this->belongsTo('App\Models\User');
    }

    public function hosts()
    {
        return $this->hasMany('App\Models\Host', 'creditcard_id', 'id');
    }
}
