<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


/**
 * App\Models\Floor
 *
 * @property integer $id
 * @property integer $building_id
 * @property string $name
 * @property integer $order
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\Building $building
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereBuildingId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereOrder($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Floor whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class Floor extends BaseModel
{
    protected $table = 'floors';
    
    protected $fillable = [
        'building_id',
        'name',
        'order'
    ];
    
    public static $VALIDATION_RULES = [
        'building_id' => 'required',
        'name' => 'required',
        'order' => 'required'
    ];

    public static $VALIDATION_MESSAGES = [
        
    ];
    
    public function building()
    {
        return $this->belongsTo('App\Models\Building');
    }
}
