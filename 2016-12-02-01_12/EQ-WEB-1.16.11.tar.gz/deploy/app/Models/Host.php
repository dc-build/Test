<?php

namespace App\Models;

use App\Models\Interfaces\IAuthorisedModelAccess;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\Host
 *
 * @property integer $id
 * @property string $company_name
 * @property string $company_abn
 * @property string $street_address_1
 * @property string $street_address_2
 * @property string $postcode
 * @property string $contact_name
 * @property string $contact_email
 * @property string $contact_phone
 * @property string $contact_position
 * @property integer $locality_id
 * @property integer $region_id
 * @property integer $country_id
 * @property integer $creditcard_id
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $images
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $logoImage
 * @property-read \App\Models\Creditcard $creditcard
 * @property-read \App\Models\Country $country
 * @property-read \App\Models\Region $region
 * @property-read \App\Models\Locality $locality
 * @property-read \App\Models\User $createdby
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereCompanyName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereCompanyAbn($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereStreetAddress1($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereStreetAddress2($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host wherePostcode($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereContactName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereContactEmail($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereContactPhone($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereContactPosition($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereLocalityId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereRegionId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereCountryId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereCreditcardId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host whereDeletedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host leftJoinHostImage($id)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Host leftJoinHostImageWithImageType($query, $id, $imagetype)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space getAllAuthorised($user, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\User[] $hostadmins
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Building[] $buildings
 * @property-read mixed $display_name
 */
class Host extends BaseModel implements IAuthorisedModelAccess
{
    //TODO - Move this into BaseModel???
    use SoftDeletes;

    protected $table = 'hosts';
    protected $nullable = [];

    protected $fillable = [
        'company_name',
        'company_abn',
        'street_address_1',
        'street_address_2',
        'contact_name',
        'contact_email',
        'contact_phone',
        'contact_position',
        'locality_id',
        'region_id',
        'country_id',
        'postcode',
        'creditcard_id'
    ];

    protected $appends = ['display_name'];

    public static $VALIDATION_RULES = [
        'company_name' => 'required',
        'locality_id' => 'required',
        'region_id' => 'required',
        'country_id' => 'required|integer',
        'contact_email' => 'email',
        'contact_phone' => 'regex:/^[+0-9 ]+$/'
    ];
    
    public static $VALIDATION_MESSAGES = [
        'company_name.required' => 'A company name is required',
        'country_id.required' => 'A country is required',
        'region_id.required' => 'A region is required',
        'locality_id.required' => 'A locality is required',
        'locality_id.integer' => 'Please choose a locality from the list',
        'contact_email.email' => 'The contact email must be a valid email address',
        'contact_phone.regex' => 'The contact phone number must be a valid phone number'
    ];
    
    public function scopeLeftJoinHostImage($query, $id)
    {
        return $query->leftJoin('host_image', 'hosts.id', '=', 'host_image.host_id')->where('host_id',$id);
    }

    public function scopeLeftJoinHostImageWithImageType($query, $id, $imagetype)
    {
        return $query->leftJoin('host_image', 'hosts.id', '=', 'host_image.host_id')->where('host_id',$id)->where('imagetype_id', $imagetype);
    }

    public function images()
    {
        return $this->belongsToMany('App\Models\Image', 'host_image', 'host_id', 'image_id')->withPivot('imagetype_id')->withTimestamps();
    }

    public function logoImage()
    {
        return $this->belongsToMany('App\Models\Image', "host_image")->wherePivot("imagetype_id", '1');
    }
    
    public function profileImage()
    {
        return $this->belongsToMany('App\Models\Image', "host_image")->wherePivot("imagetype_id", '6');
    }


    public function creditcard()
    {
        return $this->belongsTo('App\Models\Creditcard');
    }

    /**
     * The users who have been added as admins of this host
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function hostadmins()
    {
        return $this->belongsToMany('App\Models\User')->withPivot('id')->withTimestamps();
    }

    /**
     * Buildings that this host belongs too
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function buildings()
    {
        return $this->belongsToMany('App\Models\Building')->withPivot('id')->withTimestamps();
    }


    public function country()
    {
        return $this->belongsTo('App\Models\Country');
    }

    public function region()
    {
        return $this->belongsTo('App\Models\Region');
    }

    public function locality()
    {
        return $this->belongsTo('App\Models\Locality');
    }

    public function createdby()
    {
        return $this->belongsTo('App\Models\User', 'created_by_id');
    }

    public function updatedby()
    {
        return $this->belongsTo('App\Models\User', 'updated_by_id');
    }

    public function getDisplayNameAttribute()
    {
        return $this->name ?: ($this->company_name ?: $this->contact_name);
    }

    /**
     * Returns a query builder that constrains the query to return all records of the model that the $user has access to, based on the $context of the query.
     * The query context can be either PUBLIC or ADMIN, and refers to the section of the site that the query is being run for.
     * @param $query
     * @param $user
     * @param int $context
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeGetAllAuthorised($query, $user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
    {
        $columnArray = $columnArray == null ? ['hosts.*'] : $columnArray;

        //In the public context or if the user is an admin, don't constrain the query at all
        if($context == IAuthorisedModelAccess::CONTEXT_PUBLIC)
        {
            $queryBuilder = Host::newQuery()->select($columnArray);
        }
        else if($context == IAuthorisedModelAccess::CONTEXT_ADMIN)
        {
            if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
            {
                $queryBuilder = Host::newQuery()->select($columnArray);
            }
            else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
            {
                //Hostadmins can only see Hosts they are attached to
                $queryBuilder = Host::join('host_user', 'hosts.id', '=', 'host_user.host_id')
                    ->where('host_user.user_id', $user->id)->select($columnArray);
            }
        }

        return $queryBuilder;
    }
}
