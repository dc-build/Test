<?php

namespace App\Models;

use App\Models\Traits\Auditable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use OwenIt\Auditing\AuditingTrait;

/**
 * App\Models\Image
 *
 * @property integer $id
 * @property string $image_uuid
 * @property string $caption
 * @property integer $file_size
 * @property string $file_ext
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereImageUuid($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereCaption($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereFileSize($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereFileExt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Image whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property-read \App\Models\User $createdby
 */
class Image extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'images';

    protected $appends = ['url'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['image_uuid','caption','file_size','file_ext'];

    public function filePath($type = '')
    {
        $uploadDir = '/images/uploads';
        $filename = sprintf('%s/%s.%s', $uploadDir, $this->image_uuid, $this->file_ext);
        return file_exists(public_path($filename)) ? $filename : '/images/missing_' . $type . '.png';
    }

    public function getUrlAttribute()
    {
        $uploadDir = '/images/uploads';
        return sprintf('%s/%s.%s', $uploadDir, $this->image_uuid, $this->file_ext);
    }

}
