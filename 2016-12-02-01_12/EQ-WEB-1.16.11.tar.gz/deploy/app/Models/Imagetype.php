<?php

namespace App\Models;

use App\Models\Traits\Auditable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use OwenIt\Auditing\AuditingTrait;

/**
 * App\Models\Imagetype
 *
 * @property integer $id
 * @property string $name
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\User $createdby
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Imagetype whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Imagetype whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Imagetype whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Imagetype whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Imagetype whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Imagetype whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class Imagetype extends Model 
{
    use Auditable, AuditingTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'imagetypes';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name'];
    
    public static $VALIDATION_RULES = [
        'name' => 'required'
    ];

    public static $VALIDATION_MESSAGES = [
        'name.required' => 'An image type name is required',
        'name.unique' => 'That name is taken, please enter a new image type name'
    ];
    
    public function createdby()
    {
        return $this->belongsTo('App\Models\User', 'created_by_id');
    }
    
    public function updatedby()
    {
        return $this->belongsTo('App\Models\User', 'updated_by_id');
    }

}
