<?php

    namespace App\Models\Interfaces;
/**
 * Created by PhpStorm.
 * User: carpo
 * Date: 20/11/2016
 * Time: 5:50 AM
 */

/**
 * Interface which defines methods to access models in an authorised way within the Admin section of the site
 *
 * Interface IAuthorisedModelAccess
 * @package App\Services
 */
interface IAuthorisedModelAccess
{
    const CONTEXT_PUBLIC = 1;
    const CONTEXT_ADMIN = 2;

    /**
     * Returns a query builder that constrains the query to return all records of the model that the $user has access to, based on the $context of the query.
     * The query context can be either PUBLIC or ADMIN, and refers to the section of the site that the query is being run for.
     * @param $query
     * @param $user
     * @param int $context
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function  scopeGetAllAuthorised($query, $user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN);
}