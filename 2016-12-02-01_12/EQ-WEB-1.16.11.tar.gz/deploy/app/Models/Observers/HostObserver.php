<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 1/11/2016
 * Time: 11:48
 */

namespace App\Models\Observers;

use App\Models\Host;
use App\Models\Image;
use App\Models\Imagetype;
use App\Services\IImageService;

class HostObserver
{
    protected $imageService;
    protected $imageInputs = [
        'logo_image' => 'logo',
        'profile_image' => 'profile'
    ];

    public function __construct(IImageService $imageService)
    {
        $this->imageService = $imageService;
    }


    public function saved(Host $model)
    {
        $path = base_path('public/images/uploads/');

        $images = request()->files->all();
        foreach($images as $imageInput => $file)
        {
            $imageTypeName = $this->imageInputs[$imageInput];
            if (!empty($file))
            {
                try
                {
                    $imageType = Imagetype::where('name', $imageTypeName)->first();
                    $image_id = $this->imageService->uploadImage($file, [], $path, new Image());

                    $existingImage = Host::LeftJoinHostImageWithImageType($model->id, $imageType->id, $imageTypeName)->first();
                    if (!is_null($existingImage))
                    {
                        $model->images()->detach($existingImage->image_id);
                    }

                    $model->images()->attach($image_id, ['imagetype_id' => $imageType->id]);
                    request()->files->remove($imageInput);
                }
                catch (\Exception $e)
                {
                    throw $e;
                }
            }
        }

        return true;
    }
}
