<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 19/10/2016
 * Time: 14:52
 */

namespace App\Models\Observers;

use App\Models\Locality;
use App\Models\Region;

class LocalityObserver
{
    public function saving(Locality $model)
    {
        if (!is_numeric($model->region_id))
        {
            $data = request()->all();
            try
            {
                $region = Region::create(
                    [
                        'name' => $data['region_id'],
                        'country_id' => $data['region_country_id']
                    ]
                );
                if (!is_null($region))
                {
                    $model->region_id = $region->id;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (\Exception $e)
            {
                throw $e;
            }
        }
        return true;
    }
}