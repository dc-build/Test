<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 15/11/2016
 * Time: 12:34
 */

namespace App\Models\Observers;

use App\Services\IImageService;
use App\Models\Space;
use App\Models\Imagetype;
use App\Models\Image;

class SpaceObserver
{
    protected $imageService;
    protected $imageInputs = [
        'thumb_image' => 'thumbnail',
        'gallery_images' => 'gallery'
    ];

    public function __construct(IImageService $imageService)
    {
        $this->imageService = $imageService;
    }

    public function saved(Space $model)
    {
        $this->createAndUploadImages($model);
        return true;
    }

    private function createAndUploadImages(Space $model)
    {
        $path = base_path('public/images/uploads/');

        foreach ($this->imageInputs as $imageInput => $imageTypeName)
        {
            $file = request()->file($imageInput);
            if (!empty($file))
            {
                try
                {
                    $imageType = Imagetype::where('name', $imageTypeName)->first();

                    $files = $file;
                    if (!is_array($files))
                    {
                        $existingImage = Space::LeftJoinSpaceImageWithImageType($model->id, $imageType->id)
                                              ->first();
                        if (!is_null($existingImage))
                        {
                            $model->images()->detach($existingImage->image_id);
                        }

                        // make the $files an array
                        $files = [$file];
                    }
                    // at this point, $files WILL be an array
                    $files =  array_filter($files); // make sure we don't get crap like: array( 0 => NULL )
                    foreach ($files as $aFile)
                    {
                        $image_id = $this->imageService->uploadImage($aFile, [], $path, new Image());
                        $model->images()->attach($image_id, ['imagetype_id' => $imageType->id]);
                    }
                }
                catch (\Exception $e)
                {
                    throw $e;
                }
            }
        }
    }

}