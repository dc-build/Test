<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 16/11/2016
 * Time: 9:39 AM
 */

namespace App\Models\Popo;
use App\Models\Transaction;


/**
 * Container for booking details
 *
 * Class BookingDetail
 * @package App\Models\Popo
 */
class BookingDetail
{
    public $event_title = null;
    public $event_description = null;
    public $contact_name = null;
    public $company_name = null;
    public $company_address = null;
    public $company_city = null;
    public $company_postcode = null;
    public $company_state = null;
    public $company_country = null;
    public $purchase_order = null;

    public $payment_transaction_id = null;
    public $cc_name = null;
    public $cc_lastfour = null;
    public $cc_expiry_year = null;
    public $cc_expiry_month = null;
    public $payment_total_amount = null;

    private $transaction = null;
    private $bookingRateDetail = null;

    /**
     * BookingDetail constructor.
     * @param null $event_title
     * @param null $event_description
     * @param string $contact_name
     * @param string $company_name
     * @param string $company_address
     * @param string $company_city
     * @param string $company_postcode
     * @param string $company_state
     * @param string $company_country
     * @param null $purchase_order
     */
    public function __construct(
        $event_title = null,
        $event_description = null,
        $contact_name = null,
        $company_name = null,
        $company_address = null,
        $company_city = null,
        $company_postcode = null,
        $company_state = null,
        $company_country = null,
        $purchase_order = null)
    {
        $this->event_title = $event_title;
        $this->event_description = $event_description;
        $this->contact_name = $contact_name;
        $this->company_name = $company_name;
        $this->company_address = $company_address;
        $this->company_city = $company_city;
        $this->company_postcode = $company_postcode;
        $this->company_state = $company_state;
        $this->company_country = $company_country;
        $this->purchase_order = $purchase_order;
    }

    /**
     * @return Transaction
     */
    public function getTransaction()
    {
        return $this->transaction;
    }

    /**
     * @param Transaction $transaction
     */
    public function setTransaction(Transaction $transaction)
    {
        $this->transaction = $transaction;
    }

    /**
     * @return BookingRateDetail
     */
    public function getBookingRateDetail()
    {
        return $this->bookingRateDetail;
    }

    /**
     * @param BookingRateDetail $bookingRateDetail
     */
    public function setBookingRateDetail(BookingRateDetail $bookingRateDetail)
    {
        $this->bookingRateDetail = $bookingRateDetail;
    }

}