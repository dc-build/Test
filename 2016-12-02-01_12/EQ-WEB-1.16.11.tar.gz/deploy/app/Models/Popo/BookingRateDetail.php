<?php

namespace App\Models\Popo;

use App\Models\Capacityprice;
use App\Models\Space;
use Carbon\Carbon;

/**
 *
 * The RateDetail object contains a breakdown of the rates for a specific booking, based on the rules that
 * have been configured for the Space
 *
 * Class RateDetail
 * @package App\Models\Popo
 */
class BookingRateDetail
{
    protected $totalCost = 0;

    protected $dayDuration = 0;
    protected $halfDayDuration = 0;
    protected $monthDuration = 0;

    //Time Booked
    protected $totalHourlyHours = 0;
    protected $totalHalfDayHours = 0;
    protected $totalAfterHoursHours = 0;
    protected $totalDayHours = 0;
    protected $totalMonthHours = 0;

    protected $bookingStartDateTime;
    protected $bookingEndDateTime;

    //Rates
    protected $ratePerHour = 0.0;
    protected $ratePerHalfDayHour = 0.0;
    protected $ratePerDayHour = 0.0;
    protected $ratePerMonthHour = 0.0;
    protected $ratePerAfterHoursHour = 0.0;

    protected $pricingHourlyEnabled = TRUE;
    protected $pricingHalfdailyEnabled = TRUE;
    protected $pricingDailyEnabled = TRUE;
    protected $pricingMonthlyEnabled = TRUE;


    /**
     * BookingRateDetail constructor
     *
     * Sets the default values from the space
     *
     * @param \App\Models\Space $space
     */
    public function __construct(Space $space, Capacityprice $capacityPrice, $startDateTime, $endDateTime)
    {
        $this->ratePerHour = $capacityPrice->rate_hour;
        $this->ratePerHalfDayHour = $capacityPrice->rate_halfday;
        $this->ratePerDayHour = $capacityPrice->rate_day;
        $this->ratePerMonthHour = $capacityPrice->rate_month;
        $this->ratePerAfterHoursHour = $capacityPrice->rate_afterhours;
        $this->dayDuration = ($space->day_duration / 60);
        $this->halfDayDuration = ($space->day_duration / 2) / 60;
        $this->monthDuration = $space->month_duration;

        $this->bookingStartDateTime = clone $startDateTime;
        $this->bookingEndDateTime = clone $endDateTime;

        $this->pricingHourlyEnabled = $space->pricing_hourly_enabled;
        $this->pricingHalfdailyEnabled = $space->pricing_halfdaily_enabled;
        $this->pricingDailyEnabled = $space->pricing_daily_enabled;
        $this->pricingMonthlyEnabled = $space->pricing_monthly_enabled;
    }


    /**
     * Return the total price
     * @return float|int
     */
    public function totalCost()
    {

        //We will need to put the rules in here that control the special pricing
        //so that any booking less than half a day in hours, cannot cost more than
        //halfaday - eg. Hourly = 100, halfday = 320 so 4 hours should be 320, not 400
        //even though half a day is 5 hours long

        $totalCalc =    $this->hourlyTotalCost() +
                        $this->halfDayTotalCost() +
                        $this->dayTotalCost() +
                        $this->monthTotalCost();

        //Check that the price isn't higher than the next highest chunk price
        if($this->pricingHalfdailyEnabled && $this->totalStandardHours() < $this->halfDayDuration && $totalCalc > $this->maxHalfDayPrice())
        {
            $totalCalc = $this->maxHalfDayPrice();
        }


        if($this->pricingDailyEnabled && ($this->totalStandardHours() > $this->halfDayDuration && $this->totalStandardHours() <= $this->dayDuration) && $totalCalc > $this->maxFullDayPrice())
        {
            $totalCalc = $this->maxFullDayPrice();
        }

        //if monthly pricing is enabled, check that they are not paying more the monthly maximum price
        if($this->pricingMonthlyEnabled && $this->totalStandardHours() > $this->dayDuration)
        {
            $monthCount = ceil($this->totalDays() / $this->monthDuration);
            $maxMonthlyCost = $monthCount * $this->maxMonthPrice();

            if($totalCalc > $maxMonthlyCost)
            {
                $totalCalc = $maxMonthlyCost;
            }
        }

        //TODO Do the daily / monthly check too

        $this->totalCost = $totalCalc + $this->afterHoursTotalCost();

        return $this->totalCost;
    }

    /**
     * @return Carbon
     */
    public function bookingStartDateTime()
    {
        return $this->bookingStartDateTime;
    }

    /**
     * @return Carbon
     */
    public function bookingEndDateTime()
    {
        return $this->bookingEndDateTime;
    }

    /**
     * Returns the total hourly cost
     * @return float|mixed
     */
    public function hourlyTotalCost()
    {
        return round($this->ratePerHour * $this->totalHourlyHours);
    }

    public function halfDayTotalCost()
    {
        return round($this->ratePerHalfDayHour * $this->totalHalfDayHours);
    }

    public function dayTotalCost()
    {
        return round($this->ratePerDayHour * $this->totalDayHours);
    }

    public function monthTotalCost()
    {
        return round($this->ratePerMonthHour * $this->totalMonthHours);
    }

    public function afterHoursTotalCost()
    {
        return round($this->ratePerAfterHoursHour * $this->totalAfterHoursHours);
    }


    /**
     * Set the chunks of time for this booking
     */
    public function setTimeChunks($hours, $halfDayHours = 0, $afterHoursHours = 0, $dayHours = 0, $monthHours = 0)
    {
        $this->totalHourlyHours = $hours;
        $this->totalHalfDayHours = $halfDayHours;
        $this->totalAfterHoursHours = $afterHoursHours;
        $this->totalDayHours = $dayHours;
        $this->totalMonthHours = $monthHours;
    }

    /*********************************************************************
     * Functions to return the time chunks for particular lengths of booking
     *********************************************************************/
    public function totalHourlyHours()
    {
        return $this->totalHourlyHours;
    }

    public function totalHalfDayHours()
    {
        return $this->totalHalfDayHours;
    }

    public function totalAfterHoursHours()
    {
        return $this->totalAfterHoursHours;
    }

    public function totalDayHours()
    {
        return $this->totalDayHours;
    }

    public function totalMonthHours()
    {
        return $this->totalMonthHours;
    }

    /**
     * The total number of booked hours between the standard start and end time of the space. NOTE: This doesn't include after hours.
     * @return int
     */
    public function totalStandardHours()
    {
        return $this->totalHourlyHours() + $this->totalHalfDayHours() + $this->totalDayHours() + $this->totalMonthHours();
    }

    /**
     * The total number of booked hours, including after hours
     * @return int
     */
    public function totalHours()
    {
        return $this->totalHourlyHours() + $this->totalHalfDayHours() + $this->totalDayHours() + $this->totalMonthHours() + $this->totalAfterHoursHours();
    }

    public function totalDays()
    {
        $returnVal = 0;

        if($this->totalHours() >= $this->dayDuration)
        {
            $returnVal = floor($this->totalHours() / $this->dayDuration);
        }
        return $returnVal;
    }

    public function totalMonths()
    {
        if ($this->pricingMonthlyEnabled)
        {
            return $this->totalMonthHours / ($this->monthDuration * $this->dayDuration);
        }
        return 0;
    }

    /*********************************************************************
     * Functions to return the prices for particular lengths of booking
     *********************************************************************/
    public function maxHourPrice()
    {
        return $this->ratePerHour;
    }

    public function maxAfterHoursPrice()
    {
        return $this->ratePerAfterHoursHour;
    }

    public function maxHalfDayPrice()
    {
        return round($this->ratePerHalfDayHour * ($this->dayDuration / 2));
    }

    public function maxFullDayPrice()
    {
        return round($this->ratePerDayHour * $this->dayDuration);
    }

    public function maxMonthPrice()
    {
        return round($this->ratePerMonthHour * $this->dayDuration * $this->monthDuration);
    }

    /*********************************************************************
     * Functions to return the durations
     *********************************************************************/
    public function halfDayDuration()
    {
        return $this->halfDayDuration;
    }

    public function dayDuration()
    {
        $this->dayDuration;
    }

    public function monthDuration()
    {
        $this->monthDuration;
    }
}
