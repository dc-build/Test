<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 18/11/2016
 * Time: 3:31 PM
 */

namespace App\Models\Popo;
use App\Models\Transaction;

/**
 * Class BookingRequest
 * @package App\Models\Popo
 */
class BookingRequest
{
    private $bookingDetail = null;
    private $bookingRateDetail = null;
    private $transaction = null;

    /**
     * @return BookingDetail
     */
    public function getBookingDetail()
    {
        return $this->bookingDetail;
    }

    /**
     * @param BookingDetail $bookingDetail
     */
    public function setBookingDetail(BookingDetail $bookingDetail)
    {
        $this->bookingDetail = $bookingDetail;
    }

    /**
     * @return Transaction
     */
    public function getTransaction()
    {
        return $this->transaction;
    }

    /**
     * @param Transaction $transaction
     */
    public function setTransaction(Transaction $transaction)
    {
        $this->transaction = $transaction;
    }

    /**
     * @return BookingRateDetail
     */
    public function getBookingRateDetail()
    {
        return $this->bookingRateDetail;
    }

    /**
     * @param BookingRateDetail $bookingRateDetail
     */
    public function setBookingRateDetail(BookingRateDetail $bookingRateDetail)
    {
        $this->bookingRateDetail = $bookingRateDetail;
    }
}