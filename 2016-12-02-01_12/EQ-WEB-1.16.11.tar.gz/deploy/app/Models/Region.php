<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

/**
 * App\Models\Region
 *
 * @property integer $id
 * @property integer $country_id
 * @property string $name
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\Country $country
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Region whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Region whereCountryId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Region whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Region whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Region whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Region withLocalities($withLocalities = true)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Region regionsForCountry($country_id = null)
 * @mixin \Eloquent
 */
class Region extends Model
{

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'regions';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'country_id'];

    public static $REGION_VALIDATION_RULES = [
        'name' => 'required',
        'country_id' => 'required'
    ];

    public static function getInputValues(Request $request)
    {
        $input = [
            'name' => $request->input('name'),
            'country_id' => $request->input('country_id')
        ];
        return $input;
    }

    public function country()
    {
        return $this->belongsTo('App\Models\Country');
    }

    public function scopeWithLocalities($query, $withLocalities = true)
    {
        return $withLocalities ? $query->join('localities', 'regions.id', '=', 'localities.region_id')->distinct() : $query;
    }

    public function scopeRegionsForCountry($query, $country_id = null)
    {
        return !is_null($country_id) ? $query->where('country_id', $country_id) : $query;
    }
}
