<?php

namespace App\Models;

use App\Models\Traits\Auditable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use OwenIt\Auditing\AuditingTrait;

/**
 * App\Models\Role
 *
 * @property integer $id
 * @property string $name
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\User[] $users
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Role whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Role whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Role whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Role whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Role whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Role whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property-read \App\Models\User $createdby
 */
class Role extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'roles';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name'];
    
    public static $ROLE_VALIDATION_RULES = [
        'name' => 'required'
    ];
    
    public static function getInputValues(Request $request) {
        $input = array(
            'name' => $request->input('name')
        );
        return $input;
    }

    public function users()
    {
        return $this->belongsToMany('App\Models\User');
    }

}
