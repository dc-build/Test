<?php

namespace App\Models;

use App\Models\Interfaces\IAuthorisedModelAccess;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Helpers\Form;
use Illuminate\Http\Request;

/**
 * App\Models\Space
 *
 * @property integer $id
 * @property integer $host_id
 * @property integer $building_id
 * @property integer $floor_id
 * @property string $public_slug
 * @property string $private_slug
 * @property string $room_number
 * @property string $room_name
 * @property integer $max_capacity
 * @property string $description
 * @property boolean $active
 * @property boolean $is_available_mon
 * @property boolean $is_available_tue
 * @property boolean $is_available_wed
 * @property boolean $is_available_thu
 * @property boolean $is_available_fri
 * @property boolean $is_available_sat
 * @property boolean $is_available_sun
 * @property boolean $is_available_afterhours
 * @property string $day_start_time
 * @property integer $day_duration
 * @property integer $month_duration
 * @property integer $after_hours_duration
 * @property integer $prep_time_before
 * @property integer $prep_time_after
 * @property integer $booking_window_min
 * @property integer $booking_window_max
 * @property boolean $pricing_hourly_enabled
 * @property boolean $pricing_halfdaily_enabled
 * @property boolean $pricing_daily_enabled
 * @property boolean $pricing_monthly_enabled
 * @property string $booking_type
 * @property boolean $payment_creditcard_allowed
 * @property boolean $payment_invoice_allowed
 * @property string $terms
 * @property integer $cancellation_hours
 * @property float $cancellation_percent
 * @property string $currency
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property \Carbon\Carbon $deleted_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Capacityprice[] $capacityprices
 * @property-read \App\Models\Building $building
 * @property-read \App\Models\Floor $floor
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $logoImage
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $headerImage
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $thumbImage
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $images
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Spacetype[] $spacetypes
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Spaceuse[] $spaceuses
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Spacefacility[] $spacefacilities
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Spaceconfiguration[] $spaceconfigurations
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereHostId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereBuildingId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereFloorId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePublicSlug($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePrivateSlug($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereRoomNumber($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereRoomName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereMaxCapacity($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereDescription($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereActive($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableMon($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableTue($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableWed($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableThu($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableFri($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableSat($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableSun($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereIsAvailableAfterhours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereDayStartTime($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereDayDuration($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereMonthDuration($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereAfterHoursDuration($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePrepTimeBefore($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePrepTimeAfter($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereBookingWindowMin($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereBookingWindowMax($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePricingHourlyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePricingHalfdailyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePricingDailyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePricingMonthlyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereBookingType($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePaymentCreditcardAllowed($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space wherePaymentInvoiceAllowed($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereTerms($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereCancellationHours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereCancellationPercent($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereCurrency($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space whereDeletedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space active()
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Blacklistdate[] $blacklistdates
 * @property-read \App\Models\Host $host
 * @property-read \App\Models\User $createdby
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space hasSpacetype($spacetype)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space hasPricingEnabled($pricing)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space search($term)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space hasFacilities($facilities = array(), $cardinality = 'all')
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Image[] $galleryImages
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space leftJoinSpaceImageWithImageType($id, $imagetype)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space getAllAuthorised($user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
 */
class Space extends BaseModel implements IAuthorisedModelAccess
{
    Use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'spaces';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'host_id',
        'building_id',
        'floor_id',
        'room_number',
        'room_name',
        'description',
        'max_capacity',
        'active',
        'is_available_mon',
        'is_available_tue',
        'is_available_wed',
        'is_available_thu',
        'is_available_fri',
        'is_available_sat',
        'is_available_sun',
        'is_available_afterhours',
        'day_start_time',
        'day_duration',
        'month_duration',
        'after_hours_duration',
        'prep_time_before',
        'prep_time_after',
        'booking_window_min',
        'booking_window_max',
        'booking_type',
        'payment_creditcard_allowed',
        'payment_invoice_allowed',
        'terms',
        'cancellation_hours',
        'cancellation_percent',
        'currency',
        'pricing_hourly_enabled',
        'pricing_halfdaily_enabled',
        'pricing_daily_enabled',
        'pricing_monthly_enabled'
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    protected $appends = ['max_capacity', 'min_capacity'];

    /**
     * Get the Spaces can have many Capacity prices configured
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function capacityprices()
    {
        return $this->hasMany('App\Models\Capacityprice');
    }

    public function blacklistdates()
    {
        return $this->hasMany('App\Models\Blacklistdate');
    }


    public static $SPACE_VALIDATION_RULES = [
        'host_id' => 'required',
        'building_id' => 'required',
        'floor_id' => 'required',
        'room_name' => 'required',
        'active' => 'availability|capacityprices|payment_options|pricing_period',
        'day_start_time' => 'required',
        'day_duration' => 'required',
        'month_duration' => 'required',
        'booking_type' => 'required',
        'currency' => 'required',
        'payment_invoice_allowed' => 'requires_creditcard'
    ];

    public static $SPACE_VALIDATION_MESSAGES = [
        'host_id.required' => 'Please select a Host',
        'building_id.required' => 'Please select a Building',
        'floor_id.required' => 'Please select a Floor',
        'room_name.required' => 'Please enter a name for the Space',
        'active.availability' => 'The space must be available at least one day or after hours before the it can be active',
        'active.capacityprices' => 'Please check that capacity prices have valid attendee ranges and that there is at least one non-zero rate.',
        'active.payment_options' => 'A payment option must be selected',
        'active.pricing_period' => 'At least one pricing period must be selected.',
        'day_start_time.required' => 'Please specify time of day from which the Space is available',
        'day_duration.required' => 'Please specify the number of hours that the Space is available during the day',
        'month_duration.required' => 'Please specify the number of days during which the Space is available in a month',
        'booking_type.required' => 'Please specify the booking type',
        'currency.required' => 'Please specify the currency accepted for this Space',
        'payment_invoice_allowed.requires_creditcard' => 'Before allowing invoices for this Space the Host must have a registered Credit Card'
    ];

    public static $DEFAULT_VALUES = [
        'is_available_mon' => false,
        'is_available_tue' => false,
        'is_available_wed' => false,
        'is_available_thu' => false,
        'is_available_fri' => false,
        'is_available_sat' => false,
        'is_available_sun' => false,
        'is_available_afterhours' => false,
        'pricing_hourly_enabled' => false,
        'pricing_halfdaily_enabled' => false,
        'pricing_daily_enabled' => false,
        'pricing_monthly_enabled' => false,
        'payment_invoice_allowed' => false,
        'payment_creditcard_allowed' => false
    ];

    // These are values the user *CANNOT/MUST NOT* change
    public static $OVERRIDE_VALUES = [
        'currency' => 'AUD'
    ];

    public function building()
    {
        return $this->hasOne('App\Models\Building', 'id', 'building_id');
    }
    
    public function host()
    {
        return $this->hasOne('App\Models\Host', 'id', 'host_id');
    }
    
    public function floor()
    {
        return $this->hasOne('App\Models\Floor', 'id', 'floor_id');
    }

    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    public function logoImage()
    {
        $imageType = Imagetype::where('name', 'logo')->first();
        return $this->belongsToMany('App\Models\Image', "space_image")->wherePivot("imagetype_id", $imageType->id);
    }

    public function headerImage()
    {
        $imageType = Imagetype::where('name', 'header')->first();
        return $this->belongsToMany('App\Models\Image', "space_image")->wherePivot("imagetype_id", $imageType->id);
    }

    public function thumbImage()
    {
        $imageType = Imagetype::where('name', 'thumbnail')->first();
        return $this->belongsToMany('App\Models\Image', "space_image")->wherePivot("imagetype_id", $imageType->id);
    }

    public function galleryImages()
    {
        $imageType = Imagetype::where('name', 'gallery')->first();
        return $this->belongsToMany('App\Models\Image', "space_image")->wherePivot("imagetype_id", $imageType->id);
    }

    public function images()
    {
        return $this->belongsToMany('App\Models\Image', 'space_image', 'space_id', 'image_id')->withPivot('imagetype_id')->withTimestamps();
    }

    public function spacetypes()
    {
        return $this->belongsToMany('App\Models\Spacetype')->withTimestamps();
    }

    public function spaceuses()
    {
        return $this->belongsToMany('App\Models\Spaceuse')->withTimestamps();
    }

    public function spacefacilities()
    {
        return $this->belongsToMany('App\Models\Spacefacility')->withTimestamps();
    }

    public function spaceconfigurations()
    {
        return $this->belongsToMany('App\Models\Spaceconfiguration')->withTimestamps();
    }

    public function scopeLeftJoinSpaceImageWithImageType($query, $id, $imagetype)
    {
        return $query->leftJoin('space_image', 'spaces.id', '=', 'space_image.space_id')->where('space_id', $id)->where('imagetype_id', $imagetype);
    }

    public function sharedfacilities()
    {
        return $this->spacefacilities()->where('shared', true)->orderBy('name');
    }

    public function spacefeatures()
    {
        return $this->spacefacilities()->where('shared', false)->orderBy('name');
    }

    public function scopeHasSpacetype($query, $spacetype)
    {
        return $query->whereHas('spacetypes', function ($query) use ($spacetype)
        {
            $query->where('id', $spacetype);
        });
    }

    public function scopeHasPricingEnabled($query, $pricing)
    {
        switch ($pricing)
        {
            case 'pricing_daily':
                $query->where(function ($query) use ($pricing)
                {
                    $query->where('pricing_daily_enabled', true);
                });
                break;
            case 'pricing_hourly':
                $query->where(function ($query) use ($pricing)
                {
                    $query->where('pricing_hourly_enabled', true);
                });
                break;
            case 'pricing_monthly':
                $query->where(function ($query) use ($pricing)
                {
                    $query->where('pricing_monthly_enabled', true);
                    $query->orWhere('pricing_daily_enabled', true);
                });
                break;
        }
        return $query;
    }

    public function scopeSearch($query, $term)
    {
        return $query->where('description', 'LIKE', '%' . $term . '%');
    }

    public function scopeHasFacilities($query, $facilities = [], $cardinality = 'all')
    {
        list($operator, $count) = $cardinality == 'all' ? ['=', count($facilities)] : ['>=', 1];

        return $query->whereHas('spacefacilities', function ($query) use ($facilities)
        {
            $query->whereIn('id', $facilities);
        }, $operator, $count);
    }

    /**
     * Returns a query builder that constrains the query to return all records of the model that the $user has access to, based on the $context of the query.
     * The query context can be either PUBLIC or ADMIN, and refers to the section of the site that the query is being run for.
     * @param $query
     * @param $user
     * @param int $context
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeGetAllAuthorised($query, $user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
    {
        $columnArray = $columnArray == null ? ['spaces.*'] : $columnArray;

        //In the public context or if the user is an admin, don't constrain the query at all
        if($context == IAuthorisedModelAccess::CONTEXT_PUBLIC)
        {
            $queryBuilder = Space::newQuery()->select($columnArray);
        }
        else if($context == IAuthorisedModelAccess::CONTEXT_ADMIN)
        {
            if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
            {
                $queryBuilder = Space::newQuery()->select($columnArray);
            }
            else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
            {
                $queryBuilder = Space::join('building_host', function($join) {
                    $join->on('spaces.building_id', '=', 'building_host.building_id')
                        ->on('spaces.host_id', '=', 'building_host.host_id');
                    })
                    ->join('building_user', 'building_user.building_host_id', '=', 'building_host.id')
                    ->where('building_user.user_id', $user->id)->select($columnArray);
            }
        }

        return $queryBuilder;
    }

    public function getMaxCapacityAttribute()
    {
        return $this->capacityprices->max('attendees_max');
    }

    public function getMinCapacityAttribute()
    {
        return $this->capacityprices->min('attendees_min');
    }
}
