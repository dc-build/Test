<?php

namespace App\Models;

use App\Models\Interfaces\IAuthorisedModelAccess;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Spacebooking
 *
 * @property integer $id
 * @property integer $space_id
 * @property integer $booked_by_id
 * @property string $contact_name
 * @property string $company_name
 * @property string $company_address
 * @property string $company_city
 * @property string $company_postcode
 * @property string $company_state
 * @property string $company_country
 * @property string $event_title
 * @property string $event_description
 * @property integer $num_attendees
 * @property string $start_datetime
 * @property string $end_datetime
 * @property integer $configuration_id
 * @property float $total_price
 * @property float $rate_hour
 * @property float $rate_halfday
 * @property float $rate_day
 * @property float $rate_month
 * @property float $rate_afterhours
 * @property string $booking_type
 * @property string $payment_type
 * @property boolean $payment_received
 * @property integer $booked_total_hourly_hours
 * @property integer $booked_total_halfday_hours
 * @property integer $booked_total_day_hours
 * @property integer $booked_total_month_hours
 * @property integer $booked_total_afterhours_hours
 * @property integer $space_halfday_duration
 * @property integer $space_day_duration
 * @property integer $space_month_duration
 * @property boolean $space_pricing_hourly_enabled
 * @property boolean $space_pricing_halfdaily_enabled
 * @property boolean $space_pricing_daily_enabled
 * @property boolean $space_pricing_monthly_enabled
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\Space $spaces
 * @property-read \App\Models\User $users
 * @property-read \App\Models\Spaceconfiguration $spaceconfigurations
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpaceId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereBookedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereContactName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCompanyName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCompanyAddress($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCompanyCity($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCompanyPostcode($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCompanyState($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCompanyCountry($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereEventTitle($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereEventDescription($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereNumAttendees($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereStartDatetime($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereEndDatetime($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereConfigurationId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereTotalPrice($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereRateHour($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereRateHalfday($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereRateDay($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereRateMonth($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereRateAfterhours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereBookingType($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking wherePaymentType($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking wherePaymentReceived($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereBookedTotalHourlyHours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereBookedTotalHalfdayHours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereBookedTotalDayHours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereBookedTotalMonthHours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereBookedTotalAfterhoursHours($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpaceHalfdayDuration($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpaceDayDuration($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpaceMonthDuration($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpacePricingHourlyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpacePricingHalfdailyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpacePricingDailyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereSpacePricingMonthlyEnabled($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property integer $prep_time_before
 * @property integer $prep_time_after
 * @property-read \App\Models\User $createdby
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking wherePrepTimeBefore($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking wherePrepTimeAfter($value)
 * @property string $purchase_order
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Transaction[] $transactions
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spacebooking wherePurchaseOrder($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space getAllAuthorised($user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
 */
class Spacebooking extends BaseModel implements IAuthorisedModelAccess
{
    protected $table = 'spacebookings';

    protected $fillable = [
        'space_id',
        'booked_by_id',
        'contact_name',
        'company_name',
        'company_address',
        'company_city',
        'company_postcode',
        'company_state',
        'company_country',
        'event_title',
        'event_description',
        'num_attendees',
        'start_datetime',
        'end_datetime',
        'configuration_id',
        'total_price',
        'rate_hour',
        'rate_halfday',
        'rate_day',
        'rate_month',
        'rate_afterhours',
        'booking_type',
        'payment_type',
        'payment_received',
        'booked_total_hourly_hours',
        'booked_total_halfday_hours',
        'booked_total_day_hours',
        'booked_total_month_hours',
        'booked_total_afterhours_hours',
        'space_halfday_duration',
        'space_day_duration',
        'space_month_duration',
        'space_pricing_hourly_enabled',
        'space_pricing_halfdaily_enabled',
        'space_pricing_daily_enabled',
        'space_pricing_monthly_enabled',
        'purchase_order',
        'spacebookingscol'
    ];

    public $appends = ['cancellation_fee'];

    public static $EDIT_VALIDATION_RULES = [
        'space_id' => 'required',
        'booked_by_id' => 'required'
    ];
    
    public static $VALIDATION_RULES = [
        'space_id' => 'required',
        'booked_by_id' => 'required',
        'num_attendees' => 'required',
        'start_datetime' => 'required',
        'booking_type' => 'required',
        'payment_received' => 'required',
        'space_pricing_hourly_enabled' => 'required',
        'space_pricing_halfdaily_enabled' => 'required',
        'space_pricing_daily_enabled' => 'required',
        'space_pricing_monthly_enabled' => 'required'
    ];

    public static $VALIDATION_MESSAGES = [
        'num_attendees.required' => 'Number of Attendees is required',
        'time_from.required' => 'Please specify start time',
        'time_to.required' => 'Please specify end time',
        'date_from.required' => 'Please specify start date',
        'date_to.required' => 'Please specify end date'
    ];
    
    public static $BOOKING_HOURLY_VALIDATION_RULES = [
        'num_attendees' => 'required',
        'space_configuration' => 'required',
        'event_title' => 'required',
        'payment_type' => 'required',
        'date' => 'required',
        'time_from' => 'required',
        'time_to' => 'required'
    ];
    
    public static $BOOKING_DAILY_VALIDATION_RULES = [
        'num_attendees' => 'required',
        'space_configuration' => 'required',
        'event_title' => 'required',
        'payment_type' => 'required',
        'date_from' => 'required',
        'date_to' => 'required'
    ];
    
    public static $BOOKING_CREDITCARD_VALIDATION_RULES = [
        'stripeToken' => 'required'
    ];
    
    public static $BOOKING_INVOICE_VALIDATION_RULES = [
        'contact_name' => 'required',
        'company_name' => 'required',
        'company_address' => 'required',
        'company_city' => 'required',
        'company_postcode' => 'required',
        'company_state' => 'required',
        'company_country' => 'required'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function spaces()
    {
        return $this->hasOne('App\Models\Space', 'id', 'space_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function users()
    {
        return $this->hasOne('App\Models\User', 'id', 'booked_by_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function transaction()
    {
        return $this->hasOne('App\Models\Transaction', 'spacebooking_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function spaceconfigurations()
    {
        return $this->hasOne('App\Models\Spaceconfiguration', 'id', 'configuration_id');
    }
    
    public function thumbImage()
    {
        $imageType = Imagetype::where('name', 'thumbnail')->first();
        return $this->belongsToMany('App\Models\Image', "space_image", 'space_id', 'image_id')->wherePivot("imagetype_id", $imageType->id);
    }

    public function getCancellationFeeAttribute()
    {
        //  return $this->spaces->cancellation_percent * $this->total_price;
    }


    /**
     * Returns a query builder that constrains the query to return all records of the model that the $user has access to, based on the $context of the query.
     * The query context can be either PUBLIC or ADMIN, and refers to the section of the site that the query is being run for.
     * @param $query
     * @param $user
     * @param int $context
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeGetAllAuthorised($query, $user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
    {
        $columnArray = $columnArray == null ? ['spacebookings.*'] : $columnArray;

        //In the public context or if the user is an admin, don't constrain the query at all
        if($context == IAuthorisedModelAccess::CONTEXT_PUBLIC)
        {
            $queryBuilder = Spacebooking::newQuery()->select($columnArray);
        }
        else if($context == IAuthorisedModelAccess::CONTEXT_ADMIN)
        {
            if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
            {
                $queryBuilder = Spacebooking::newQuery()->select($columnArray);
            }
            else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
            {
                $queryBuilder = Spacebooking::join('spaces', 'spaces.id', '=', 'spacebookings.space_id')->join('building_host', function($join) {
                    $join->on('spaces.building_id', '=', 'building_host.building_id')
                        ->on('spaces.host_id', '=', 'building_host.host_id');
                })
                    ->join('building_user', 'building_user.building_host_id', '=', 'building_host.id')
                    ->where('building_user.user_id', $user->id)->select($columnArray);
            }
        }

        return $queryBuilder;
    }
}
