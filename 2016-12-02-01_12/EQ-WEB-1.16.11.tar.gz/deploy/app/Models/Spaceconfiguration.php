<?php

namespace App\Models;

/**
 * App\Models\Spaceconfiguration
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Space[] $spaces
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spaceconfiguration whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spaceconfiguration whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spaceconfiguration whereDescription($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spaceconfiguration whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spaceconfiguration whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spaceconfiguration whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Spaceconfiguration whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property-read \App\Models\User $createdby
 */
class Spaceconfiguration extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */

    protected $table = 'spaceconfigurations';
    
    protected $fillable = [
        'name',
        'description'
    ];
    
    public static $VALIDATION_RULES = [
        'name' => 'required'
    ];

    public static $VALIDATION_MESSAGES = [
        
    ];


    public function spaces()
    {
        return $this->belongsToMany('App\Models\Space');
    }
}
