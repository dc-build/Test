<?php
namespace App\Models\Traits;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

trait Auditable{

    public static function bootAuditable()
    {
        static::creating(function($obj)
        {
            if(Auth::user() != null)
            {
                $obj->createdby()->associate(Auth::user());
                $obj->updatedby()->associate(Auth::user());
            }
            else
            {
                $obj->created_by_id = Config::get("fsmsettings.system_user_id");
                $obj->updated_by_id = Config::get("fsmsettings.system_user_id");
            }
        });

        static::updating(function($obj)
        {
            if(Auth::user() != null)
            {
                $obj->updatedby()->associate(Auth::user());
            }
            else
            {
                $obj->updated_by_id = Config::get("fsmsettings.system_user_id");
            }
        });
    }
}