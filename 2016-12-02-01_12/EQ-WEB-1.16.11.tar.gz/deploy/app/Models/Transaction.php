<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


/**
 * App\Models\Transaction
 *
 * @property integer $id
 * @property integer $spacebooking_id
 * @property string $name
 * @property string $last_four
 * @property string $expiry_month
 * @property string $expiry_year
 * @property string $status
 * @property string $total_amount
 * @property string $fees
 * @property string $net_amount
 * @property string $receipt_number
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\Spacebooking $spacebookings
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereSpacebookingId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereLastFour($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereExpiryMonth($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereExpiryYear($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereStatus($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereTotalAmount($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereFees($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereNetAmount($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereReceiptNumber($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property-read \App\Models\Spacebooking $spacebooking
 * @property string $transaction_id
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Transaction whereTransactionId($value)
 */
class Transaction extends Model
{
    protected $table = 'transactions';
    
    protected $fillable = [
        'spacebooking_id',
        'name',
        'last_four',
        'expiry_month',
        'expiry_year',
        'status',
        'total_amount',
        'fees',
        'net_amount',
        'receipt_number'
    ];
    
    public static $VALIDATION_RULES = [
        'spacebooking_id' => 'required',
        'name' => 'required',
        'last_four' => 'required',
        'expiry_month' => 'required',
        'expiry_year' => 'required',
        'status' => 'required',
        'total_amount' => 'required',
        'net_amount' => 'required',
        'receipt_number' => 'required'
    ];

    public static $VALIDATION_MESSAGES = [
        
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\belongsTo
     */
    public function spacebooking()
    {
        return $this->belongsTo(Spacebooking::class, 'spacebooking_id');
    }
}
