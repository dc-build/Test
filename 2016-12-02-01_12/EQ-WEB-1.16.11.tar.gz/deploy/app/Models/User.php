<?php

namespace App\Models;

use App\Models\Traits\Auditable;
use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use Illuminate\Http\Request;
use OwenIt\Auditing\AuditingTrait;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * App\Models\User
 *
 * @property integer $id
 * @property string $auth0id
 * @property integer $role_id
 * @property string $first_name
 * @property string $last_name
 * @property string $email
 * @property string $mobile_number
 * @property boolean $isActive
 * @property string $password
 * @property string $remember_token
 * @property string $invitation_code
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property string $deleted_at
 * @property-read \App\Models\Role $roles
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereAuth0id($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereRoleId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereFirstName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereLastName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereEmail($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereMobileNumber($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereIsActive($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User wherePassword($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereRememberToken($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereInvitationCode($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\User whereDeletedAt($value)
 * @mixin \Eloquent
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Host[] $hosts
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Building[] $buildings
 * @property-read \App\Models\User $createdby
 */
class User extends BaseModel implements AuthenticatableContract,
                                    AuthorizableContract,
                                    CanResetPasswordContract
{
    use Authenticatable, Authorizable, CanResetPassword, SoftDeletes;
    
    public static $ACCOUNT_ROLE_ADMIN = "1";
    public static $ACCOUNT_ROLE_HOST = "2";
    public static $ACCOUNT_ROLE_USER = "3";
    
    public static $PASSWORD_RESET_VALIDATION_RULES = [
        'token' => 'required',
        'email' => 'required|email',
        'password' => 'required|confirmed|min:6|regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!$#%]).*$/|',
    ];

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['auth0id', 'isActive', 'role_id', 'first_name', 'last_name', 'email', 'mobile_number', 'invitation_code', 'created_by_id', 'updated_by_id'];

    protected $appends = ['full_name'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token'];
    
    public static $USER_EDIT_VALIDATION_RULES = [
        'email'                 => 'required|email',
        'role_id'               => 'required',
        'isActive'              => 'required'
    ];
    
    public static $USER_ADD_VALIDATION_RULES = [
        'email'                 => 'required|email',
        'role_id'               => 'required',
        'isActive'              => 'required'
    ];
    
    public function setPasswordAttribute($value) {
        $this->attributes['password'] = \Hash::make($value);
    }
    
    public function roles()
    {
        return $this->hasOne('App\Models\Role', 'id', 'role_id');
    }

    /**
     * Hosts that this user belongs too
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function hosts()
    {
        return $this->belongsToMany('App\Models\Host')->withPivot('id')->withTimestamps();
    }

    /**
     * Buildings that this user belongs too
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function buildings()
    {
        return $this->belongsToMany('App\Models\Building', 'building_user', 'user_id', 'building_id')->withPivot('host_user_id', 'building_host_id', 'host_id')->withTimestamps();
    }

    public static function getUserEditInputValues(Request $request) {
        $input = array(
            'first_name'            => $request->input('first_name'),
            'last_name'             => $request->input('last_name'),
            'email'                 => $request->input('email'),
            'mobile_number'         => $request->input('mobile_number'),
            'role_id'               => $request->input('role_id'),
            'isActive'              => $request->input('isActive'),
        );
        return $input;
    }
    
    public static function getUserAddInputValues(Request $request) {
        $input = array(
            'first_name'            => $request->input('first_name'),
            'last_name'             => $request->input('last_name'),
            'email'                 => $request->input('email'),
            'mobile_number'         => $request->input('mobile_number'),
            'password'              => $request->input('password'),
            'password_confirmation' => $request->input('password_confirmation'),
            'role_id'               => $request->input('role_id'),
            'isActive'              => $request->input('isActive'),
        );
        return $input;
    }

    public function getFullNameAttribute()
    {
        return sprintf("%s %s", ucfirst($this->first_name), ucfirst($this->last_name));
    }
}
