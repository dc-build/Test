<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 1/12/2016
 * Time: 12:22
 */

namespace App\Models\Validators;

use App\Models\Capacityprice;
use App\Models\Host;
use Illuminate\Validation\Validator;

class SpaceValidator extends Validator
{
    public function validateAvailability($atttribute, $value)
    {
        $data = $this->getData();
        $active = isset($data['active']) && $data['active'] === '1' ? true : false;
        return !$active || exists_attribute_with_value($data, '/^is_available\w+$/', false, '!==');
    }

    protected function replaceAvailability($message, $attribute, $rule, $parameters)
    {
        return $message;
    }


    public function validateCapacityprices($attribute, $value)
    {
        $data = $this->getData();

        $valid = true;
        $active = isset($data['active']) && $data['active'] === '1' ? true : false;
        if ($active && !empty($data['capacityprices']))
        {
            foreach ($data['capacityprices'] as $capacityprice)
            {
                $capacitypriceValidator = new Validator($this->getTranslator(), $capacityprice, Capacityprice::$CAPACITY_PRICE_VALIDATION_RULES);
                $valid = $valid && $capacitypriceValidator->passes();
                $valid = $valid && exists_attribute_with_value($capacityprice, '/^rate_\w+$/', 0.0, '>');
                $valid = $valid && $capacityprice['attendees_max'] >= $capacityprice['attendees_min'];
            }
        }

        return $valid;
    }

    protected function replaceCapacityprices($message, $attribute, $rule, $parameters)
    {
        return $message;
    }

    public function validatePaymentOptions($attribute, $value)
    {
        $data = $this->getData();
        $active = isset($data['active']) && $data['active'] === '1' ? true : false;
        return !$active || exists_attribute_with_value($data, '/^payment_\w+_allowed$/', false, '!==');

    }

    protected function replacePaymentOptions($message, $attribute, $rule, $parameters)
    {
        return $message;
    }

    public function validatePricingPeriod($attribute, $value)
    {
        $data = $this->getData();
        $active = isset($data['active']) && $data['active'] === '1' ? true : false;
        return !$active || exists_attribute_with_value($data, '/^pricing_\w+_enabled$/', false, '!==');
    }

    protected function replacePricingPeriod($message, $attribute, $rule, $parameters)
    {
        return $message;
    }

    public function validateRequiresCreditcard($atttribute, $value)
    {
        $data = $this->getData();
        if (empty($data['host_id']))
        {
            return false;
        }
        $host = Host::with('creditcard')->find($data['host_id']);
        return !is_null($host->creditcard);
    }

    protected function replaceRequiresCreditcard($message, $attribute, $rule, $parameters)
    {
        return $message;
    }


}