<?php

namespace App\Models;
use App\Models\Interfaces\IAuthorisedModelAccess;

/**
 * App\Models\Whitelistdate
 *
 * @property integer $id
 * @property integer $space_id
 * @property string $name
 * @property string $start_datetime
 * @property string $end_datetime
 * @property integer $created_by_id
 * @property integer $updated_by_id
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property-read \App\Models\Space $spaces
 * @property-read \App\Models\User $updatedby
 * @property-read \Illuminate\Database\Eloquent\Collection|\OwenIt\Auditing\Log[] $logs
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereSpaceId($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereName($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereStartDatetime($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereEndDatetime($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereCreatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereUpdatedById($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereCreatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Whitelistdate whereUpdatedAt($value)
 * @method static \Illuminate\Database\Query\Builder|\App\Models\Space getAllAuthorised($user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
 * @mixin \Eloquent
 * @property-read \App\Models\User $createdby
 */
class Whitelistdate extends BaseModel implements IAuthorisedModelAccess
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'whitelistdates';
    
    protected $fillable = [
        'space_id',
        'name',
        'start_datetime',
        'end_datetime'
    ];
    
    public static $VALIDATION_RULES = [
        'space_id' => 'required',
        'name' => 'required',
        'start_datetime' => 'required',
        'end_datetime' => 'required'
    ];
    
    public static $VALIDATION_MESSAGES = [
        
    ];
    
    public function space()
    {
        return $this->hasOne('App\Models\Space', 'id', 'space_id');
    }

    /**
     * Returns a query builder that constrains the query to return all records of the model that the $user has access to, based on the $context of the query.
     * The query context can be either PUBLIC or ADMIN, and refers to the section of the site that the query is being run for.
     * @param $query
     * @param $user
     * @param int $context
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeGetAllAuthorised($query, $user, $columnArray = null, $context = IAuthorisedModelAccess::CONTEXT_ADMIN)
    {
        $columnArray = $columnArray == null ? ['whitelistdates.*'] : $columnArray;
        //In the public context or if the user is an admin, don't constrain the query at all
        if($context == IAuthorisedModelAccess::CONTEXT_PUBLIC)
        {
            $queryBuilder = Whitelistdate::newQuery()->select($columnArray);
        }
        else if($context == IAuthorisedModelAccess::CONTEXT_ADMIN)
        {
            if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
            {
                $queryBuilder = Whitelistdate::newQuery()->select($columnArray);
            }
            else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
            {
                //Only return Whitelist dates that the user can see because they have access to the space
                $queryBuilder = Whitelistdate::join('spaces', 'whitelistdates.space_id', '=', 'spaces.id')->join('building_host', function($join) {
                    $join->on('spaces.building_id', '=', 'building_host.building_id')
                        ->on('spaces.host_id', '=', 'building_host.host_id');
                })
                    ->join('building_user', 'building_user.building_host_id', '=', 'building_host.id')
                    ->where('building_user.user_id', $user->id)->select($columnArray);
            }
        }

        return $queryBuilder;
    }
}
