<?php

namespace App\Policies;

use App\Models\Blacklistdate;
use Illuminate\Auth\Access\HandlesAuthorization;
use App\Models\User;


class AdminBlacklistdateModelPolicy
{
    use HandlesAuthorization;


    public function show(User $user, Blacklistdate $blacklistdate)
    {
        return $this->checkAccess($user, $blacklistdate);
    }

    public function update(User $user, Blacklistdate $blacklistdate)
    {
        return $this->checkAccess($user, $blacklistdate);
    }

    public function delete(User $user, Blacklistdate $blacklistdate)
    {
        return $this->checkAccess($user, $blacklistdate);
    }

    protected function checkAccess(User $user, Blacklistdate $blacklistdate)
    {
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            return true;
        }
        else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
        {
            //A host admin can only see blacklistdate records that they have access to through the host
            return $blacklistdate->space->host->hostadmins->contains($user->id);
        }
        else
        {
            return false;
        }
    }
}
