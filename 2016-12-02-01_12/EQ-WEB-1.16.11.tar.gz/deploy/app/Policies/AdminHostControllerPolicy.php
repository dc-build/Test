<?php

namespace App\Policies;

use App\Http\Controllers\HostController;
use Illuminate\Auth\Access\HandlesAuthorization;
use App\Models\User;


class AdminHostControllerPolicy extends BaseAdminControllerPolicy
{
    use HandlesAuthorization;

    public function getController()
    {
        return HostController::class;
    }

    /**
     * Returns the methods on the controller that the user is authorised for
     * @param $user
     * @return array
     */
    protected function getAccessibleMethods($user)
    {
        $allowedMethods = [];
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            $permittedActions = [
                'assignHostAdmin' // Allows the user to assign users to a host as a hostadmin
            ];
            $allowedMethods = array_merge($this->getUninheritedControllerMethods(), $permittedActions);
        }
        if($user->role_id == User::$ACCOUNT_ROLE_HOST)
        {
            $allowedMethods = ['index', 'hosts', 'show', 'update', 'apiList'];
        }

        return $allowedMethods;
    }



}
