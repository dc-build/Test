<?php

namespace App\Policies;

use App\Models\Host;
use Illuminate\Auth\Access\HandlesAuthorization;
use App\Models\User;


class AdminHostModelPolicy
{
    use HandlesAuthorization;


    public function show(User $user, Host $host)
    {
        return $this->checkHostAdminActions($user, $host);
    }

    public function update(User $user, Host $host)
    {
        return $this->checkHostAdminActions($user, $host);
    }

    public function delete(User $user, Host $host)
    {
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    protected function checkHostAdminActions(User $user, Host $host)
    {
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            return true;
        }
        else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
        {
            //A host admin can only see Host records that they have access to through the host
            return $host->hostadmins->contains($user->id);
        }
        else
        {
            return false;
        }
    }
}
