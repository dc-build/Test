<?php

namespace App\Policies;

use App\Models\Spacebooking;
use Illuminate\Auth\Access\HandlesAuthorization;
use App\Models\User;


class AdminSpacebookingModelPolicy
{
    use HandlesAuthorization;


    public function show(User $user, Spacebooking $spacebooking)
    {
        return $this->checkAdminAccess($user, $spacebooking);
    }

    public function update(User $user, Spacebooking $spacebooking)
    {
        return $this->checkAdminAccess($user, $spacebooking);
    }

    public function delete(User $user, Spacebooking $spacebooking)
    {
        return $this->checkAdminAccess($user, $spacebooking);
    }

    //This can be used to authorise the user who created the booking
    public function showUser(User $user, Spacebooking $spacebooking)
    {
        if($user->role_id == User::$ACCOUNT_ROLE_USER)
        {
            return ($spacebooking->booked_by_id == $user->id);
        }
        else
        {
            return false;
        }
    }

    protected function checkAdminAccess(User $user, Spacebooking $spacebooking)
    {
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            return true;
        }
        else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
        {
            //A host admin can only see blacklistdate records that they have access to through the host
            return $spacebooking->spaces->host->hostadmins->contains($user->id);
        }
        else
        {
            return false;
        }
    }
}
