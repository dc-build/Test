<?php 
namespace App\Policies;

use App\Http\Controllers\TransactionController;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class AdminTransactionControllerPolicy extends BaseAdminControllerPolicy
{
    use HandlesAuthorization;

    protected function getController()
    {
        return TransactionController::class;
    }

    /**
     * Returns the methods on the controller that the user is authorised for
     * @param $user
     * @return array
     */
    protected function getAccessibleMethods($user)
    {
        $allowedMethods = [];
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            $allowedMethods = get_class_methods($this->getController());
        }

        return $allowedMethods;
    }

}
