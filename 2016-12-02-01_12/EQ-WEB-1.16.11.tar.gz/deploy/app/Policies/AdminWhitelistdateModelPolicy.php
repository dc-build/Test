<?php

namespace App\Policies;

use App\Models\Whitelistdate;
use Illuminate\Auth\Access\HandlesAuthorization;
use App\Models\User;


class AdminWhitelistdateModelPolicy
{
    use HandlesAuthorization;


    public function show(User $user, Whitelistdate $whitelistdate)
    {
        return $this->checkAccess($user, $whitelistdate);
    }

    public function update(User $user, Whitelistdate $whitelistdate)
    {
        return $this->checkAccess($user, $whitelistdate);
    }

    public function delete(User $user, Whitelistdate $whitelistdate)
    {
        return $this->checkAccess($user, $whitelistdate);
    }

    protected function checkAccess(User $user, Whitelistdate $whitelistdate)
    {
        if($user->role_id == User::$ACCOUNT_ROLE_ADMIN)
        {
            return true;
        }
        else if($user->role_id == User::$ACCOUNT_ROLE_HOST)
        {
            //A host admin can only see blacklistdate records that they have access to through the host
            return $whitelistdate->space->host->hostadmins->contains($user->id);
        }
        else
        {
            return false;
        }
    }
}
