<?php 
namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use ReflectionMethod;

abstract class BaseAdminControllerPolicy
{
    use HandlesAuthorization;

    /**
     *
     * This assoc. array handles the groupings to which certain methods belong:
     *
     *      <method> => <method group>
     *
     *
     * @var array
     */
    public $accessibleMethodGroups = [];

    public $adminAccessibleMethods = [];

    /**
     * Methods accessible by the HOST user role.
     *
     * @var array
     */
    public $hostAccessibleMethods = [];

    protected abstract function getController();

    protected abstract function getAccessibleMethods($user);

    /**
     * Returns the methods defined only in the controller class, and no inherited methods
     * @return array
     */
    protected function getUninheritedControllerMethods()
    {
        $reflection = new \ReflectionClass($this->getController());
        $methods = [];
        foreach ($reflection->getMethods(ReflectionMethod::IS_PUBLIC) as $method)
        {
            if ($method->class == $reflection->getName())
            {
                $methods[] = $method->name;
            }
        }

        return $methods;
    }

    /**
     * This method uses the PHP Magic Method __call to handle any authorise action passed to the policy
     *
     * This enabled us to do a basic check using the policy's getAccessibleMethods function and passing in th current user
     * and then checking within the policy if the user can do the required check.
     *
     * This is designed to work with controller methods, but could work with anything as long as you pass in the correct
     * string and controller class to the authorise call, and then define the accessiblemethods in the policy implementation
     *
     * @param $name
     * @param $arguments
     *
     * @return bool
     */
    public function __call($name, $arguments)
    {
        $user = array_shift($arguments);
        return in_array($name, $this->getAccessibleMethods($user));
    }
}
