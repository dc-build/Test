<?php

namespace App\Providers;

use App\Models\Capacityprice;
use App\Models\Validators\SpaceValidator;
use App\Repository\ISpacebookingRepository;
use App\Repository\SpacebookingRepository;
use App\Services\BookingEngineService;
use App\Services\IBookingEngineService;
use App\Services\AuthorisedModelAccessService;
use App\Services\IAuthorisedModelAccessService;
use App\Services\IPaymentService;
use App\Services\StripePaymentService;
use Illuminate\Support\ServiceProvider;
use Validator;
use Illuminate\Validation\Validator as IlluminateValidator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Validator::resolver(function($translator, $data, $rules, $messages)
        {
            return new SpaceValidator($translator, $data, $rules, $messages);
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(
        '\Auth0\Login\Contract\Auth0UserRepository',
        '\App\Repository\UserRepository');
        
        $this->app->bind(
        '\App\Services\IImageService',
        '\App\Services\ImageService');
        
        $this->app->bind(
        '\App\Services\IUuidService',
        '\App\Services\UuidService');
        
        $this->app->bind(
        '\App\Services\IDateService',
        '\App\Services\DateService');

        $this->app->bind(
          '\App\Services\IRateEngineService',
          '\App\Services\RateEngineService');

        $this->app->bind(
            '\App\Services\ISpaceManagerService',
            '\App\Services\SpaceManagerService');

        $this->app->bind(
            IBookingEngineService::class,
            BookingEngineService::class);

        $this->app->bind(
            IPaymentService::class,
            StripePaymentService::class);

        $this->app->bind(
            ISpacebookingRepository::class,
            SpacebookingRepository::class);

        $this->app->bind(
            IAuthorisedModelAccessService::class,
            AuthorisedModelAccessService::class);

        if ($this->app->environment() !== 'production') {
            $this->app->register(\Barryvdh\LaravelIdeHelper\IdeHelperServiceProvider::class);
        }
    }
}
