<?php namespace App\Providers;

use App\Http\Controllers\AdminController;
use App\Http\Controllers\HostController;
use App\Http\Controllers\LocalityController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\BuildingController;
use App\Http\Controllers\ImagetypeController;
use App\Http\Controllers\SpaceController;
use App\Http\Controllers\SpacebookingController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\SpaceconfigurationController;
use App\Http\Controllers\FloorController;
use App\Http\Controllers\CardController;
use App\Http\Controllers\SpacefacilityController;
use App\Http\Controllers\SpacetypeController;
use App\Http\Controllers\SpaceuseController;
use App\Http\Controllers\BlacklistdateController;
use App\Http\Controllers\WhitelistdateController;
use App\Http\Controllers\CalendarController;
use App\Models\Blacklistdate;
use App\Models\Host;
use App\Models\Spacebooking;
use App\Models\Whitelistdate;
use App\Policies\AdminBlacklistdateModelPolicy;
use App\Policies\AdminHostControllerPolicy;
use App\Policies\AdminControllerPolicy;
use App\Policies\AdminHostModelPolicy;
use App\Policies\AdminLocalityControllerPolicy;
use App\Policies\AdminSpacebookingModelPolicy;
use App\Policies\AdminSpaceControllerPolicy;
use App\Policies\AdminUserControllerPolicy;
use App\Policies\AdminRoleControllerPolicy;
use App\Policies\AdminBuildingControllerPolicy;
use App\Policies\AdminImagetypeControllerPolicy;
use App\Policies\AdminSpacebookingControllerPolicy;
use App\Policies\AdminTransactionControllerPolicy;
use App\Policies\AdminSpaceconfigurationControllerPolicy;
use App\Policies\AdminFloorControllerPolicy;
use App\Policies\AdminCardControllerPolicy;
use App\Policies\AdminSpacefacilityControllerPolicy;
use App\Policies\AdminSpacetypeControllerPolicy;
use App\Policies\AdminSpaceuseControllerPolicy;
use App\Policies\AdminBlacklistdateControllerPolicy;
use App\Policies\AdminWhitelistdateControllerPolicy;
use App\Policies\AdminCalendarControllerPolicy;
use App\Policies\AdminWhitelistdateModelPolicy;
use Illuminate\Contracts\Auth\Access\Gate as GateContract;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        AdminController::class => AdminControllerPolicy::class,
        UserController::class => AdminUserControllerPolicy::class,
        RoleController::class => AdminRoleControllerPolicy::class,
        BuildingController::class => AdminBuildingControllerPolicy::class,
        HostController::class => AdminHostControllerPolicy::class,
        ImagetypeController::class => AdminImagetypeControllerPolicy::class,
        SpaceController::class => AdminSpaceControllerPolicy::class,
        LocalityController::class => AdminLocalityControllerPolicy::class,
        SpacebookingController::class => AdminSpacebookingControllerPolicy::class,
        TransactionController::class => AdminTransactionControllerPolicy::class,
        SpaceconfigurationController::class => AdminSpaceconfigurationControllerPolicy::class,
        FloorController::class => AdminFloorControllerPolicy::class,
        CardController::class => AdminCardControllerPolicy::class,
        SpacefacilityController::class => AdminSpacefacilityControllerPolicy::class,
        SpacetypeController::class => AdminSpacetypeControllerPolicy::class,
        SpaceuseController::class => AdminSpaceuseControllerPolicy::class,
        BlacklistdateController::class => AdminBlacklistdateControllerPolicy::class,
        WhitelistdateController::class => AdminWhitelistdateControllerPolicy::class,
        CalendarController::class => AdminCalendarControllerPolicy::class,

        Host::class => AdminHostModelPolicy::class,
        Blacklistdate::class => AdminBlacklistdateModelPolicy::class,
        Whitelistdate::class => AdminWhitelistdateModelPolicy::class,
        Spacebooking::class => AdminSpacebookingModelPolicy::class,
    ];

    /**
     * Register any application authentication / authorization services.
     *
     * @param  \Illuminate\Contracts\Auth\Access\Gate  $gate
     * @return void
     */
    public function boot(GateContract $gate)
    {
        parent::registerPolicies($gate);

        $this->definePolicies($gate);

        $this->registerPolicies($gate);
    }

    private function definePolicies(GateContract $gate)
    {
        $this->registerPolicies($gate);
        /*
        foreach ($this->policies as $controller => $policy)
        {
            $policyInstance = $gate->getPolicyFor($controller);
            // get the class methods for for the associated controller
            $methods = get_class_methods($controller);
            // remove the parent class methods - may pose a security risk
            $methods = array_diff($methods, get_class_methods(get_parent_class($controller)));
            foreach ($methods as $method)
            {
                if (!$gate->has($method))
                {
                    $gate->define($method, "{$policy}@{$method}");
                    if (in_array($method, array_keys($policyInstance->accessibleMethodGroups)))
                    {
                        $gate->define($policyInstance->accessibleMethodGroups[$method], "{$policy}@" . $policyInstance->accessibleMethodGroups[$method]);
                    }
                }
            }
        }
        */


    }
}
