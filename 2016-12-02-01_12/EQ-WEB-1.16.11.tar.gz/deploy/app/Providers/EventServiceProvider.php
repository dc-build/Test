<?php

namespace App\Providers;

use App\Models\Host;
use App\Models\Locality;
use App\Models\Space;
use App\Models\Observers\SpaceObserver;
use App\Models\Observers\HostObserver;
use App\Models\Observers\LocalityObserver;
use Illuminate\Contracts\Events\Dispatcher as DispatcherContract;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        'App\Events\SomeEvent' => [
            'App\Listeners\EventListener',
        ],
    ];

    /**
     * Register any other events for your application.
     *
     * @param  \Illuminate\Contracts\Events\Dispatcher  $events
     * @return void
     */
    public function boot(DispatcherContract $events)
    {
        parent::boot($events);

        Locality::observe(LocalityObserver::class);
        Host::observe(HostObserver::class);
        Space::observe(SpaceObserver::class);
    }
}
