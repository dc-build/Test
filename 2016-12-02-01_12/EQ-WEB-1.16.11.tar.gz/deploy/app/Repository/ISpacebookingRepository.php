<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 2:49 PM
 */

namespace App\Repository;


use App\Models\Popo\BookingDetail;
use App\Models\Spacebooking;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;

/**
 * Interface defining SpacebookingRepository
 *
 * Interface ISpacebookingRepository
 * @package App\Repository
 */
interface ISpacebookingRepository
{
    /**
     * @param Spacebooking $spacebooking
     * @return Spacebooking if successful, null otherwise
     */
    public function save(Spacebooking $spacebooking);

    /**
     * @param Spacebooking $spacebooking
     * @param BookingDetail $bookingDetail
     * @return Transaction if successful, null otherwise
     */
    public function updateSpacebookingPaymentTransaction(Spacebooking $spacebooking, BookingDetail $bookingDetail);

    /**
     * Gets all bookings for a specified space
     *
     * @param $spaceId
     * @return Collection of Spacebookings
     */
    public function getSpaceBookings($spaceId);

    /**
     * @param $spaceId
     * @param Carbon $startDatetime
     * @param Carbon $endDatetime
     * @return mixed
     */
    public function getSpaceBookingsWithinDateInterval($spaceId, Carbon $startDatetime, Carbon $endDatetime);

    /**
     * Gets all bookings for a specified user
     *
     * @param $userId
     * @param bool $filterUnpaid
     * @return Collection of Spacebookings
     */
    public function getSpaceBookingsByUserId($userId, $filterUnpaid = true);

    /**
     * @param $spacebookingId
     * @return Spacebooking
     */
    public function getSpaceBookingById($spacebookingId);

    /**
     * @param $buildingId
     * @param null $userId
     * @param bool $filterUnpaid
     * @return Collection of Spacebookings
     */
    public function getSpaceBookingsByBuildingIdAndUserId($buildingId, $userId = null, $filterUnpaid = true);
    
    /**
     * Gets all space bookings in the system
     * NOTE: Careful using this as this could be a lot of them!
     *
     * @return Collection of Spacebookings
     */
    public function getAllSpaceBookings();
}