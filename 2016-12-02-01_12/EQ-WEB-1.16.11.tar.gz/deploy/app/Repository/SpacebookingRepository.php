<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 2:51 PM
 */

namespace App\Repository;


use App\Models\Popo\BookingDetail;
use App\Models\Spacebooking;
use App\Models\Transaction;
use App\Services\Exceptions\SpacebookingUpdateException;
use App\Services\IDateService;
use Carbon\Carbon;
use Illuminate\Database\Connection;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Log\Writer;

/**
 * Repository object for updating Spacebookings
 *
 * Class SpacebookingRepository
 * @package App\Repository
 */
class SpacebookingRepository implements ISpacebookingRepository
{
    /**
     * @var Writer
     */
    private $logger;
    /**
     * @var Connection
     */
    private $db;
    /**
     * @var IDateService
     */
    private $dateService;

    /**
     * SpacebookingRepository constructor.
     * @param Writer $logger
     * @param Connection $db
     * @param IDateService $dateService
     */
    public function __construct(Writer $logger, Connection $db, IDateService $dateService)
    {
        $this->logger = $logger;
        $this->db = $db;
        $this->dateService = $dateService;
    }

    /**
     * @inheritDoc
     */
    public function save(Spacebooking $spacebooking)
    {
        try
        {
            $this->db->transaction(function () use (&$spacebooking)
            {
                $spacebooking->save();
            });

            return $spacebooking;
        }
        catch (\Exception $e)
        {
            $message = sprintf('There was an error saving the spacebooking: \n%s', (string)$e);
            $this->logger->error($message);
            $spacebookingEx = new SpacebookingUpdateException($message, 0, $e);
            $spacebookingEx->setSpacebooking($spacebooking);
            throw $spacebookingEx;
        }
    }

    /**
     * @inheritDoc
     */
    public function updateSpacebookingPaymentTransaction(Spacebooking $spacebooking, BookingDetail $bookingDetail)
    {
        try
        {
            $this->logger->info(sprintf('Updating payment data for spacebooking: %s, %s', $spacebooking->id, serialize($bookingDetail)));

            $txRecord = new Transaction();
            $this->db->transaction(function() use (&$spacebooking, &$txRecord, $bookingDetail) {
                $spacebooking->update(['payment_received' => true]);

                // Add transaction record
                $txRecord->spacebooking_id = $spacebooking->id;
                $txRecord->transaction_id = $bookingDetail->payment_transaction_id;
                $txRecord->total_amount = (float)($bookingDetail->payment_total_amount/100);
                $txRecord->name = $bookingDetail->cc_name;
                $txRecord->last_four = $bookingDetail->cc_lastfour;
                $txRecord->expiry_month = $bookingDetail->cc_expiry_month;
                $txRecord->expiry_year = $bookingDetail->cc_expiry_year;
                $txRecord->status = "SUCCESS";
                $txRecord->save();
            });

            return $txRecord;
        }
        catch (\Exception $e)
        {
            $message = sprintf('There was an error while updating the payment transaction record: \n%s', (string)$e);
            $this->logger->error($message, ['exception' => $e]);
            $this->logger->error(sprintf('BOOKING DETAILS: %s', serialize($bookingDetail)));
            $spacebookingEx = new SpacebookingUpdateException($message, 0, $e);
            $spacebookingEx->setSpacebooking($spacebooking);
            throw $spacebookingEx;
        }
    }

    /**
     * @param Spacebooking $item
     * @param $key
     * @return Spacebooking
     */
    private function resolvePreptimes(Spacebooking $item, $key)
    {
        $item->resolved_start_datetime = $item->start_datetime;
        $item->resolved_end_datetime = $item->end_datetime;

        if ($item->prep_time_before != null && $item->prep_time_before > 0)
        {
            $resolved_start_datetime = Carbon::parse($item->start_datetime)->subMinutes($item->prep_time_before);
            $item->resolved_start_datetime = $resolved_start_datetime->toDateTimeString();
        }
        if ($item->prep_time_after != null && $item->prep_time_after > 0)
        {
            $resolved_end_datetime = Carbon::parse($item->end_datetime)->addMinutes($item->prep_time_after);
            $item->resolved_end_datetime = $resolved_end_datetime->toDateTimeString();
        }
        return $item;
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookings($spaceId)
    {
        $spacebookings =
            Spacebooking::where('space_id', $spaceId)
                ->get()
                ->transform(function(Spacebooking $item, $key) {
                    return ($this->resolvePreptimes($item, $key));
                });

        return $spacebookings;
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingsWithinDateInterval($spaceId, Carbon $startDatetime, Carbon $endDatetime)
    {
        $utcStartDatetime = $startDatetime;
        $utcEndDatetime = $endDatetime;
        if (!$startDatetime->utc)
        {
            $utcStartDatetime = $this->dateService->convertCarbonDateToUTC($startDatetime);
        }
        if (!$endDatetime->utc)
        {
            $utcEndDatetime = $this->dateService->convertCarbonDateToUTC($endDatetime);
        }

        $spacebookings = Spacebooking::where('space_id', $spaceId)->where('start_datetime', '<=', $utcEndDatetime)->where('end_datetime', '>=', $utcStartDatetime)->get();

        // Resolve the prep times
        $spacebookings->transform(function(Spacebooking $item, $key) {
            return ($this->resolvePreptimes($item, $key));
        });

        // Run filter
        $resolvedSpacebookings = $spacebookings->filter(function(Spacebooking $value) use($utcStartDatetime, $utcEndDatetime) {
            return ($value->resolved_start_datetime <= $utcEndDatetime && $value->resolved_end_datetime >= $utcStartDatetime);
        });

        return $resolvedSpacebookings;
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingsByUserId($userId, $filterUnpaid = true)
    {
        $selectCols = \DB::getSchemaBuilder()->getColumnListing('spaces');
        for ($i = 0; $i < count($selectCols); $i++)
        {
            $selectCols[$i] = "spaces.{$selectCols[$i]} as spaces_{$selectCols[$i]}";
        }

        $query =
            \DB::table('spacebookings')
                ->join('spaces', 'spacebookings.space_id', '=', 'spaces.id')
                ->join('space_image', 'spaces.id', '=', 'space_image.space_id')
                ->join('buildings', 'spaces.building_id', '=', 'buildings.id')
                ->join('building_image', 'buildings.id', '=', 'building_image.building_id')
                ->join('images as image_building', 'building_image.image_id', '=', 'image_building.id')
                ->join('imagetypes as it_logo', function($join) {
                    $join->on('building_image.imagetype_id', '=', 'it_logo.id')->where('it_logo.name', '=', 'logo');
                })
                ->join('images as image_space', 'space_image.image_id', '=', 'image_space.id')
                ->join('imagetypes as it_thumb', function($join) {
                    $join->on('space_image.imagetype_id', '=', 'it_thumb.id')->where('it_thumb.name', '=', 'thumbnail');
                })
                ->join('users', function($join) use ($userId) {
                    $join->on('spacebookings.booked_by_id', '=', 'users.id')->where('users.id', '=', $userId);
                });

        if ($filterUnpaid)
        {
            $query = $query->where('spacebookings.payment_received', true);
        }

        array_unshift(
            $selectCols, 
            'image_space.image_uuid as image_space_image_uuid', 
            'image_space.file_ext as image_space_file_ext', 
            'image_building.image_uuid as image_building_image_uuid', 
            'image_building.file_ext as image_building_file_ext',
            'buildings.name as building_name',
            'buildings.private_slug as building_private_slug',
            'buildings.direct_url as building_direct_url',
            'spacebookings.*'
        );
        $query = $query->select($selectCols)->distinct();

        $this->logger->debug("getSpaceBookingsByUserId: {$query->toSql()}");

        return $query->get();
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingById($spacebookingId)
    {
        return (Spacebooking::find($spacebookingId));
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingsByBuildingIdAndUserId($buildingId, $userId = null, $filterUnpaid = true)
    {
        $selectCols = \DB::getSchemaBuilder()->getColumnListing('spaces');
        for ($i = 0; $i < count($selectCols); $i++)
        {
            $selectCols[$i] = "spaces.{$selectCols[$i]} as spaces_{$selectCols[$i]}";
        }

        $query =
            \DB::table('spacebookings')
                ->join('spaces', 'spacebookings.space_id', '=', 'spaces.id')
                ->join('buildings', function($join) use($buildingId) {
                    $join->on('spaces.building_id', '=', 'buildings.id')->where('buildings.id', '=', $buildingId);
                })
                ->join('space_image', 'spaces.id', '=', 'space_image.space_id')
                ->join('images', 'space_image.image_id', '=', 'images.id')
                ->join('imagetypes', function($join) {
                    $join->on('space_image.imagetype_id', '=', 'imagetypes.id')->where('imagetypes.name', '=', 'thumbnail');
                });

        if ($filterUnpaid)
        {
            $query = $query->where('spacebookings.payment_received', true);
        }
        if ($userId != null)
        {
            $query = $query->join('users', function($join) use ($userId) {
                $join->on('spacebookings.booked_by_id', '=', 'users.id')->where('users.id', '=', $userId);
            });
        }

        array_unshift($selectCols, 'images.image_uuid as images_image_uuid', 'images.file_ext as images_file_ext', 'spacebookings.*');
        $query = $query->select($selectCols)->distinct();

        $this->logger->debug("getSpaceBookingsByBuildingIdAndUserId: {$query->toSql()}");

        return $query->get();
    }

    /**
     * @inheritDoc
     */
    public function getAllSpaceBookings()
    {
        $spacebookings =
            Spacebooking::all()
                ->transform(function(Spacebooking $item, $key) {
                    return ($this->resolvePreptimes($item, $key));
                });
        return $spacebookings;
    }
}