<?php 
namespace App\Repository;

use Auth0\Login\Contract\Auth0UserRepository;
use App\Models\User;

class UserRepository implements Auth0UserRepository {

    /* This class is used on api authN to fetch the user based on the jwt.*/
    public function getUserByDecodedJWT($jwt) {
        /* 
         * The `sub` claim in the token represents the subject of the token
         * and it is always the `user_id`
         */
        $jwt->user_id = $jwt->sub;

        return $this->upsertUser($jwt);
    }

    public function getUserByUserInfo($userInfo) {  
        return $this->upsertUser($userInfo['profile']);
    }

    protected function upsertUser($profile) {
        $user = User::where("email", $profile['email'])->first();

        if ($user === null) {
            //Add new user
            $user = new User();
            $user->email = $profile['email']; 
            $user->auth0id = $profile['user_id'];
            $user->role_id = "3";
            $user->isActive = "1";
            if (isset($profile['user_metadata']['mobile_number'])) {
                $user->mobile_number = $profile['user_metadata']['mobile_number'];
            }
            if (isset($profile['user_metadata']['first_name'])) {
                $user->first_name = $profile['user_metadata']['first_name'];
            }
            if (isset($profile['user_metadata']['last_name'])) {
                $user->last_name = $profile['user_metadata']['last_name'];
            }
            $user->save();
        }
        elseif ($user->auth0id===null || empty($user->auth0id)) {
            //Update auth0id mobile_number for pre-registered users once they logged-in
            $user->auth0id = $profile['user_id'];
            if (isset($profile['user_metadata']['mobile_number'])) {
                $user->mobile_number = $profile['user_metadata']['mobile_number'];
            }
            if (isset($profile['user_metadata']['first_name'])) {
                $user->first_name = $profile['user_metadata']['first_name'];
            }
            if (isset($profile['user_metadata']['last_name'])) {
                $user->last_name = $profile['user_metadata']['last_name'];
            }
            $user->save();
        }

        if ($profile['user_id']!=$user->auth0id) {
            $user->auth0id = $profile['user_id'];
            $user->save();
        }
        return $user;
    }

    public function getUserByIdentifier($identifier) {
        //Get the user info of the user logged in (probably in session)
        $user = \App::make('auth0')->getUser();

        if ($user===null) return null;

        // build the user
        $user = $this->getUserByUserInfo($user);
        
        // it is not the same user as logged in, it is not valid
        if ($user && $user->auth0id == $identifier) {
            return $auth0User;
        }
    }

}