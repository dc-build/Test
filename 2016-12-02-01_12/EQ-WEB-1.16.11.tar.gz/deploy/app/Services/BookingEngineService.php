<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 10/11/2016
 * Time: 2:21 PM
 */

namespace App\Services;

use App\Models\Host;
use App\Models\Popo\BookingDetail;
use App\Models\Popo\BookingRateDetail;
use App\Models\Popo\BookingRequest;
use App\Models\Space;
use App\Models\Spacebooking;
use App\Repository\ISpacebookingRepository;
use App\Services\Exceptions\AttendeesOutOfRangeException;
use App\Services\Exceptions\BookingContainsAtLeastOneExistingBookingException;
use App\Services\Exceptions\BookingException;
use App\Services\Exceptions\DailyBookingDaysLessThanOneException;
use App\Services\Exceptions\DailyPricingAndMonthlyPricingNotEnabled;
use App\Services\Exceptions\HourlyBookingContainsAtLeastOneBlacklistDateException;
use App\Services\Exceptions\HourlyPricingNotEnabledException;
use App\Services\Exceptions\StartDatePastEndDateException;
use App\Services\Exceptions\StartDayDifferentFromEndDayForHourlyBookingException;
use App\Services\Exceptions\UnavailableHourlyBookingAfterhoursException;
use App\Services\Exceptions\UnavailableHourlyBookingDayOfWeekException;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Log\Writer;

error_reporting(E_ALL);

/**
 * Class BookingEngineService
 * @package App\Services
 */
class BookingEngineService Implements IBookingEngineService
{
    const INVOICE_PAYMENT_TYPE = "invoice";
    const CREDIT_CARD_PAYMENT_TYPE = "creditcard";

    /**
     * @var IDateService
     */
    private $dateService = null;
    /**
     * @var ISpaceManagerService
     */
    private $spaceMgr = null;
    /**
     * @var IRateEngineService
     */
    private $rateEngine = null;
    /**
     * @var Writer
     */
    private $logger = null;
    /**
     * @var IPaymentService
     */
    private $paymentService = null;
    /**
     * @var ISpacebookingRepository
     */
    private $spacebookingRepo;

    /**
     * BookingEngineService constructor.
     *
     * @param Writer $logger
     * @param ISpacebookingRepository $spacebookingRepo
     * @param ISpaceManagerService $spaceMgr
     * @param IRateEngineService $rateEngine
     * @param IDateService $dateService
     * @param IPaymentService $paymentService
     */
    public function __construct(
        Writer $logger,
        ISpacebookingRepository $spacebookingRepo,
        ISpaceManagerService $spaceMgr,
        IRateEngineService $rateEngine,
        IDateService $dateService,
        IPaymentService $paymentService)
    {
        $this->logger = $logger;
        $this->dateService = $dateService;
        $this->spaceMgr = $spaceMgr;
        $this->rateEngine = $rateEngine;
        $this->paymentService = $paymentService;
        $this->spacebookingRepo = $spacebookingRepo;

        // Init payment service
        $this->paymentService->init();
    }

    /*********************************************************************
     * Helpers
     *********************************************************************/

    /**
     * @param Space $space
     * @param BookingDetail $bookingDetail
     * @param $numAttendees
     * @param Carbon $startDatetimeLocalTz
     * @param Carbon $endDatetimeLocalTz
     * @param null $bookedByUserId
     * @param null $paymentType
     * @param null $configurationId
     * @param null $paymentToken
     * @param Host $host
     * @param callable $validateBooking
     * @return BookingRequest
     * @throws BookingException
     * @throws \Exception
     */
    private function bookSpace(
        Space $space,
        BookingDetail $bookingDetail,
        $numAttendees,
        Carbon $startDatetimeLocalTz,
        Carbon $endDatetimeLocalTz,
        $bookedByUserId = null,
        $paymentType = null,
        $configurationId = null,
        $paymentToken = null,
        Host $host = null,
        callable $validateBooking = null)
    {
        try
        {
            $this->logger->debug('Start book space');

            // Create new booking request instance
            $bookingRequest = new BookingRequest();
            $bookingRequest->setBookingDetail($bookingDetail);

            // Make sure we have a BookingDetail instance to work with
            if (is_null($bookingDetail))
            {
                throw (new \InvalidArgumentException('$bookingDetail cannot be NULL, even if you do not have details, you need to set it so it can be returned with rates'));
            }

            // Check that host is provided if we have a payment type of invoice
            if (strtolower($paymentType) == self::INVOICE_PAYMENT_TYPE && is_null($host))
            {
                throw (new \InvalidArgumentException('$host cannot be NULL if payment type is: '.self::INVOICE_PAYMENT_TYPE));
            }

            // Check that we have a defined capacity price for the number of attendees specified
            $capacityPrice = $this->spaceMgr->getCapacityPrice($space, $numAttendees);
            if (is_null($capacityPrice))
            {
                throw (new AttendeesOutOfRangeException(sprintf('The attendee number: %d is out of range!', $numAttendees)));
            }

            // Check that the start time isn't gte to the endtime
            if ($startDatetimeLocalTz->gte($endDatetimeLocalTz))
            {
                throw (new StartDatePastEndDateException('The specified startTime is greater than or equal than the endTime!'));
            }

            // Check that there aren't any overlapping bookings
            $spacebookings = $this->getSpaceBookingsWithinDateInterval($space, $startDatetimeLocalTz, $endDatetimeLocalTz);
            if ($spacebookings != null && $spacebookings->count() > 0)
            {
                throw (new BookingContainsAtLeastOneExistingBookingException('The booking interval contains at least one or more existing booking(s)!'));
            }

            // #1. Get the rates for the space
            $bookingRateDetail = $this->rateEngine->calculateSpaceRates($space, $numAttendees, $startDatetimeLocalTz,  $endDatetimeLocalTz);
            $bookingRequest->setBookingRateDetail($bookingRateDetail);

            // Validate the booking
            if ($validateBooking != null)
            {
                $this->logger->info('Start validation for booking');
                $validateBooking($space, $bookingRateDetail);
            }

            // If any of the default params are null, we can't create the booking, but we'll still run validations (in case this is a booking check by caller)
            // We only need to check a few of these params
            if ($bookingDetail != null && $bookedByUserId != null && $configurationId != null)
            {
                // #3. Populate data
                $this->logger->debug('Populating Spacebooking data');

                $spacebooking = new Spacebooking();
                $spacebooking->space_id = $space->id;
                $spacebooking->booked_by_id = $bookedByUserId;
                $spacebooking->configuration_id = $configurationId;
                $spacebooking->event_title = $bookingDetail->event_title;
                $spacebooking->event_description = $bookingDetail->event_description;
                $spacebooking->num_attendees = $numAttendees;
                $spacebooking->payment_type = $paymentType;
                $spacebooking->payment_received = false;    // Default payment to false, until we actually use the paymentService to pay
                $spacebooking->booking_type = $space->booking_type;
                $spacebooking->prep_time_before = $space->prep_time_before;
                $spacebooking->prep_time_after = $space->prep_time_after;
                $spacebooking->space_pricing_hourly_enabled = $space->pricing_hourly_enabled;
                $spacebooking->space_pricing_halfdaily_enabled = $space->pricing_halfdaily_enabled;
                $spacebooking->space_pricing_daily_enabled = $space->pricing_daily_enabled;
                $spacebooking->space_pricing_monthly_enabled = $space->pricing_monthly_enabled;

                $spacebooking->start_datetime = $this->dateService->convertCarbonDateToUTC($startDatetimeLocalTz);
                $spacebooking->end_datetime = $this->dateService->convertCarbonDateToUTC($endDatetimeLocalTz);

                // Set booking data
                $spacebooking->contact_name = $bookingDetail->contact_name;
                $spacebooking->company_name = $bookingDetail->company_name;
                $spacebooking->company_address = $bookingDetail->company_address;
                $spacebooking->company_city = $bookingDetail->company_city;
                $spacebooking->company_postcode = $bookingDetail->company_postcode;
                $spacebooking->company_state = $bookingDetail->company_state;
                $spacebooking->company_country = $bookingDetail->company_country;
                $spacebooking->purchase_order = $bookingDetail->purchase_order;

                // #4. Set the data from booking rates
                $spacebooking->total_price = $bookingRateDetail->totalCost();
                $spacebooking->rate_hour = $bookingRateDetail->maxHourPrice();
                $spacebooking->rate_halfday = $bookingRateDetail->maxHalfDayPrice();
                $spacebooking->rate_day = $bookingRateDetail->maxFullDayPrice();
                $spacebooking->rate_month = $bookingRateDetail->maxMonthPrice();
                $spacebooking->rate_afterhours = $bookingRateDetail->maxAfterHoursPrice();

                $spacebooking->space_day_duration = $space->day_duration;
                $spacebooking->space_month_duration = $space->month_duration;

                $spacebooking->booked_total_hourly_hours = $bookingRateDetail->totalHourlyHours();
                $spacebooking->booked_total_halfday_hours = $bookingRateDetail->totalHalfDayHours();
                $spacebooking->booked_total_day_hours = $bookingRateDetail->totalDayHours();
                $spacebooking->booked_total_month_hours = $bookingRateDetail->totalMonthHours();
                $spacebooking->booked_total_afterhours_hours = $bookingRateDetail->totalAfterHoursHours();

                // TODO: Add addons code here

                // 5. Save the spacebooking
                $this->logger->debug('Saving spacebooking');
                $updatedSpacebooking = $this->spacebookingRepo->save($spacebooking);

                // 6. Make the payment
                $responseData = null;
                if (strtolower($paymentType) == self::CREDIT_CARD_PAYMENT_TYPE)
                {
                    $this->logger->debug("Making a payment for the spacebooking via CREDITCARD");
                    $responseData = $this->paymentService->makePaymentViaToken($space->currency, $bookingRateDetail->totalCost(), $paymentToken);
                }
                else
                {
                    $this->logger->debug('Making a papyment for spacebooking via INVOICE');
                    $responseData = $this->paymentService->makePaymentViaCustomerRef($space->currency, $bookingRateDetail->totalCost(), $host->creditcard->gateway_customer_id);
                }

                // 7. Fill in the payment data
                $this->logger->debug('Filling in payment data from gateway');
                $responseDataSource = $responseData['source'];
                $bookingDetail->payment_transaction_id = $responseData['id'];
                $bookingDetail->payment_total_amount = $responseData['amount'];
                $bookingDetail->cc_name = $responseDataSource['name'];
                $bookingDetail->cc_lastfour = $responseDataSource['last4'];
                $bookingDetail->cc_expiry_month = $responseDataSource['exp_month'];
                $bookingDetail->cc_expiry_year = $responseDataSource['exp_year'];

                // 8. Update status of spacebooking and associated transaction record with data from payment trans
                $this->logger->debug('Updating payment and transaction for spacebooking');
                $transaction = $this->spacebookingRepo->updateSpacebookingPaymentTransaction($updatedSpacebooking, $bookingDetail);

                $bookingRequest->setTransaction($transaction);
            } // if
        } // try
        catch (BookingException $be)
        {
            // Just rethrow, these are known
            throw $be;
        }
        catch (\Exception $e)
        {
            // Unknown exception, log and rethrow
            $this->logger->error(sprintf("Unexpected error has occurred while attempting booking with space id: %d, with num atttendees: %d, for event: %s, booked by: %d",
                $space->id, $numAttendees, $bookingDetail->event_title, $bookedByUserId), ['exception' => $e]);
            $this->logger->error((string)$e);
            throw $e;
        }

        return $bookingRequest;
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookings(Space $space)
    {
        return ($this->spacebookingRepo->getSpaceBookings($space->id));
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingsWithinDateInterval(Space $space, Carbon $startDatetime, Carbon $endDatetime)
    {
        return ($this->spacebookingRepo->getSpaceBookingsWithinDateInterval($space->id, clone $startDatetime, clone $endDatetime));
    }

    /**
     * @inheritDoc
     */
    public function getAllSpaceBookings()
    {
        return ($this->spacebookingRepo->getAllSpaceBookings());
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingsByUserId($userId)
    {
        return ($this->spacebookingRepo->getSpaceBookingsByUserId($userId));
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingById($spacebookingId)
    {
        return ($this->spacebookingRepo->getSpaceBookingById($spacebookingId));
    }

    /**
     * @inheritDoc
     */
    public function getSpaceBookingsByBuildingIdAndUserId($buildingId, $userId = null)
    {
        return ($this->spacebookingRepo->getSpaceBookingsByBuildingIdAndUserId($buildingId, $userId));
    }

    /**
     * @inheritDoc
     */
    public function bookSpaceByHourly(
        Space $space,
        BookingDetail $bookingDetail,
        $numAttendees,
        Carbon $startDatetimeLocalTz,
        Carbon $endDatetimeLocalTz,
        $bookedByUserId = null,
        $paymentType = null,
        $configurationId = null,
        $paymentToken = null,
        Host $host = null)
    {

        // Create hourly booking validation function
        $validateHourlyBooking = function(Space $space, BookingRateDetail $bookingRateDetail) {
            $this->logger->info('Validating hourly booking');

            // Check that hourly is enabled for the space
            if (!$space->pricing_hourly_enabled && !$space->pricing_halfdaily_enabled)
            {
                throw (new HourlyPricingNotEnabledException('Both hourly pricing and halfdaily pricing has not been enabled for this space for the hourly booking!'));
            }

            // Check that the start day is the same as the end day since this is an hourly booking!
            if ($bookingRateDetail->bookingStartDateTime()->diffInDays($bookingRateDetail->bookingEndDateTime()) > 0)
            {
                throw (new StartDayDifferentFromEndDayForHourlyBookingException('The startDatetime is NOT on the same day as endDatetime!  They must be on the same day for Hourly bookings!'));
            }

            // Verify that the day chosen is enabled in the space
            $dayOfWeek = $bookingRateDetail->bookingStartDateTime()->dayOfWeek;
            $isValidDayOfWeek = true;

            if ($dayOfWeek == Carbon::MONDAY && !$space->is_available_mon)
            {
                $isValidDayOfWeek = false;
            }
            else if ($dayOfWeek == Carbon::TUESDAY && !$space->is_available_tue)
            {
                $isValidDayOfWeek = false;
            }
            else if ($dayOfWeek == Carbon::WEDNESDAY && !$space->is_available_wed)
            {
                $isValidDayOfWeek = false;
            }
            else if ($dayOfWeek == Carbon::THURSDAY && !$space->is_available_thu)
            {
                $isValidDayOfWeek = false;
            }
            else if ($dayOfWeek == Carbon::FRIDAY && !$space->is_available_fri)
            {
                $isValidDayOfWeek = false;
            }
            else if ($dayOfWeek == Carbon::SATURDAY && !$space->is_available_sat)
            {
                $isValidDayOfWeek = false;
            }
            else if ($dayOfWeek == Carbon::SUNDAY && !$space->is_available_sun)
            {
                $isValidDayOfWeek = false;
            }

            if (!$isValidDayOfWeek)
            {
                throw (new UnavailableHourlyBookingDayOfWeekException('The booking has been made on a day that is unavailable!'));
            }

            // Validate if there are after hours hours, if there are, we need to make sure that the space allows after hours hours
            $bookingStartTime = clone $bookingRateDetail->bookingStartDateTime();
            $afterHoursTime = $bookingStartTime->addMinutes($space->day_duration);
            if ($bookingRateDetail->bookingEndDateTime()->gt($afterHoursTime) && !$space->is_available_afterhours)
            {
                throw (new UnavailableHourlyBookingAfterhoursException('The booking has been made with after hours hours which are unavailable'));
            }

            // Validate if any blacklist dates overlap with the start and end datetime range
            $blacklistDates = $this->spaceMgr->getBlackListDates($space, $bookingRateDetail->bookingStartDateTime(), $bookingRateDetail->bookingEndDateTime());
            if (!empty($blacklistDates) && $blacklistDates->count() > 0)
            {
                $blacklistEx = new HourlyBookingContainsAtLeastOneBlacklistDateException('The booking contains at least one overlapping blacklist date');
                $blacklistEx->setBlacklistDates($blacklistDates->toArray());
                throw $blacklistEx;
            }
        };

        // Call internal bookspace
        return
            $this->bookSpace(
            $space,
            $bookingDetail,
            $numAttendees,
            $startDatetimeLocalTz,
            $endDatetimeLocalTz,
            $bookedByUserId,
            $paymentType,
            $configurationId,
            $paymentToken,
            $host,
            $validateHourlyBooking
        );
    }

    /**
     * @inheritDoc
     */
    public function bookSpaceByDaily(
        Space $space,
        BookingDetail $bookingDetail,
        $numAttendees,
        Carbon $startDatetimeLocalTz,
        Carbon $endDatetimeLocalTz,
        $bookedByUserId = null,
        $paymentType = null,
        $configurationId = null,
        $paymentToken = null,
        Host $host = null)
    {

        // Create validate daily booking function
        $validateDailyBooking = function (Space $space, BookingRateDetail $bookingRateDetail)
        {
            $this->logger->info('Validating daily booking');

            // Check that either daily or monthly or both are enabled
            if (!$space->pricing_daily_enabled && !$space->pricing_monthly_enabled)
            {
                throw (new DailyPricingAndMonthlyPricingNotEnabled('Both daily or monthly pricing is not enabled for Daily bookings!'));
            }

            // Check if the number of days is gte to 1
            if ($bookingRateDetail->bookingEndDateTime()->diffInDays($bookingRateDetail->bookingStartDateTime()) < 1)
            {
                throw (new DailyBookingDaysLessThanOneException('The daily booking must have more than 1 day!'));
            }
        };

        // Convert date to full day depending on space
        $startDatetimeLocalTzDaily = Carbon::createFromFormat('Y-m-d H:i:s', "{$startDatetimeLocalTz->toDateString()} {$space->day_start_time}", $startDatetimeLocalTz->tzName);
        $endDatetimeLocalTzDaily = Carbon::createFromFormat('Y-m-d H:i:s', "{$endDatetimeLocalTz->toDateString()} {$space->day_start_time}", $endDatetimeLocalTz->tzName)->addMinutes($space->day_duration);

        // Call internal bookspace
        return
            $this->bookSpace(
            $space,
            $bookingDetail,
            $numAttendees,
            $startDatetimeLocalTzDaily,
            $endDatetimeLocalTzDaily,
            $bookedByUserId,
            $paymentType,
            $configurationId,
            $paymentToken,
            $host,
            $validateDailyBooking
        );
    }

}