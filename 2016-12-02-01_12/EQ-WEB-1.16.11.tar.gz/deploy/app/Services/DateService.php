<?php namespace App\Services;

use App\Services\IDateService;
use Carbon\Carbon;

class DateService implements IDateService {

    /**
     * @inheritDoc
     */
    public function convertDateToUTC($datetime, $fromTimezone = 'Australia/Sydney')
    {
        $object = Carbon::createFromFormat('Y-m-d H:i:s', $datetime, $fromTimezone)->setTimezone('UTC');
        $datetime = $object->toDateTimeString();
        return $datetime;
    }

    /**
     * @inheritDoc
     */
    public function convertDateToTimezone($datetime, $fromTimezone = 'UTC', $toTimezone = 'Australia/Sydney')
    {
        $object = Carbon::createFromFormat('Y-m-d H:i:s', $datetime, $fromTimezone)->setTimezone($toTimezone);
        $datetime = $object->toDateTimeString();
        return $datetime;
    }

    /**
     * @inheritDoc
     */
    public function convertCarbonDateToUTC(Carbon $dateTimeLocal)
    {
        return ($dateTimeLocal->tz('UTC'));
    }
}