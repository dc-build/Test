<?php

namespace App\Services\Exceptions;

/**
 * Custom exception for attendees out of range exception
 *
 * Class AttendeesOutOfRangeException
 */
class AttendeesOutOfRangeException extends BookingException
{
}