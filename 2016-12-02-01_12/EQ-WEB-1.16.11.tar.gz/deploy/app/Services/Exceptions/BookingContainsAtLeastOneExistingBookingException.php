<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 17/11/2016
 * Time: 2:01 PM
 */

namespace App\Services\Exceptions;


/**
 * Custom exception to throw when an existing booking
 *
 * Class BookingContainsAtLeastOneExistingBookingException
 * @package App\Services\Exceptions
 */
class BookingContainsAtLeastOneExistingBookingException extends BookingException
{
}