<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 3:28 PM
 */

namespace App\Services\Exceptions;


use Exception;

/**
 * Base BookingException so we can catch just this type instead of of multiple catch statements if necessary
 *
 * Class BookingException
 * @package App\Services\Exceptions
 */
class BookingException extends \Exception
{
}