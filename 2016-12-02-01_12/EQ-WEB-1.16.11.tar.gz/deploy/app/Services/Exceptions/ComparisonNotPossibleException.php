<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 17/11/2016
 * Time: 23:05
 */

namespace App\Services\Exceptions;

use Exception;

/**
 * Used when attempting to compare values with dynamically specified comparators
 *
 * Class ComparisonNotPossibleException
 * @package App\Services\Exceptions
 */
class ComparisonNotPossibleException extends Exception
{
}