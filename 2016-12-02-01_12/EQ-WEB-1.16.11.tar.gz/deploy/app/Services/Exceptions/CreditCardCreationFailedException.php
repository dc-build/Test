<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 29/11/2016
 * Time: 12:55
 */

namespace App\Services\Exceptions;

/**
 * Custom exception for handling failures to create a Credit Card
 *
 * Class CreditCardCreationFailedException
 * @package App\Services\Exceptions
 */
class CreditCardCreationFailedException extends StripeAPIResponseException
{
}