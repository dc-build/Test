<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 9:11 AM
 */

namespace App\Services\Exceptions;

use Exception;

/**
 * Custom exception for handling daily bookings with less than 1 day
 *
 * Class DailyBookingDaysLessThanOneException
 * @package App\Services\Exceptions
 */
class DailyBookingDaysLessThanOneException extends BookingException
{
}