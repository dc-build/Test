<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 11:14 AM
 */

namespace App\Services\Exceptions;


use Exception;

/**
 * Custom exception when Daily Pricing is called without daily pricing or monthly pricing enabled
 *
 * Class DailyPricingAndMonthlyPricingNotEnabled
 * @package App\Services\Exceptions
 */
class DailyPricingAndMonthlyPricingNotEnabled extends BookingException
{
}