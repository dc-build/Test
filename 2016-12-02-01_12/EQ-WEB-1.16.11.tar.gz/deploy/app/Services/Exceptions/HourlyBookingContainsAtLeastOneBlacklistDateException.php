<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 8:49 PM
 */

namespace App\Services\Exceptions;


/**
 * Custom exception for Hourly bookings when a blacklist date overlaps with the booking
 *
 * Class HourlyBookingContainsAtLeastOneBlacklistDateException
 * @package App\Services\Exceptions
 */
class HourlyBookingContainsAtLeastOneBlacklistDateException extends BookingException
{
    private $blacklistDates = null;

    /**
     * @return array
     */
    public function getBlacklistDates()
    {
        return $this->blacklistDates;
    }

    /**
     * @param null $blacklistDates
     */
    public function setBlacklistDates($blacklistDates)
    {
        $this->blacklistDates = $blacklistDates;
    }
}