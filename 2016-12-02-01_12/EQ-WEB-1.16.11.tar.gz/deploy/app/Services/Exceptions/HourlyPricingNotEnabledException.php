<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 11:11 AM
 */

namespace App\Services\Exceptions;


use Exception;

/**
 * Custom class for when hourly pricing isn't enabled for Hourly bookings
 *
 * Class HourlyPricingNotEnabledException
 * @package App\Services\Exceptions
 */
class HourlyPricingNotEnabledException extends BookingException
{
}