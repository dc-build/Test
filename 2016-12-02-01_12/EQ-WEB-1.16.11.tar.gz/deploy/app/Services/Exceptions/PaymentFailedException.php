<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 2:00 PM
 */

namespace App\Services\Exceptions;

/**
 * Custom exception for payment exceptions
 *
 * Class PaymentFailedException
 * @package App\Services\Exceptions
 */
class PaymentFailedException extends BookingException
{
    private $responseData = null;

    /**
     * @return null
     */
    public function getResponseData()
    {
        return $this->responseData;
    }

    /**
     * @param null $responseData
     */
    public function setResponseData($responseData)
    {
        $this->responseData = $responseData;
    }

}