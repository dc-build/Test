<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 16/11/2016
 * Time: 12:21 PM
 */

namespace App\Services\Exceptions;

use App\Models\Spacebooking;

/**
 * Custom exception for updating spacebookings
 *
 * Class SpacebookingUpdateException
 * @package App\Services\Exceptions
 */
class SpacebookingUpdateException extends BookingException
{
    private $spacebooking = null;

    /**
     * @return Spacebooking
     */
    public function getSpacebooking()
    {
        return $this->spacebooking;
    }

    /**
     * @param Spacebooking $spacebooking
     */
    public function setSpacebooking($spacebooking)
    {
        $this->spacebooking = $spacebooking;
    }
}