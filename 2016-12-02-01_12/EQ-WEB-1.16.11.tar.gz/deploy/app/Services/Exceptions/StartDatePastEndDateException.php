<?php

namespace App\Services\Exceptions;

/**
 * Custom exception for when Start date passes End Date
 *
 * Class StartDatePastEndDateException
 */
class StartDatePastEndDateException extends BookingException
{
}