<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 14/11/2016
 * Time: 10:03 PM
 */

namespace App\Services\Exceptions;

use Exception;

/**
 * Custom exception for when start day is same as end day for hourly bookings
 *
 * Class StartDayDifferentFromEndDayForHourlyBookingException
 * @package App\Services\Exceptions
 */
class StartDayDifferentFromEndDayForHourlyBookingException extends BookingException
{
}