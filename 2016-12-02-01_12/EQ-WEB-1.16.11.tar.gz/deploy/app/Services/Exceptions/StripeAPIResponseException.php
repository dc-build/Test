<?php
/**
 * Created by PhpStorm.
 * User: johnquintal
 * Date: 30/11/2016
 * Time: 11:24
 */

namespace App\Services\Exceptions;


class StripeAPIResponseException extends \Exception
{
    private $responseData = null;

    /**
     * @return null
     */
    public function getResponseData()
    {
        return $this->responseData;
    }

    /**
     * @param null $responseData
     */
    public function setResponseData($responseData)
    {
        $this->responseData = $responseData;
    }
}