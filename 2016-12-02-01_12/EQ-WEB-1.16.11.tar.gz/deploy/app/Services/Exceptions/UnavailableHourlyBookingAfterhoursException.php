<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 14/11/2016
 * Time: 8:52 PM
 */

namespace App\Services\Exceptions;

use Exception;

/**
 * Custom exception for bookings made when after hours are unavailable
 *
 * Class UnavailableHourlyBookingAfterhoursException
 * @package App\Services\Exceptions
 */
class UnavailableHourlyBookingAfterhoursException extends BookingException
{
}