<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 14/11/2016
 * Time: 5:28 PM
 */

namespace App\Services\Exceptions;


use Exception;

/**
 * Custom exception for Unavailable Day of Week exceptions
 *
 * Class UnavailableHourlyBookingDayOfWeekException
 * @package App\Services\Exceptions
 */
class UnavailableHourlyBookingDayOfWeekException extends BookingException
{
}