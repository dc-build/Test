<?php

namespace App\Services;

use App\Models\Host;
use App\Models\Popo\BookingDetail;
use App\Models\Popo\BookingRequest;
use App\Models\Space;
use App\Models\Spacebooking;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;

/**
 * Interface for defining BookingEngine
 *
 * Interface IBookingEngineService
 * @package App\Services
 */
interface IBookingEngineService
{
    /**
     * Books a space HOURLY with specified startTime, endTime and number of attendees
     *
     * @param Space $space
     * @param BookingDetail $bookingDetail
     * @param $numAttendees
     * @param Carbon $startDatetimeLocalTz
     * @param Carbon $endDatetimeLocalTz
     * @param $bookedByUserId
     * @param null $paymentType
     * @param $configurationId
     * @param $paymentToken
     * @param Host $host
     * @return BookingRequest
     */
    public function bookSpaceByHourly(
        Space $space,
        BookingDetail $bookingDetail,
        $numAttendees,
        Carbon $startDatetimeLocalTz,
        Carbon $endDatetimeLocalTz,
        $bookedByUserId = null,
        $paymentType = null,
        $configurationId = null,
        $paymentToken = null,
        Host $host = null);

    /**
     * Books a space HOURLY with specified startTime, endTime and number of attendees
     *
     * @param Space $space
     * @param BookingDetail $bookingDetail
     * @param $numAttendees
     * @param Carbon $startDatetimeLocalTz
     * @param Carbon $endDatetimeLocalTz
     * @param $bookedByUserId
     * @param null $paymentType
     * @param $configurationId
     * @param $paymentToken
     * @param Host $host
     * @return BookingRequest
     */
    public function bookSpaceByDaily(
        Space $space,
        BookingDetail $bookingDetail,
        $numAttendees,
        Carbon $startDatetimeLocalTz,
        Carbon $endDatetimeLocalTz,
        $bookedByUserId = null,
        $paymentType = null,
        $configurationId = null,
        $paymentToken = null,
        Host $host = null);

    /**
     * Gets all bookings for a specified space
     *
     * @param Space $space
     * @return Collection of Spacebookings
     */
    public function getSpaceBookings(Space $space);

    /**
     * @param Space $space
     * @param Carbon $startDatetime
     * @param Carbon $endDatetime
     * @return mixed
     */
    public function getSpaceBookingsWithinDateInterval(Space $space, Carbon $startDatetime, Carbon $endDatetime);

    /**
     * Gets all bookings for a specified user
     *
     * @param $userId
     * @return Collection of Spacebookings
     */
    public function getSpaceBookingsByUserId($userId);

    /**
     * @param $spacebookingId
     * @return Spacebooking
     */
    public function getSpaceBookingById($spacebookingId);

    /**
     * @param $buildingId
     * @param null $userId
     * @return Collection of Spacebookings
     */
    public function getSpaceBookingsByBuildingIdAndUserId($buildingId, $userId = null);

    /**
     * Gets all space bookings in the system
     * NOTE: Careful using this as this could be a lot of them!
     *
     * @return Collection of Spacebookings
     */
    public function getAllSpaceBookings();

}