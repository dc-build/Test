<?php namespace App\Services;

use Carbon\Carbon;

/**
 * Interface for defining a DateService
 *
 * Interface IDateService
 * @package App\Services
 */
interface IDateService {

    /**
     * @param $datetime
     * @param string $fromTimezone
     * @return mixed
     */
    public function convertDateToUTC($datetime, $fromTimezone = 'Australia/Sydney');

    /**
     * @param Carbon $dateTimeLocal
     * @return Carbon
     */
    public function convertCarbonDateToUTC(Carbon $dateTimeLocal);

    /**
     * @param $datetime
     * @param string $fromTimezone
     * @param string $toTimezone
     * @return mixed
     */
    public function convertDateToTimezone($datetime, $fromTimezone = 'UTC', $toTimezone = 'Australia/Sydney');

}