<?php namespace App\Services;

interface IImageService {

    
    /**
     * Upload image functionality - will automatically create directory, generates uuid, and save to database provided model is defined
     * $model is optional - specify model (e.g. New App\Models\Image) to automatically save to database
     * requires file_size and file_ext fields in database
     * @param input $file
     * @param array $additional_fields
     * @param string $path (base path)
     * @param model $model (e.g. New App\Models\Image)
     * @return this
     */
    public function uploadImage($file, $additional_fields, $path, $model);
    
    /**
     * Save image to database
     * @param array $imageData (requires image_uuid, file_size and file_ext)
     * @param string $uuid
     * @param model $model
     * @return this
     */
    public function saveImage(array $imageData, $uuid, $model);
    
    /**
     * Create upload directory
     * @param string $path (base path)
     */
    public function createUploadDirectory($path);
    
    /**
     * generate uuid    
     * @return this
     */
    public function generateUUID();

    /**
     * Takes the string name of an image type and returns the id
     * @param $type_string
     * @return string
     */
    public function getImageTypeId($type_string);



}