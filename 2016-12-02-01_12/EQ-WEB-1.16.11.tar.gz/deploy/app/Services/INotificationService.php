<?php namespace App\Services;

use Carbon\Carbon;

/**
 * Interface for defining a NotificationService
 *
 * Interface INotificationService
 * @package App\Services
 */
interface INotificationService {

    public function sendBookingMadeNotification($booking, $user);


}