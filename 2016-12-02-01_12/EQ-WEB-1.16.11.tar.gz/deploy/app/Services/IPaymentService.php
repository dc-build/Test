<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 11:51 AM
 */

namespace App\Services;


/**
 * Interface for implementing a Payment service
 *
 * Interface IPaymentService
 * @package App\Services
 */
interface IPaymentService
{
    /**
     * @return string - represents API key
     */
    public function getApiKey();

    /**
     * @param null $apiKey
     */
    public function setApiKey($apiKey = null);

    /**
     * @param null $apiKey
     * @return mixed
     */
    public function init($apiKey = null);

    /**
     * @param string $currency
     * @param float $paymentAmount - This is the amount to be paid
     * @param string $paymentToken - This is the token to use for payment (in place of cc details)
     * @return array
     */
    public function makePaymentViaToken($currency, $paymentAmount, $paymentToken);

    /**
     * @param $currency
     * @param $paymentAmount
     * @param $customerRef
     * @return array
     */
    public function makePaymentViaCustomerRef($currency, $paymentAmount, $customerRef);
}