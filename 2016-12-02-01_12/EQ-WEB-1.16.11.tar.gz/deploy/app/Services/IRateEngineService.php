<?php namespace App\Services;

use App\Models\Space;
use Carbon\Carbon;
use Illuminate\Support\Collection;

interface IRateEngineService {

    /**
     * Takes a $space record and the requested number of attendees, dates and times and returns a RateDetail object
     * which breaks it all down
     *
     * @param \App\Models\Space $space
     * @param $numberOfAttendees
     * @param \Carbon\Carbon $startDateTime
     * @param \Carbon\Carbon $endDateTime
     *
     * @returns \App\Models\Popo\BookingRateDetail
     */
    public function calculateSpaceRates(Space $space, $num_attendees, Carbon $startDateTime, Carbon $endDateTime);

    /**r
     * Takes a collection of spaces, the number of attendees and the dates and appends the RateDetails to each individual space
     * @param \Illuminate\Database\Eloquent\Collection $spaces
     * @param $num_attendees
     * @param \Carbon\Carbon $startDateTime
     * @param \Carbon\Carbon $endDateTime
     * @return mixed
     */
    public function calculateSpaceRatesForCollection(Collection $spaces, $num_attendees, Carbon $startDateTime, Carbon $endDateTime);

}