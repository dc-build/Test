<?php namespace App\Services;

use App\Models\Space;
use Carbon\Carbon;
use Illuminate\Support\Collection;

/**
 * Interface ISpaceManagerService
 * @package App\Services
 */
interface ISpaceManagerService {

    /**
     * Returns the minimum increment in minutes that a space will charge in
     *
     * @param \App\Models\Space $space
     * @return mixed
     */
    public function minChargeIncrementHourlyBooking(Space $space);

    /**
     * Returns the minimum increment in minutes that a space can charge in for daily bookings
     *
     * The minimum increment is based on the spaces enabled pricing options.
     *
     * @param \App\Models\Space $space
     * @return int
     */
    public function minChargeIncrementDailyBooking(Space $space);

    /**
     * Returns an array with the afterhours start and end time of a space
     *
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $bookingStartTime
     * @return array
     */
    public function getSpaceAfterHoursTimes(Space $space, Carbon $bookingStartTime);

    /**
     * Returns the correct capacityprice for the number of attendees
     * @param \App\Models\Space $space
     * @param $attendees
     */
    public function getCapacityPrice(Space $space, $attendees);


    /**
     * Takes a space and a date and returns true if the date is available for booking
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $date
     * @param \Illuminate\Support\Collection $blackListDates
     * @return bool
     */
    public function isDayAvailable(Space $space, Carbon $date, Collection $blackListDates);

    /**
     * Returns the Blacklisted dates for a space that occur between 2 dates
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $startDate
     * @param Carbon $endDate
     * @return Collection
     */
    public function getBlackListDates(Space $space, Carbon $startDate, Carbon $endDate);

    /**
     * Returns the number of days that a space has been booked for, taking into account the days
     * that the space has been configures to be available, and blacklist dates.
     *
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $startDate
     * @param \Carbon\Carbon $endDate
     * @return int
     */
    public function getActualBookedDayCount(Space $space, Carbon $startDate, Carbon $endDate);

}