<?php namespace App\Services;

interface IUuidService {

    /**
     * generate uuid    
     * @return this
     */
    public function generateUUID();
}