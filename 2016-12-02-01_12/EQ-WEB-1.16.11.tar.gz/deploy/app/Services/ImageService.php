<?php namespace App\Services;

use App\Exceptions\ImageTypeNotFoundException;
use App\Models\Imagetype;
use App\Services\IImageService;
use App\Services\IUuidService;
use Illuminate\Support\Facades\File;
use Illuminate\Database\DatabaseManager;

class ImageService implements IImageService {
    
    protected $uuidService;
    private $imageTypes = NULL;
    
    public function __construct(IUuidService $uuidService)
    {
        $this->uuidService = $uuidService;
    }

    public function uploadImage($file, $additional_fields, $path, $model=null) {
        $this->createUploadDirectory($path);
        
        //get input file details
        $extension = $file->getClientOriginalExtension();
        $filesize = $file->getClientSize();
        
        //generate UUID
        $fileid = $this->uuidService->generateUUID();
        
        //get filename
        $filename = strtolower($fileid->string).'.'.strtolower($extension);

        //upload image to specified path
        $uploadResult = $file->move($path, $filename);
        
        //check if upload is successful and if model is defined
        if ($uploadResult && !is_null($model)) {
            $image["file_size"] = $filesize;
            $image["file_ext"] = strtolower($extension);
            if (!is_null($additional_fields)) {
                foreach ($additional_fields as $key => $value) {
                    $image[$key] = $value;
                }
            }
            
            //save image and get image id
            $image_id = $this->saveImage($image, $fileid, $model);
            
            //return image id
            $uploadResult = $image_id;
        }
        return $uploadResult;
    }
    
    public function saveImage(array $imageData, $uuid, $model) {
        $image = $model;
        $image->image_uuid = $uuid;
        
        foreach ($imageData as $key => $value) {
            $image->$key = $value;
        }
        $image->save();
        return $image->id;
    }
    
    public function createUploadDirectory($path) {
        if(!File::exists($path)) {
            File::makeDirectory($path, 0775, true);
        }
    }
    
    public function generateUUID() {
        $uuid = Uuid::generate();
        return $uuid;
    }

    /**
     * Takes the string name of an image type and returns the id
     * @param $type_string
     * @return string
     */
    public function getImageTypeId($type_string)
    {
        if($this->imageTypes == NULL)
        {
            $this->imageTypes = Imagetype::all()->keyBy('name');
        }

        if($this->imageTypes->has($type_string))
        {
            $value = $this->imageTypes->get($type_string);
            return $value->id;
        }
        else
        {
            throw new ImageTypeNotFoundException('The image type ' . $type_string . ' was not found');
        }
    }
    
}