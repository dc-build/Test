<?php namespace App\Services;

use App\Services\INotificationService;
use Carbon\Carbon;

class NoptificationService implements INotificationService
{

    /**
     * @inheritDoc
     */
    public function sendBookingMadeNotification($booking, $user)
    {
        $data = ['booking' => $booking];
        Mail::queue('emails.admin.booking.booked', $data, function ($m) use ($booking, $user) {
            $m->from(env('fsmsettings.from_email'));
            $m->to($booking->spaces->host->contact_email, $booking->spaces->host->contact_name)
              ->subject("New booking");
        });
    }
}