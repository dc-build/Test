<?php namespace App\Services;

use App\Models\Popo\BookingRateDetail;
use App\Models\Space;
use App\Services\IRateEngineService;
use App\Services\ISpaceManagerService;
use Carbon\Carbon;
use Illuminate\Support\Collection;

/**
 * Class RateEngineService
 * @package App\Services
 */
class RateEngineService implements IRateEngineService
{
    /** @var BookingRateDetail */
    protected $rateDetail;

    /** @var Space */
    protected $space;

    /** @var Carbon */
    protected $bookingStartDateTime;

    /** @var Carbon */
    protected $bookingEndDateTime;

    /** @var  ISpaceManagerService */
    protected $spaceService;

    /**
     * Inject the Space Service
     *
     * RateEngineService constructor.
     * @param \App\Services\ISpaceManagerService $spaceService
     */
    public function __construct(ISpaceManagerService $spaceService)
    {
        $this->spaceService = $spaceService;
    }

    /**
     * Takes a $space record and the requested number of attendees, dates and times and returns a RateDetail object
     * which breaks it all down
     *
     * @param \App\Models\Space $space
     * @param $numberOfAttendees
     * @param \Carbon\Carbon $startDateTime
     * @param \Carbon\Carbon $endDateTime
     *
     * @returns \App\Models\Popo\BookingRateDetail
     */
    public function calculateSpaceRates(Space $space, $numberOfAttendees, Carbon $startDateTime, Carbon $endDateTime)
    {
        //Get the capacity pricing from the space service
        $capacityPrice = $this->spaceService->getCapacityPrice($space, $numberOfAttendees);

        $this->rateDetail = new BookingRateDetail($space, $capacityPrice, $startDateTime, $endDateTime);
        $this->space = $space;
        $this->bookingStartDateTime = clone $startDateTime;
        $this->bookingEndDateTime = clone $endDateTime;

        //Determine if the booking is for days or hours
        if($this->bookingEndDateTime->diffInDays($this->bookingStartDateTime) == 0)
        {
            $this->breakOutHourChunks();
        }
        else
        {
            $this->breakOutDayChunks();
        }

        return $this->rateDetail;
    }

    /**
     * Takes a collection of spaces, the number of attendees and the dates and appends the RateDetails to each individual space
     * @param Collection $spaces
     * @param $num_attendees
     * @param \Carbon\Carbon $startDateTime
     * @param \Carbon\Carbon $endDateTime
     * @return mixed
     */
    public function calculateSpaceRatesForCollection(Collection $spaces, $num_attendees, Carbon $startDateTime, Carbon $endDateTime)
    {
        foreach($spaces as $space)
        {
            $rateDetail = $this->calculateSpaceRates($space, $num_attendees, $startDateTime, $endDateTime);

            $space->maxHourlyPrice = $rateDetail->maxHourPrice();
            $space->maxHalfDayPrice = $rateDetail->maxHalfDayPrice();
            $space->maxFullDayPrice = $rateDetail->maxFullDayPrice();
            $space->maxMonthPrice = $rateDetail->maxMonthPrice();
        }

        return $spaces;
    }



    /**
     * Break out the hours into chunks of time based on the rules of the space
     */
    protected function breakOutHourChunks()
    {
        //set everything to 0 as default
        $hours = 0; $halfDayHours = 0; $bookedAfterHoursMins = 0; $dayHours = 0; $monthHours = 0;

        $chargeIncrement = $this->spaceService->minChargeIncrementHourlyBooking($this->space);

        $halfDayDuration = $this->space->day_duration / 2;

        //If the booking is after hours we need to split those hours from the rest
        if($this->space->is_available_afterhours == true)
        {
            //get the after hours times
            $afterHoursTimes = $this->spaceService->getSpaceAfterHoursTimes($this->space, $this->bookingStartDateTime);

            if($this->bookingEndDateTime->gt($afterHoursTimes['start']))
            {
                $bookedAfterHoursMins = $this->bookingEndDateTime->diffInMinutes($afterHoursTimes['start']);
            }
        }

        //get the total number of minutes for the booking, round to the increment and convert to hours
        $actualStandardMinutes = $this->bookingEndDateTime->diffInMinutes($this->bookingStartDateTime) - $bookedAfterHoursMins;
        $bookedStandardMinutes = ceil($actualStandardMinutes / $chargeIncrement) * $chargeIncrement;

        //after hours is rounded to the nearest hour
        $roundedAfterHoursMins = ceil($bookedAfterHoursMins / 60) * 60;
        $bookedAfterHourHours = $roundedAfterHoursMins / 60;

        //ensure that the time is split into the correct chunks.
        //We work backwards from daily to hourly
        if($this->space->pricing_daily_enabled && $bookedStandardMinutes == $this->space->day_duration)
        {
            $dayHours = $bookedStandardMinutes / 60;
        }
        else if($this->space->pricing_halfdaily_enabled && $bookedStandardMinutes >= $halfDayDuration)
        {
            if($bookedStandardMinutes == $this->space->day_duration)
            {
                $halfDayHours = $bookedStandardMinutes / 60;
            }
            else
            {
                $halfDayHours = $halfDayDuration / 60;
                $hours = ($bookedStandardMinutes - $halfDayDuration) / 60;
            }
        }
        else if($this->space->pricing_hourly_enabled)
        {
            $hours = $bookedStandardMinutes / 60;
        }

        $this->rateDetail->setTimeChunks($hours, $halfDayHours, $bookedAfterHourHours, $dayHours, $monthHours);
    }


    /**
     * Break out the days into chunks of time based on the rules of the space
     */
    protected function breakOutDayChunks()
    {
        //set everything to 0 as default
        $hours = 0; $halfDayHours = 0; $afterHoursHours = 0; $dayHours = 0; $monthHours = 0;

        $chargeIncrement = $this->spaceService->minChargeIncrementDailyBooking($this->space);

        //get the total number of day hours for the booking
        $bookedDays = $this->spaceService->getActualBookedDayCount($this->space, $this->bookingStartDateTime, $this->bookingEndDateTime);
        $roundedDays = ceil($bookedDays / $chargeIncrement) * $chargeIncrement;


        //ensure that the time is split into the correct chunks.
        //We work backwards from monthly to daily
        if($this->space->pricing_monthly_enabled && $roundedDays >= $this->space->month_duration)
        {
            $ratio = $roundedDays / $this->space->month_duration;
            $fullMonths = floor($ratio);

            $monthHours = $fullMonths * $this->space->month_duration * ($this->space->day_duration / 60);
            $dayHours = ($roundedDays % $this->space->month_duration) * ($this->space->day_duration / 60);
        }
        elseif($this->space->pricing_daily_enabled && $roundedDays >= 1)
        {
            $dayHours = $roundedDays * ($this->space->day_duration / 60);
        }

        $this->rateDetail->setTimeChunks($hours, $halfDayHours, $afterHoursHours, $dayHours, $monthHours);
    }

}