<?php namespace App\Services;

use App\Models\Blacklistdate;
use App\Models\Space;
use App\Services\ISpaceManagerService;
use Carbon\Carbon;
use Illuminate\Support\Collection;

/**
 * Contains methods for the Space business logic
 *
 * Class SpaceService
 * @package App\Services
 */
class SpaceManagerService implements ISpaceManagerService
{
    /**
     * @var IDateService
     */
    private $dateService;

    /**
     * SpaceManagerService constructor.
     * @param IDateService $dateService
     */
    public function __construct(IDateService $dateService)
    {
        $this->dateService = $dateService;
    }

    /**
     * Returns the minimum increment in minutes that a space can charge in for hourly bookings
     *
     * The minimum increment is based on the spaces enabled pricing options.
     *
     * @param \App\Models\Space $space
     * @return int
     */
    public function minChargeIncrementHourlyBooking(Space $space)
    {
        $minIncrement = 0;

        if($space->pricing_hourly_enabled == true)
        {
            $minIncrement = 60;
        }
        elseif($space->pricing_halfdaily_enabled == true)
        {
            $minIncrement = $space->day_duration / 2;
        }
        elseif($space->pricing_daily_enabled == true)
        {
            $minIncrement = $space->day_duration;
        }

        return $minIncrement;
    }


    /**
     * Returns the minimum increment in days that a space can charge in daily bookings
     *
     * The minimum increment is based on the spaces enabled pricing options.
     *
     * @param \App\Models\Space $space
     * @return int
     */
    public function minChargeIncrementDailyBooking(Space $space)
    {
        $minIncrement = 0;

        if($space->pricing_daily_enabled == true)
        {
            $minIncrement = 1;
        }
        elseif($space->pricing_monthly_enabled == true)
        {
            $minIncrement = $space->month_duration;
        }

        return $minIncrement;
    }

    /**
     * Returns an array with the afterhours start and end time of a space
     *
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $bookingStartTime
     * @return array
     */
    public function getSpaceAfterHoursTimes(Space $space, Carbon $bookingStartTime)
    {
        $spaceStart = new Carbon($bookingStartTime->year . "/" . $bookingStartTime->month . "/" . $bookingStartTime->day . " " . $space->day_start_time, $bookingStartTime->tz);

        $afterHoursStart = new Carbon($spaceStart, $spaceStart->tz);
        $afterHoursStart->addHours($space->day_duration / 60);

        $afterHoursEnd = new Carbon($afterHoursStart, $spaceStart->tz);
        $afterHoursEnd->addHours($space->after_hours_duration / 60);

        $afterHoursTime = ['start' => $afterHoursStart, 'end' => $afterHoursEnd];

        return $afterHoursTime;
    }

    /**
     * Returns the correct capacityprice for the number of attendees
     * @param \App\Models\Space $space
     * @param $attendees
     */
    public function getCapacityPrice(Space $space, $attendees)
    {
        $capacityPrice = $space->capacityprices->first(function ($key, $value) use ($attendees) {
            return ($attendees >= $value->attendees_min && $attendees <= $value->attendees_max);
        });

        return $capacityPrice;
    }


    /**
     * Takes a space and a date and returns true if the date is available for booking
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $date
     * @param \Illuminate\Support\Collection $blackListDates
     * @return bool
     */
    public function isDayAvailable(Space $space, Carbon $date, Collection $blackListDates)
    {
        $isAvailable = false;

        // Check blacklisted dates first
        $utcDate = $date;
        if (!$date->utc)
            $utcDate = $this->dateService->convertCarbonDateToUTC($date);
        $isBlackListed = $blackListDates->contains(function ($key, $value) use ($utcDate)
        {
            return ($utcDate->between(Carbon::parse($value->start_datetime), Carbon::parse($value->end_datetime)));
        });

        if($isBlackListed == TRUE)
        {
            return $isAvailable;
        }

        //Check the rest of the days
        if($date->dayOfWeek == Carbon::MONDAY && $space->is_available_mon == TRUE)
        {
            $isAvailable = true;
        }
        elseif($date->dayOfWeek == Carbon::TUESDAY && $space->is_available_tue == TRUE)
        {
            $isAvailable = true;
        }
        elseif($date->dayOfWeek == Carbon::WEDNESDAY && $space->is_available_wed == TRUE)
        {
            $isAvailable = true;
        }
        elseif($date->dayOfWeek == Carbon::THURSDAY && $space->is_available_thu == TRUE)
        {
            $isAvailable = true;
        }
        elseif($date->dayOfWeek == Carbon::FRIDAY && $space->is_available_fri == TRUE)
        {
            $isAvailable = true;
        }
        elseif($date->dayOfWeek == Carbon::SATURDAY && $space->is_available_sat == TRUE)
        {
            $isAvailable = true;
        }
        elseif($date->dayOfWeek == Carbon::SUNDAY && $space->is_available_sun == TRUE)
        {
            $isAvailable = true;
        }

        return $isAvailable;
    }

    /**
     * Returns the Blacklisted dates for a space that occur between 2 dates
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $startDate
     * @param \Carbon\Carbon $endDate
     * @return Collection
     */
    public function getBlackListDates(Space $space, Carbon $startDate, Carbon $endDate)
    {
        $utcStartDatetime = $startDate;
        $utcEndDatetime = $endDate;
        if (!$startDate->utc)
        {
            $utcStartDatetime = $this->dateService->convertCarbonDateToUTC($startDate);
        }
        if (!$endDate->utc)
        {
            $utcEndDatetime = $this->dateService->convertCarbonDateToUTC($endDate);
        }

        return Blacklistdate::where('space_id', $space->id)->where('start_datetime', '<=', $utcEndDatetime)->where('end_datetime', '>=', $utcStartDatetime)->get();
    }

    /**
     * Returns the number of days that a space has been booked for, taking into account the days
     * that the space has been configures to be available, and blacklist dates.
     *
     * @param \App\Models\Space $space
     * @param \Carbon\Carbon $startDate
     * @param \Carbon\Carbon $endDate
     * @return int
     */
    public function getActualBookedDayCount(Space $space, Carbon $startDate, Carbon $endDate)
    {
        $bookedDays = 0;

        $interval = new \DateInterval('P1D');
        $daterange = new \DatePeriod($startDate, $interval, $endDate);
        $blacklistDates = $this->getBlackListDates($space, $startDate, $endDate);

        foreach($daterange as $date)
        {
            if($this->isDayAvailable($space, $date, $blacklistDates))
            {
                $bookedDays++;
            }
        }

        return $bookedDays;
    }
}