<?php
/**
 * Created by PhpStorm.
 * User: dan
 * Date: 15/11/2016
 * Time: 12:27 PM
 */

namespace App\Services;


use App\Services\Exceptions\CreditCardCreationFailedException;
use App\Services\Exceptions\CreditCardDeletionFailedException;
use App\Services\Exceptions\PaymentFailedException;
use Illuminate\Log\Writer;
use Omnipay\Omnipay;
use Symfony\Component\VarDumper\VarDumper;

/**
 * IPaymentService implementation specific to Stripe
 *
 * Class StripePaymentService
 * @package App\Services
 */
class StripePaymentService implements IPaymentService
{
    const TOKEN = 1;
    const CUSTOMER = 2;

    /**
     * @var Writer
     */
    private $logger = null;

    /**
     * @var null|\Omnipay\Stripe\Gateway
     */
    private $gateway = null;

    /**
     * StripePaymentService constructor.
     * @param Writer $logger
     */
    public function __construct(Writer $logger)
    {
        $this->logger = $logger;

        // Initialize to the Stripe gateway
        $this->gateway = Omnipay::create('Stripe');
    }

    /**
     * @inheritDoc
     */
    public function getApiKey()
    {
        return $this->gateway->getApiKey();
    }

    /**
     * @inheritDoc
     */
    public function setApiKey($apiKey = null)
    {
        if ($apiKey == null)
        {
            $this->gateway->setApiKey(env('PAYMENT_API_KEY'));
        }
        else
        {
            $this->gateway->setApiKey($apiKey);
        }
    }

    /**
     * @inheritDoc
     */
    public function init($apiKey = null)
    {
        $this->setApiKey($apiKey);
    }

    /**
     * @param $currency
     * @param $paymentAmount
     * @param $purchaseOptionsArr
     * @return mixed
     * @throws PaymentFailedException
     * @throws \Exception
     */
    protected function makePayment($currency, $paymentAmount, $purchaseOptionsArr)
    {
        try
        {
            $this->logger->info(sprintf("Attempting to make payment via STRIPE, Amount: %f, in currency: %s, with token/ref: %s",
                $paymentAmount, $currency, isset($purchaseOptionsArr['source']) ? $purchaseOptionsArr['source'] : $purchaseOptionsArr['customerReference']));
            $response = $this->gateway->purchase($purchaseOptionsArr)->send();

            // Check response
            $this->logger->info("Checking response for payment");
            if ($response->isSuccessful())
            {
                return $response->getData();
            }
            else
            {
                $paymentEx = new PaymentFailedException($response->getMessage());
                $paymentEx->setResponseData($response->getData());
                throw $paymentEx;
            }
        }
        catch (PaymentFailedException $pe)
        {
            // Just rethrow the custom ex
            throw $pe;
        }
        catch (\Exception $e)
        {
            $this->logger->error($e->getMessage(), ['exception' => $e]);
            throw $e;
        }

    }

    /**
     * @inheritDoc
     */
    public function makePaymentViaToken($currency, $paymentAmount, $paymentToken)
    {
        $purchaseOptionsArr = [
            'amount' => $paymentAmount,
            'currency' => $currency,
            'source' => $paymentToken
        ];
        return ($this->makePayment($currency, $paymentAmount, $purchaseOptionsArr));
    }

    /**
     * @inheritDoc
     */
    public function makePaymentViaCustomerRef($currency, $paymentAmount, $customerRef)
    {
        $purchaseOptionsArr = [
            'amount' => $paymentAmount,
            'currency' => $currency,
            'customerReference' => $customerRef
        ];
        return ($this->makePayment($currency, $paymentAmount, $purchaseOptionsArr));
    }

    public function createCreditCard($cardData)
    {
        try
        {
            $response = $this->gateway->createCard(['card' => $cardData])->send();
            if ($response->isSuccessful())
            {
                return $response->getData();
            }
            else
            {
                $creditCardException = new CreditCardCreationFailedException(($response->getMessage()));
                $creditCardException->setResponseData($response->getData());
                throw $creditCardException;
            }
        }
        catch (\Exception $e)
        {
            $this->logger->error($e->getMessage(), ['exception' => $e]);
            throw $e;
        }
    }

    public function deleteCreditCard($customerId, $cardId)
    {
        try
        {
            $response = $this->gateway->deleteCard(
                [
                    'cardReference' => $cardId,
                    'customerReference' => $customerId
                ])->send();
            if ($response->isSuccessful())
            {
                return $response->getData();
            }
            else
            {
                $creditCardException = new CreditCardDeletionFailedException($response->getMessage());
                $creditCardException->setResponseData($response->getData());
                throw $creditCardException;
            }
        }
        catch (\Exception $e)
        {
            $this->logger->error($e->getMessage(), ['exception' => $e]);
            throw $e;
        }
    }
}