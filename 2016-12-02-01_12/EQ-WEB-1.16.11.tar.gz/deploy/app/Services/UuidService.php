<?php namespace App\Services;

use App\Services\IUuidService;
use Webpatser\Uuid\Uuid;

class UuidService implements IUuidService {
    
    public function generateUUID()
    {
        return Uuid::generate();
    }
    
}