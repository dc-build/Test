<?php

return [

    /**
     * SYSTEM settings
     */

    //The User ID of the system account. Should be 1 as it's the first account created, but can be changed if needed
    'system_user_id' => ENV('SYSTEM_USER_ID', 1),

    'from_email' => ENV('FROM_EMAIL', 'test@example.com'),
];
