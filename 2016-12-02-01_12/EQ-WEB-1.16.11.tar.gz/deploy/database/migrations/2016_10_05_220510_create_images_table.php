<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateImagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('images', function (Blueprint $table) {
            $table->increments('id');
            $table->string('image_uuid')->nullable();
            $table->string('caption')->nullable();
            $table->bigInteger('file_size')->nullable();
            $table->string('file_ext')->nullable();
            $table->integer('created_by_id')->unsigned()->nullable();
            $table->integer('updated_by_id')->unsigned()->nullable();
            $table->timestamps();
        });
        
        Schema::table("images", function(Blueprint $table){
            $table->foreign("created_by_id")->references('id')->on('users');
            $table->foreign("updated_by_id")->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('ALTER TABLE images DROP FOREIGN KEY images_created_by_id_foreign');
        DB::statement('ALTER TABLE images DROP FOREIGN KEY images_updated_by_id_foreign');
        Schema::drop('images');
    }
}
