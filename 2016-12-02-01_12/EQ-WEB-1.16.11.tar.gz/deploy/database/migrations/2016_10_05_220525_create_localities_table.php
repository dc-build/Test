<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLocalitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('localities', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('region_id')->unsigned()->nullable();
            $table->string('name')->nullable();
            $table->string('timezone')->nullable();
            $table->timestamps();
        });
        
        Schema::table("localities", function(Blueprint $table){
            $table->foreign("region_id")->references('id')->on('regions');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('ALTER TABLE localities DROP FOREIGN KEY localities_region_id_foreign');
        Schema::drop('localities');
    }
}
