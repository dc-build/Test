<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBuildingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('buildings', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name')->nullable();
            $table->string('street_address_1')->nullable();
            $table->string('street_address_2')->nullable();
            $table->integer('locality_id')->unsigned()->nullable();
            $table->integer('region_id')->unsigned()->nullable();
            $table->integer('country_id')->unsigned()->nullable();
            $table->string('postcode')->nullable();
            $table->string('public_slug')->nullable();
            $table->string('private_slug')->nullable();
            $table->text('catering_information')->nullable();
            $table->integer('created_by_id')->unsigned()->nullable();
            $table->integer('updated_by_id')->unsigned()->nullable();
            $table->timestamps();
        });
        
        Schema::table("buildings", function(Blueprint $table){
            $table->foreign("locality_id")->references('id')->on('localities');
            $table->foreign("region_id")->references('id')->on('regions');
            $table->foreign("country_id")->references('id')->on('countries');
            $table->foreign("updated_by_id")->references('id')->on('users');
            $table->foreign("created_by_id")->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('ALTER TABLE buildings DROP FOREIGN KEY buildings_locality_id_foreign');
        DB::statement('ALTER TABLE buildings DROP FOREIGN KEY buildings_region_id_foreign');
        DB::statement('ALTER TABLE buildings DROP FOREIGN KEY buildings_country_id_foreign');
        DB::statement('ALTER TABLE buildings DROP FOREIGN KEY buildings_created_by_id_foreign');
        DB::statement('ALTER TABLE buildings DROP FOREIGN KEY buildings_updated_by_id_foreign');
        Schema::drop('buildings');
    }
}
