<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFloorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('floors', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('building_id')->unsigned()->nullable();
            $table->string('name')->nullable();
            $table->integer('order')->nullable();
            $table->integer('created_by_id')->unsigned()->nullable();
            $table->integer('updated_by_id')->unsigned()->nullable();
            $table->timestamps();
        });
        
        Schema::table("floors", function(Blueprint $table){
            $table->foreign("building_id")->references('id')->on('buildings');
            $table->foreign("created_by_id")->references('id')->on('users');
            $table->foreign("updated_by_id")->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('ALTER TABLE floors DROP FOREIGN KEY floors_building_id_foreign');
        DB::statement('ALTER TABLE floors DROP FOREIGN KEY floors_created_by_id_foreign');
        DB::statement('ALTER TABLE floors DROP FOREIGN KEY floors_updated_by_id_foreign');
        Schema::drop('floors');
    }
}
