<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        // Create the hosts table
        Schema::create('hosts', function (Blueprint $table)
        {
            $table->increments('id');

            $table->string('company_name');
            $table->string('company_abn')->nullable();
            $table->string('street_address_1')->nullable();
            $table->string('street_address_2')->nullable();
            $table->string('postcode')->nullable();
            $table->string('contact_name')->nullable();
            $table->string('contact_email')->nullable();
            $table->string('contact_phone')->nullable();
            $table->string('contact_position')->nullable();

            $table->integer('locality_id')->unsigned()->nullable();
            $table->integer('region_id')->unsigned()->nullable();
            $table->integer('country_id')->unsigned();

            $table->integer('creditcard_id')->unsigned()->nullable();

            $table->integer('created_by_id')->unsigned();
            $table->integer('updated_by_id')->unsigned();

            $table->timestamps();
        });

        // Setup host foreign keys
        Schema::table('hosts', function (Blueprint $table)
        {
            $table->foreign('created_by_id')->references('id')->on('users');
            $table->foreign('updated_by_id')->references('id')->on('users');
            $table->foreign('creditcard_id')->references('id')->on('creditcards');
            $table->foreign('region_id')->references('id')->on('regions');
            $table->foreign('locality_id')->references('id')->on('localities');
            $table->foreign('country_id')->references('id')->on('countries');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('hosts');
    }
}
