<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateCardsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('cards');

        /* Cards has now been changed to creditcards, with link tables to hosts
        // Setup cards pivot table
        Schema::create('cards', function(Blueprint $table)
        {
            $table->increments('id');
            $table->integer('host_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->string('name');
            $table->string('last_four', 4);
            $table->string('expiry_month', 2);
            $table->string('expiry_year', 4);
            $table->string('gateway_customer_id', 100);
            $table->timestamps();
        });

        // Setup cards foreign keys
        Schema::table('cards', function (Blueprint $table)
        {
            $table->foreign('host_id')->references('id')->on('hosts');
            $table->foreign('user_id')->references('id')->on('users');
        });
        */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cards');
    }
}
