<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateUserHostAccess extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::dropIfExists('user_host_access');
        /*
        // Create the user_host_access pivot table
        Schema::create('user_host_access', function (Blueprint $table)
        {
            $table->increments('id');
            $table->integer('host_id')->unsigned()->nullable();
            $table->integer('user_id')->unsigned()->nullable();
        });

        // Setup user_host_access foreign keys
        Schema::table('user_host_access', function (Blueprint $table)
        {
            $table->foreign('host_id')->references('id')->on('hosts');
            $table->foreign('user_id')->references('id')->on('users');
        });
        */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_host_access');
    }
}
