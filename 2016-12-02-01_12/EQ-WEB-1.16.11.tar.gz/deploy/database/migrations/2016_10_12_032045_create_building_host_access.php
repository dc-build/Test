<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateBuildingHostAccess extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('building_host_access');

        /*
        Schema::create('building_host_access', function (Blueprint $table)
        {
            $table->increments('id');
            $table->integer('building_id')->unsigned()->nullable();
            $table->integer('host_id')->unsigned()->nullable();
        });

        // TODO: Setup building_host_access foreign keys
        Schema::table('building_host_access', function (Blueprint $table)
        {
            $table->foreign('building_id')->references('id')->on('buildings')->onDelete('cascade');
            $table->foreign('host_id')->references('id')->on('hosts')->onDelete('cascade');
        });
        */

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('building_host_access');
    }
}
