<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateBuildingAccess extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::dropIfExists('building_access');
        /*
        // Setup building_access pivot table
        Schema::create('building_access', function(Blueprint $table)
        {
            $table->integer('user_host_access_id')->unsigned();
            $table->integer('building_host_access_id')->unsigned();
        });

        // Setup building_access foreign keys
        Schema::table('building_access', function (Blueprint $table)
        {
            $table->foreign('user_host_access_id')->references('id')->on('user_host_access');
            $table->foreign('building_host_access_id')->references('id')->on('building_host_access');
            $table->unique(['user_host_access_id', 'building_host_access_id'], 'user_building_host_access_unique');
        });
        */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('building_access');
    }
}
