<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class CreateHostImageTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('host_image', function (Blueprint $table) {
            $table->integer('host_id')->unsigned();
            $table->integer('image_id')->unsigned();
            $table->integer('imagetype_id')->unsigned();
        });

        Schema::table('host_image', function(Blueprint $table) {
            $table->foreign('host_id')->references('id')->on('hosts')->onDelete('cascade');
            $table->foreign('image_id')->references('id')->on('images')->onDelete('cascade');
            $table->foreign('imagetype_id')->references('id')->on('imagetypes');
            $table->unique(['host_id', 'image_id', 'imagetype_id'], 'host_image_imagetype_unique');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('host_image');
    }
}
