<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddBuildingImageForeignKeysTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('building_image', function (Blueprint $table) {
            $table->foreign("image_id")->references('id')->on('images')->onDelete('cascade');;
            $table->foreign("imagetype_id")->references('id')->on('imagetypes');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('building_image', function (Blueprint $table) {
            $table->dropForeign('building_image_image_id_foreign');
            $table->dropForeign('building_image_imagetype_id_foreign');
        });
    }
}
