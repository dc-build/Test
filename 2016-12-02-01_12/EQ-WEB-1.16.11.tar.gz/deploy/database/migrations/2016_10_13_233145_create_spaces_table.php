<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSpacesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('spaces', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('host_id');
            $table->unsignedInteger('building_id');
            $table->unsignedInteger('floor_id');
            $table->string('public_slug')->nullable();
            $table->string('private_slug')->nullable();
            $table->string('room_number')->nullable();
            $table->string('room_name')->nullable();
            $table->unsignedInteger('max_capacity')->nullable();
            $table->text('description')->nullable();
            $table->boolean('active')->default(0);
            $table->boolean('is_available_mon')->default(0);
            $table->boolean('is_available_tue')->default(0);
            $table->boolean('is_available_wed')->default(0);
            $table->boolean('is_available_thu')->default(0);
            $table->boolean('is_available_fri')->default(0);
            $table->boolean('is_available_sat')->default(0);
            $table->boolean('is_available_sun')->default(0);
            $table->boolean('is_available_afterhours')->default(0);
            $table->time('day_start_time')->nullable();
            $table->integer('day_duration')->unsigned()->default(0);
            $table->integer('month_duration')->unsigned()->default(0);
            $table->integer('after_hours_duration')->unsigned()->nullable();
            $table->integer('prep_time_before')->unsigned()->nullable();
            $table->integer('prep_time_after')->unsigned()->nullable();
            $table->integer('booking_window_min')->unsigned()->nullable();
            $table->integer('booking_window_max')->unsigned()->nullable();

            $table->boolean('pricing_hourly_enabled')->default(0);
            $table->boolean('pricing_halfdaily_enabled')->default(0);
            $table->boolean('pricing_daily_enabled')->default(0);
            $table->boolean('pricing_monthly_enabled')->default(0);

            $table->char('booking_type', 1);
            $table->boolean('payment_creditcard_allowed')->default(0);
            $table->boolean('payment_invoice_allowed')->default(0);
            $table->text('terms')->nullable();
            $table->integer('cancellation_hours')->unsigned();
            $table->decimal('cancellation_percent', 5, 4)->nullable();
            $table->char('currency', 3);

            $table->integer('created_by_id')->unsigned();
            $table->integer('updated_by_id')->unsigned();
            $table->timestamps();
            $table->softDeletes();
        });

        // Setup foreign keys
        Schema::table('spaces', function (Blueprint $table)
        {
            $table->foreign('created_by_id')->references('id')->on('users');
            $table->foreign('updated_by_id')->references('id')->on('users');

            $table->foreign('host_id')->references('id')->on('hosts');
            $table->foreign('building_id')->references('id')->on('buildings');
            $table->foreign('floor_id')->references('id')->on('floors');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('spaces');
    }
}
