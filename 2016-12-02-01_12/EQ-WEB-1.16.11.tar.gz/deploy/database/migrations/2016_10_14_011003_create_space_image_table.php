<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSpaceImageTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('space_image', function (Blueprint $table) {
            $table->integer('space_id')->unsigned();
            $table->integer('image_id')->unsigned();
            $table->integer('imagetype_id')->unsigned();
            $table->timestamps();
        });

        // Setup foreign keys
        Schema::table('space_image', function (Blueprint $table)
        {
            $table->foreign('space_id')->references('id')->on('spaces');
            $table->foreign('image_id')->references('id')->on('images');
            $table->foreign('imagetype_id')->references('id')->on('imagetypes');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('space_image');
    }
}
