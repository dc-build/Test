<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSpaceSpacetypeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('space_spacetype', function (Blueprint $table) {
            $table->integer('space_id')->unsigned();
            $table->integer('spacetype_id')->unsigned();
            $table->timestamps();
        });

        // Setup foreign keys
        Schema::table('space_spacetype', function (Blueprint $table)
        {
            $table->foreign('space_id')->references('id')->on('spaces')->onDelete('cascade');
            $table->foreign('spacetype_id')->references('id')->on('spacetypes')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('space_spacetype');
    }
}
