<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCapacitypricesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('capacityprices', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('space_id')->unsigned();
            $table->integer('attendees_min')->unsigned()->nullable();
            $table->integer('attendees_max')->unsigned()->nullable();
            $table->decimal('rate_hour', 10, 2)->nullable();
            $table->decimal('rate_halfday', 10, 2)->nullable();
            $table->decimal('rate_day', 10, 2)->nullable();
            $table->decimal('rate_month', 10, 2)->nullable();
            $table->decimal('rate_afterhours', 10, 2)->nullable();

            $table->integer('created_by_id')->unsigned();
            $table->integer('updated_by_id')->unsigned();
            $table->timestamps();
        });

        // Setup foreign keys
        Schema::table('capacityprices', function (Blueprint $table)
        {
            $table->foreign('created_by_id')->references('id')->on('users');
            $table->foreign('updated_by_id')->references('id')->on('users');
            $table->foreign('space_id')->references('id')->on('spaces');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('capacityprices');
    }
}
