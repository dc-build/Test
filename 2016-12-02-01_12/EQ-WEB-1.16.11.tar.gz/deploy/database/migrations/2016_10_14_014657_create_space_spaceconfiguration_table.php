<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSpaceSpaceconfigurationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('space_spaceconfiguration', function (Blueprint $table) {
            $table->integer('space_id')->unsigned();
            $table->integer('spaceconfiguration_id')->unsigned();
            $table->timestamps();
        });

        // Setup foreign keys
        Schema::table('space_spaceconfiguration', function (Blueprint $table)
        {
            $table->foreign('space_id')->references('id')->on('spaces')->onDelete('cascade');
            $table->foreign('spaceconfiguration_id')->references('id')->on('spaceconfigurations')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('space_spaceconfiguration');
    }
}
