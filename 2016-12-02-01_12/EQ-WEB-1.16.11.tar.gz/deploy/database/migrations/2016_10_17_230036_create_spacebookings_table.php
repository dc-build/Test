<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSpacebookingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('spacebookings', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('space_id')->unsigned();
            $table->integer('booked_by_id')->unsigned();
            $table->string('contact_name')->nullable();
            $table->string('company_name')->nullable();
            $table->string('company_address')->nullable();
            $table->string('company_city')->nullable();
            $table->string('company_postcode')->nullable();
            $table->string('company_state')->nullable();
            $table->string('company_country')->nullable();
            $table->string('event_title')->nullable();
            $table->text('event_description')->nullable();
            $table->integer('num_attendees');
            $table->dateTime('start_datetime');
            $table->dateTime('end_datetime')->nullable();
            $table->integer('configuration_id')->unsigned()->nullable();
            $table->decimal('total_price',10,2)->nullable();
            $table->decimal('rate_hour',10,2)->nullable();
            $table->decimal('rate_halfday',10,2)->nullable();
            $table->decimal('rate_day',10,2)->nullable();
            $table->decimal('rate_month',10,2)->nullable();
            $table->decimal('rate_afterhours',10,2)->nullable();
            $table->char('booking_type',1);
            $table->string('payment_type')->nullable();
            $table->boolean('payment_received');

            $table->integer('booked_total_hourly_hours')->unsigned()->nullable();
            $table->integer('booked_total_halfday_hours')->unsigned()->nullable();
            $table->integer('booked_total_day_hours')->unsigned()->nullable();
            $table->integer('booked_total_month_hours')->unsigned()->nullable();
            $table->integer('booked_total_afterhours_hours')->unsigned()->nullable();
            $table->integer('space_day_duration')->unsigned()->nullable();
            $table->integer('space_month_duration')->unsigned()->nullable();
            $table->boolean('space_pricing_hourly_enabled')->default(0);
            $table->boolean('space_pricing_halfdaily_enabled')->default(0);
            $table->boolean('space_pricing_daily_enabled')->default(0);
            $table->boolean('space_pricing_monthly_enabled')->default(0);
            $table->integer('prep_time_before')->unsigned()->nullable();
            $table->integer('prep_time_after')->unsigned()->nullable();
            $table->string('purchase_order')->nullable();

            $table->integer('created_by_id')->unsigned();
            $table->integer('updated_by_id')->unsigned();
            $table->timestamps();
        });
        
        // Setup foreign keys
        Schema::table('spacebookings', function (Blueprint $table)
        {
            $table->foreign('space_id')->references('id')->on('spaces');
            $table->foreign('booked_by_id')->references('id')->on('users');
            $table->foreign('configuration_id')->references('id')->on('spaceconfigurations');
            $table->foreign('created_by_id')->references('id')->on('users');
            $table->foreign('updated_by_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('spacebookings');
    }
}
