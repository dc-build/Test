<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('spacebooking_id')->unsigned();
            $table->string('name')->nullable();
            $table->string('last_four');
            $table->string('expiry_month');
            $table->string('expiry_year');
            $table->string('status');
            $table->decimal('total_amount');
            $table->decimal('fees')->nullable();
            $table->decimal('net_amount')->nullable();
            $table->string('transaction_id', 500);
            $table->timestamps();
        });
        
        // Setup foreign keys
        Schema::table('transactions', function (Blueprint $table)
        {
            $table->foreign('spacebooking_id')->references('id')->on('spacebookings');
        });

        DB::statement("ALTER TABLE transactions AUTO_INCREMENT = 10001;");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('transactions');
    }
}
