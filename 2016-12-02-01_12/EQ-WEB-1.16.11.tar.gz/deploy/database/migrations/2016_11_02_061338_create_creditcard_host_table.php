<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCreditcardHostTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('creditcard_host');

        /*
        Schema::create('creditcard_host', function (Blueprint $table) {
            $table->integer('creditcard_id')->unsigned();
            $table->integer('host_id')->unsigned();
            $table->timestamps();
        });

        // Setup foreign keys
        Schema::table('creditcard_host', function (Blueprint $table)
        {
            $table->foreign('creditcard_id')->references('id')->on('creditcards')->onDelete('cascade');
            $table->foreign('host_id')->references('id')->on('hosts')->onDelete('cascade');
        });
        */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('creditcard_host');
    }
}
