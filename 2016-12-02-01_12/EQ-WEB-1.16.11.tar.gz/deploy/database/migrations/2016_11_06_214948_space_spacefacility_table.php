<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SpaceSpacefacilityTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('space_spacefacility', function (Blueprint $table) {
            $table->integer('space_id')->unsigned();
            $table->integer('spacefacility_id')->unsigned();
            $table->timestamps();
        });

        // Setup foreign keys
        Schema::table('space_spacefacility', function (Blueprint $table)
        {
            $table->foreign('space_id')->references('id')->on('spaces')->onDelete('cascade');
            $table->foreign('spacefacility_id')->references('id')->on('spacefacilities');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('space_spacefacility');
    }
}
