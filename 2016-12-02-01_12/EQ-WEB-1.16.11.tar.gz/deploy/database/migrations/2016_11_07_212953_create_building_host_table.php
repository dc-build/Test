<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBuildingHostTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Create the host_user pivot table
        Schema::create('building_host', function (Blueprint $table)
        {
            $table->increments('id');
            $table->integer('building_id')->unsigned();
            $table->integer('host_id')->unsigned();
            $table->timestamps();
        });

        // Setup user_host_access foreign keys
        Schema::table('building_host', function (Blueprint $table)
        {
            $table->foreign('building_id')->references('id')->on('buildings')->onDelete('cascade');
            $table->foreign('host_id')->references('id')->on('hosts')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('building_host');
    }
}
