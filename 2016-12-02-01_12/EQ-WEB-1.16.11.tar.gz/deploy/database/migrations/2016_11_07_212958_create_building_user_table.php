<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBuildingUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Create the host_user pivot table
        Schema::create('building_user', function (Blueprint $table)
        {
            //these 2 columns link the building_user relationship to the bulding_host and host_user relationships
            //so that if either one of those relationships are removed, this record will be removed too.
            $table->integer('building_host_id')->unsigned();
            $table->integer('host_user_id')->unsigned();

            $table->integer('building_id')->unsigned();
            $table->integer('user_id')->unsigned();
            $table->integer('host_id')->unsigned();
            $table->timestamps();
        });

        // Setup user_host_access foreign keys
        Schema::table('building_user', function (Blueprint $table)
        {
            $table->foreign('building_host_id')->references('id')->on('building_host')->onDelete('cascade');
            $table->foreign('host_user_id')->references('id')->on('host_user')->onDelete('cascade');

            $table->foreign('building_id')->references('id')->on('buildings')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('host_id')->references('id')->on('hosts')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('building_user');
    }
}
