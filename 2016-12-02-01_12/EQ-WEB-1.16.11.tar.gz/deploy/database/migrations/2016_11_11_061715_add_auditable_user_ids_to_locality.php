<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddAuditableUserIdsToLocality extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('localities', function (Blueprint $table)
        {
            $table->integer('created_by_id')->unsigned()->nullable();
            $table->integer('updated_by_id')->unsigned()->nullable();
            $table->foreign("created_by_id")->references('id')->on('users');
            $table->foreign("updated_by_id")->references('id')->on('users');
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('localities', function (Blueprint $table)
        {
            // TODO: add constraint disable
//            $table->dropColumn('created_by_id');
//            $table->dropColumn('updated_by_id');
        });
    }
}
