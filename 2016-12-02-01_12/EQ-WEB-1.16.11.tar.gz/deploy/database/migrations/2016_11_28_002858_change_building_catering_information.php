<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ChangeBuildingCateringInformation extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::transaction(function() {
            Schema::table('buildings', function(Blueprint $table) {
                $table->renameColumn('catering_information', 'other_services');
            });
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasColumn('buildings', 'other_services'))
        {
            DB::transaction(function() {
                Schema::table('buildings', function(Blueprint $table) {
                    $table->renameColumn('other_services', 'catering_information');
                });
            });
        }
    }
}
