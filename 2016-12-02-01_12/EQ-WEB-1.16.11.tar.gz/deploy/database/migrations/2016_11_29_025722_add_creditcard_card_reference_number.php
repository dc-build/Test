<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddCreditcardCardReferenceNumber extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::transaction(function() {
            Schema::table('creditcards', function(Blueprint $table) {
                $table->string('gateway_card_id', 100)->default('');
            });
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasColumn('creditcards', 'gateway_card_id'))
        {
            DB::transaction(function() {
                Schema::table('creditcards', function(Blueprint $table) {
                    $table->dropColumn('gateway_card_id');
                });
            });
        }
    }
}
