<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Model::unguard();

        //Data that all environments need
        $this->call(RealSystemUsersRolesDataSeeder::class);
        $this->call(RealImageTypeDataSeeder::class);
        $this->call(RealCountryRegionLocalityDataSeeder::class);
        $this->call(RealTypesUsesFacilitiesDataSeeder::class);


        if(getenv('APP_ENV') == 'prod')
        {
            $this->call(DialogueSydneyHostBuildingSpaceDataSeeder::class);
        }
        else if(getenv('APP_ENV') == 'uat')
        {
            $this->call(DialogueSydneyHostBuildingSpaceDataSeeder::class);
        }
        else if(getenv('APP_ENV') == 'test')
        {
            $this->call(DialogueSydneyHostBuildingSpaceDataSeeder::class);
        }
        else //Local
        {

            $this->call(DevelopmentUsersTableSeeder::class);
            $this->call(DialogueSydneyHostBuildingSpaceDataSeeder::class);
            //$this->call(SampleHostBuildingSpaceDataSeeder::class);
        }




        Model::reguard();
    }
}
