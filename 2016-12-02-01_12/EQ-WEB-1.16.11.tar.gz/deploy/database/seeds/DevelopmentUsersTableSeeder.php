<?php

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\DB;

class DevelopmentUsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /******************************************************************************
         *  ADD USERS
         ******************************************************************************/

        $role = Role::where('name', 'admin')->first();

        $user = ["isActive" => true, "role_id" => $role->id, "first_name" => "Sally", "last_name" => "Jones", "email" => "test@digitalcarpenter.com.au", "mobile_number" => "0413076388"];
        $user = User::create($user);

    }
}
