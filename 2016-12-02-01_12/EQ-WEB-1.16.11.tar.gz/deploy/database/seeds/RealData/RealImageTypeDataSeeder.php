<?php

use Illuminate\Database\Seeder;
use App\Models\Imagetype;

class RealImageTypeDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /******************************************************************************
         *  IMAGE TYPES
         ******************************************************************************/

        $imagetypes = ["name" => "logo"];
        $imagetypes = Imagetype::create($imagetypes);

        $imagetypes = ["name" => "header"];
        $imagetypes = Imagetype::create($imagetypes);

        $imagetypes = ["name" => "icon"];
        $imagetypes = Imagetype::create($imagetypes);

        $imagetypes = ["name" => "gallery"];
        $imagetypes = Imagetype::create($imagetypes);

        $imagetypes = ["name" => "thumbnail"];
        $imagetypes = Imagetype::create($imagetypes);
        
        $imagetypes = ["name" => "profile"];
        $imagetypes = Imagetype::create($imagetypes);

    }
}
