<?php

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\User;

class RealSystemUsersRolesDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = ["isActive" => true, "first_name" => "system", "last_name" => "admin", "email" => "system@digitalcarpenter.com.au", "mobile_number" => "0402352491"];
        $user = User::create($user);

        $role = ["name" => "Admin"];
        $role = Role::create($role);

        $role = ["name" => "Host"];
        $role = Role::create($role);
        
        $role = ["name" => "User"];
        $role = Role::create($role);

    }
}
