<?php

use Illuminate\Database\Seeder;
use App\Models\Spacetype;
use App\Models\Spaceuse;
use App\Models\Spacefacility;
use App\Models\Spaceconfiguration;

class RealTypesUsesFacilitiesDataSeeder extends Seeder
{
    /**
     * Creates the initial Spaceuse, Spacetype and Spacefacility records
     *
     * @return void
     */
    public function run()
    {
        /******************************************************************************
         *  SPACE TYPES
         ******************************************************************************/

        $spaceTypes = [ 'Boardroom',
                        'Classroom',
                        'Theatrette',
                        'Meeting room',
                        'Function space',
                        'Immersive studio',
                        'Auditorium',
                        'Project space',
                        'Desk/Workstation',
                        'Conference',
                        'Terrace/Balcony',
                        'Workshop',
                        'Lecture theatre',
                        'Warroom'];

        foreach ($spaceTypes as $spaceType)
        {
            Spacetype::create(['name' => $spaceType]);
        }


        /******************************************************************************
         *  SPACE USES
         ******************************************************************************/

        $spaceUses = [
                        'Cocktail party',
                        'Presentations',
                        'Video screening',
                        'Product launches',
                        'Seminars',
                        'Product Sampling/Market Research',
                        ];

        foreach ($spaceUses as $spaceUse)
        {
            Spaceuse::create(['name' => $spaceUse]);
        }


        /******************************************************************************
         *  SPACE FACILITIES
         ******************************************************************************/
        $spaceFacilities = [
                            ['shared' => false, 'name' => 'High speed wifi', 'icon_style' => 'fa fa-wifi'],
                            ['shared' => false, 'name' => 'Hearing impairment loop', 'icon_style' => 'fa fa-deaf'],
                            ['shared' => false, 'name' => 'Teleconferencing', 'icon_style' => 'fa fa-phone'],
                            ['shared' => false, 'name' => 'Video conferencing', 'icon_style' => 'fa fa-video-camera'],
                            ['shared' => false, 'name' => 'Accessibility', 'icon_style' => 'fa fa-wheelchair'],
                            ['shared' => false, 'name' => 'Whiteboard', 'icon_style' => 'fa fa-square'],
                            ['shared' => false, 'name' => 'Projector', 'icon_style' => 'fa fa-eye'],
                            ['shared' => false, 'name' => 'Microphone', 'icon_style' => 'fa fa-microphone'],
                            ['shared' => false, 'name' => '"Clickshare"', 'icon_style' => 'fa fa-share-square-o'],
                            ['shared' => false, 'name' => 'Television', 'icon_style' => 'fa fa-tv'],
                            ['shared' => false, 'name' => 'Phone chargers', 'icon_style' => 'fa fa-plug'],
                            ['shared' => true, 'name' => 'Business lounge', 'icon_style' => 'fa fa-briefcase'],
                            ['shared' => true, 'name' => 'Printer', 'icon_style' => 'fa fa-print'],
                            ['shared' => true, 'name' => 'Kitchenette', 'icon_style' => 'fa fa-cutlery'],
                            ['shared' => true, 'name' => 'Tea/coffee', 'icon_style' => 'fa fa-coffee'],
                            ['shared' => true, 'name' => 'Biscuits', 'icon_style' => 'fa fa-th-large'],
                            ['shared' => true, 'name' => 'Bathroom(s)', 'icon_style' => 'fa fa-venus-mars'],
                            ['shared' => true, 'name' => 'Break-out area', 'icon_style' => 'fa fa-codepen'],
                            ['shared' => true, 'name' => 'Flipcharts', 'icon_style' => 'fa fa-calendar-o'],

                ];

        foreach ($spaceFacilities as $spaceFacility)
        {
            Spacefacility::create($spaceFacility);
        }


        /******************************************************************************
         *  SPACE CONFIGURATIONS
         ******************************************************************************/

        $spaceConfigurations = [
            'Theatre',
            'Cafe',
            'Cabaret',
            'Cocktail',
            'Boardroom',
            'Classroom',
            'U-shaped',
        ];

        foreach ($spaceConfigurations as $spaceConfiguration)
        {
            Spaceconfiguration::create(['name' => $spaceConfiguration]);
        }

    }
}
