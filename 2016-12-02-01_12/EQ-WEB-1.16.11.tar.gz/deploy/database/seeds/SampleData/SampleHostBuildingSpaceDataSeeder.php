<?php

use App\Models\Building;
use App\Models\Capacityprice;
use App\Models\Floor;
use App\Models\Host;
use App\Models\Image;
use App\Models\Role;
use App\Models\User;
use App\Models\Space;
use App\Models\Locality;
use App\Models\Spaceconfiguration;
use App\Models\Spacefacility;
use App\Models\Spacetype;
use App\Models\Spaceuse;
use Illuminate\Database\Seeder;

class SampleHostBuildingSpaceDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $sydney = Locality::where('name', 'sydney')->with('region.country')->first();
        $uuidService = new \App\Services\UuidService();
        $imageService = new \App\Services\ImageService($uuidService);

        /******************************************************************************
         *  ADD THE BUILDING & FLOOR
         ******************************************************************************/
        $buildingArray = [
            'name' => 'Test Building',
            'street_address_1' => '44 Bork Street',
            'street_address_2' => '',
            'locality_id' => $sydney->id,
            'region_id' => $sydney->region->id,
            'country_id' => $sydney->region->country->id,
            'postcode' => '2000',
            'private_slug' => $uuidService->generateUUID(),
            'other_services' => '',
        ];

        $building = Building::create($buildingArray);

        $floor = new Floor(['name' => 'Level 2', 'order' => 2,]);
        $building->floors()->save($floor);

        /******************************************************************************
         *  CREATE THE BUILDING HEADER IMAGE
         ******************************************************************************/
        $image_id = $imageService->saveImage([
                                                 'file_size' => 219313,
                                                 'file_ext' => 'jpg'
                                             ], '2c3450e0-a21d-11e6-8d5e-27b18d456977', new Image);
        $building->images()
                 ->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('header')]);


        /******************************************************************************
         *  CREATE ANOTHER BUILDING FOR ISPT
         ******************************************************************************/
        $buildingArray3 = [
            'name' => '3rd Building',
            'street_address_1' => '12 George Street',
            'street_address_2' => '',
            'locality_id' => $sydney->id,
            'region_id' => $sydney->region->id,
            'country_id' => $sydney->region->country->id,
            'postcode' => '2000',
            'private_slug' => $uuidService->generateUUID(),
            'other_services' => '',
        ];

        $building3 = Building::create($buildingArray3);

        $floor3 = new Floor(['name' => 'Level 4', 'order' => 1,]);
        $building3->floors()->save($floor3);

        /******************************************************************************
         *  ADD THE HOST
         ******************************************************************************/
        $hostArray = [
            'company_name' => 'ABCD',
            'company_abn' => '',
            'street_address_1' => '44 Bork Street',
            'street_address_2' => '',
            'locality_id' => $sydney->id,
            'region_id' => $sydney->region->id,
            'country_id' => $sydney->region->country->id,
            'postcode' => '2000',
            'contact_name' => 'Homer Simposn',
            'contact_email' => 'chris+homer@digitalcarpenter.com.au',
            'contact_phone' => '0402 352 491',
            'contact_position' => 'ABCD Business Support'
        ];

        $host = Host::create($hostArray);

        //$uuidService->generateUUID()

        $image_id = $imageService->saveImage(['file_size' => 3078, 'file_ext' => 'jpg'], 'e0150280-a251-11e6-a2f6-534a532b8b77', new Image);
        $host->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('logo')]);

        //Add this building to the host
        $host->buildings()->attach($building->id);
        $host->buildings()->attach($building3->id);

        /******************************************************************************
         *  ADD A HOST ADMIN USER AND RELATE TO THE HOST AND BUILDINGS
         ******************************************************************************/
        $role = Role::where('name', 'host')->first();

        $user = ["isActive" => true, "role_id" => $role->id, "first_name" => "James", "last_name" => "White", "email" => "webtest+host1@digitalcarpenter.com.au", "mobile_number" => "0402352491"];
        $user = User::create($user);

        $user2 = ["isActive" => true, "role_id" => $role->id, "first_name" => "Jane", "last_name" => "Black", "email" => "webtest+host2@digitalcarpenter.com.au", "mobile_number" => "0402352491"];
        $user2 = User::create($user2);

        $user3 = ["isActive" => true, "role_id" => $role->id, "first_name" => "Jemima", "last_name" => "Mauve", "email" => "webtest+host3@digitalcarpenter.com.au", "mobile_number" => "0402352491"];
        $user3 = User::create($user3);

        //add this user to the host
        $host->hostadmins()->attach($user->id);
        $host->hostadmins()->attach($user2->id);
        $host->hostadmins()->attach($user3->id);

        $attachedUser = $host->hostadmins()->where('users.id', $user->id)->first();
        $attachedBuilding = $host->buildings()->where('buildings.id', $building->id)->first();

        //add the user to the building
        $building->hostadmins()->attach($user->id, ['host_user_id' => $attachedUser->pivot->id, 'building_host_id' => $attachedBuilding->pivot->id, 'host_id' => $host->id]);


        /******************************************************************************
         *  CREATE ANOTHER BUILDING & HOST
         ******************************************************************************/
        $buildingArray2 = [
            'name' => 'ABCD',
            'street_address_1' => '241 George Street',
            'street_address_2' => '',
            'locality_id' => $sydney->id,
            'region_id' => $sydney->region->id,
            'country_id' => $sydney->region->country->id,
            'postcode' => '2000',
            'private_slug' => $uuidService->generateUUID(),
            'other_services' => '',
        ];

        $building2 = Building::create($buildingArray2);

        $floor2 = new Floor(['name' => 'Level 1', 'order' => 1,]);
        $building2->floors()->save($floor2);

        $hostArray2 = [
            'company_name' => 'ACompany Pty Ltd',
            'company_abn' => '',
            'street_address_1' => '242 Kent Street',
            'street_address_2' => '',
            'locality_id' => $sydney->id,
            'region_id' => $sydney->region->id,
            'country_id' => $sydney->region->country->id,
            'postcode' => '2000',
            'contact_name' => 'James White',
            'contact_email' => 'chris+ispt@digitalcarpenter.com.au',
            'contact_phone' => '02 8239 8550',
            'contact_position' => 'ISPT Business Support'
        ];

        $host2 = Host::create($hostArray2);

        //Add this building to the host
        $host2->buildings()->attach($building2->id);

        //Add someone as the admin to another building through a different host
        $host2->hostadmins()->attach($user->id);

        $attachedUser2 = $host2->hostadmins()->where('users.id', $user->id)->first();
        $attachedBuilding2 = $host2->buildings()->where('buildings.id', $building2->id)->first();
        $building2->hostadmins()->attach($user->id, ['host_user_id' => $attachedUser2->pivot->id, 'building_host_id' => $attachedBuilding2->pivot->id, 'host_id' => $host2->id]);

        /******************************************************************************
         *  ADD THE SPACE
         ******************************************************************************/
        $terms = "<ul>
<li>All charges are based on current rates and are subject to change. Room rates are reviewed annually.</li>
<li>Catering is available and the order must be finalised 48 hours prior to the catering delivery.</li>
<li>Catering is served outside the rooms, participants are encouraged to leave foodstuffs outside the room, so they can be taken by cleaners promptly after breaks.</li>
<li>Dialogue internet feed is firewalled and will only allow access to HTTP / HTTPS traffic. If you require any additional ports to be opened, please provide specific details on the booking form (72 hours notice).</li>
<li>The booking contact or other representative must arrive 1 hour - 30 minutes prior to booking if AV equipment is required. The booking contact / facilitator / trainer / leader must check in with reception for a venue briefing prior to commencement of the function.</li>
<li>Any large amount of rubbish generated from the meeting must be cleared at the client’s expense and time.</li>
<li>Whiteboards must be cleaned after use and all equipment left as found.</li>
<li>Room setup can be organised at your request as per details provided, alternatively, setup of rooms can be organised by the client. All chairs and tables are to be reinstated to the original formation at the conclusion of your meeting.</li>
<li>All bookings are taken in good faith, however, management accepts no responsibility should the double booking of a room occur.</li>
<li>Management does not accept responsibility for any loss or damage to personnel or property suffered by the client companies or individuals, their employees, guests or invitees.</li>
<li>Any damage or breakage to any equipment in the conference rooms will be charged to the client.</li>
<li>Tea and coffee facilities will be provided in the breakout kitchen and are included in the hire rates.</li>
<li>Limited administration services including photocopying, printing, faxing, binding and scanning are available from reception with associated costs. These costs will be added to the room hire fee. For administration charge rates, please check with reception.</li>
<li>All meeting room bookings include complimentary water, mints and self serve tea/coffee.</li>
</ul>";
        $spaceArray = [
            'host_id' => $host->id,
            'building_id' => $building->id,
            'floor_id' => $floor->id,
            'private_slug' => $uuidService->generateUUID(),
            'room_number' => '',
            'room_name' => 'Martin Place',
            'max_capacity' => 16,
            'description' => '',
            'active' => true,
            'is_available_mon' => true,
            'is_available_tue' => true,
            'is_available_wed' => true,
            'is_available_thu' => true,
            'is_available_fri' => true,
            'is_available_sat' => false,
            'is_available_sun' => false,
            'is_available_afterhours' => false,
            'day_start_time' => '8:30:00',
            'day_duration' => 510,
            'prep_time_before' => 30,
            'prep_time_after' => 0,
            'booking_window_min' => 10080,
            'pricing_hourly_enabled' => false,
            'pricing_halfdaily_enabled' => true,
            'pricing_daily_enabled' => true,
            'pricing_monthly_enabled' => false,
            'booking_type' => 'I',
            'payment_creditcard_allowed' => true,
            'payment_invoice_allowed' => false,
            'terms' => $terms,
            'currency' => 'AUD',
        ];
        $space = Space::create($spaceArray);

        //Capacity price
        $prices = new Capacityprice(['attendees_min' => 1, 'attendees_max' => 16, 'rate_halfday' => 107.06, 'rate_day' => 107.06]);
        $space->capacityprices()->save($prices);

        //Add the images
        $image_id = $imageService->saveImage(['file_size' => 195450, 'file_ext' => 'jpg'], 'd3e42b40-a45d-11e6-aeb9-19a1b227cab8', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('gallery')]);

        $image_id = $imageService->saveImage(['file_size' => 190843, 'file_ext' => 'jpg'], 'd3e41690-a45d-11e6-a48c-3f601d363333', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('gallery')]);

        $image_id = $imageService->saveImage(['file_size' => 210740, 'file_ext' => 'jpg'], 'd3e42460-a45d-11e6-b6f8-93ac45a5bee2', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('gallery')]);

        $image_id = $imageService->saveImage(['file_size' => 22051, 'file_ext' => 'jpg'], 'd3e431b0-a45d-11e6-ad72-e3e00c225bae', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('thumbnail')]);

        //Add the other space settings
        $spaceTypes = Spacetype::whereIn('name' ,['Boardroom','Meeting room','Workshop'])->lists('id')->toArray();
        $space->spacetypes()->attach($spaceTypes);

        $spaceUses = Spaceuse::whereIn('name' ,['Presentations','Presentations'])->lists('id')->toArray();
        $space->spaceuses()->attach($spaceUses);

        $spaceFacilities = Spacefacility::whereIn('name' ,['High speed wifi','Tea/coffee', 'Bathroom(s)', 'Kitchenette', 'Phone chargers', 'Biscuits'])->lists('id')->toArray();
        $space->spacefacilities()->attach($spaceFacilities);

        $spaceConfigurations = Spaceconfiguration::whereIn('name' ,['Boardroom'])->lists('id')->toArray();
        $space->spaceconfigurations()->attach($spaceConfigurations);


        /******************************************************************************
         *  ADD THE SPACE
         ******************************************************************************/
        $terms ="<ul>
<li>All charges are based on current rates and are subject to change. Room rates are reviewed annually.</li>
<li>Catering is available and the order must be finalised 48 hours prior to the catering delivery.</li>
<li>Catering is served outside the rooms, participants are encouraged to leave foodstuffs outside the room, so they can be taken by cleaners promptly after breaks.</li>
<li>Dialogue internet feed is firewalled and will only allow access to HTTP / HTTPS traffic. If you require any additional ports to be opened, please provide specific details on the booking form (72 hours notice).</li>
<li>The booking contact or other representative must arrive 1 hour - 30 minutes prior to booking if AV equipment is required. The booking contact / facilitator / trainer / leader must check in with reception for a venue briefing prior to commencement of the function.</li>
<li>Any large amount of rubbish generated from the meeting must be cleared at the client’s expense and time.</li>
<li>Whiteboards must be cleaned after use and all equipment left as found.</li>
<li>Room setup can be organised at your request as per details provided, alternatively, setup of rooms can be organised by the client. All chairs and tables are to be reinstated to the original formation at the conclusion of your meeting.</li>
<li>All bookings are taken in good faith, however, management accepts no responsibility should the double booking of a room occur.</li>
<li>Management does not accept responsibility for any loss or damage to personnel or property suffered by the client companies or individuals, their employees, guests or invitees.</li>
<li>Any damage or breakage to any equipment in the conference rooms will be charged to the client.</li>
<li>Tea and coffee facilities will be provided in the breakout kitchen and are included in the hire rates.</li>
<li>Limited administration services including photocopying, printing, faxing, binding and scanning are available from reception with associated costs. These costs will be added to the room hire fee. For administration charge rates, please check with reception.</li>
<li>All meeting room bookings include complimentary water, mints and self serve tea/coffee.</li>
</ul>";
        $spaceArray = [
            'host_id' => $host->id,
            'building_id' => $building->id,
            'floor_id' => $floor->id,
            'private_slug' => $uuidService->generateUUID(),
            'room_number' => '',
            'room_name' => 'Town Hall',
            'max_capacity' => 20,
            'description' => '',
            'active' => true,
            'is_available_mon' => true,
            'is_available_tue' => true,
            'is_available_wed' => true,
            'is_available_thu' => true,
            'is_available_fri' => true,
            'is_available_sat' => false,
            'is_available_sun' => false,
            'is_available_afterhours' => false,
            'day_start_time' => '8:30:00',
            'day_duration' => 510,
            'prep_time_before' => 30,
            'prep_time_after' => 0,
            'booking_window_min' => 10080,
            'pricing_hourly_enabled' => true,
            'pricing_halfdaily_enabled' => true,
            'pricing_daily_enabled' => true,
            'pricing_monthly_enabled' => false,
            'booking_type' => 'I',
            'payment_creditcard_allowed' => true,
            'payment_invoice_allowed' => false,
            'terms' => $terms,
            'currency' => 'AUD',
        ];
        $space = Space::create($spaceArray);

        //Capacity price
        $prices = new Capacityprice(['attendees_min' => 1, 'attendees_max' => 20, 'rate_halfday' => 107.06, 'rate_day' => 107.06]);
        $space->capacityprices()->save($prices);

        //Add the images
        $image_id = $imageService->saveImage(['file_size' => 195450, 'file_ext' => 'jpg'], 'd3e43e70-a45d-11e6-af41-7748fb20b270', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('gallery')]);

        $image_id = $imageService->saveImage(['file_size' => 190843, 'file_ext' => 'jpg'], 'd3e43810-a45d-11e6-8a7e-47029f8418a6', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('gallery')]);

        $image_id = $imageService->saveImage(['file_size' => 22051, 'file_ext' => 'jpg'], 'd3e44480-a45d-11e6-b456-c1c8dbbdec3b', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('thumbnail')]);

        //Add the other space settings
        $spaceTypes = Spacetype::whereIn('name' ,['Boardroom','Meeting room'])->lists('id')->toArray();
        $space->spacetypes()->attach($spaceTypes);

        $spaceUses = Spaceuse::whereIn('name' ,['Presentations','Presentations'])->lists('id')->toArray();
        $space->spaceuses()->attach($spaceUses);

        $spaceFacilities = Spacefacility::whereIn('name' ,['High speed wifi', 'Video conferencing', 'Tea/coffee', 'Bathroom(s)', 'Kitchenette', 'Phone chargers', 'Biscuits'])->lists('id')->toArray();
        $space->spacefacilities()->attach($spaceFacilities);

        $spaceConfigurations = Spaceconfiguration::whereIn('name' ,['Boardroom'])->lists('id')->toArray();
        $space->spaceconfigurations()->attach($spaceConfigurations);





        /******************************************************************************
         *  ADD THE SPACE FOR THE SECOND TEST HOST
         ******************************************************************************/
        $terms ="<ul>
<li>All charges are based on current rates and are subject to change. Room rates are reviewed annually.</li>
<li>Catering is available and the order must be finalised 48 hours prior to the catering delivery.</li>
<li>Catering is served outside the rooms, participants are encouraged to leave foodstuffs outside the room, so they can be taken by cleaners promptly after breaks.</li>
<li>Dialogue internet feed is firewalled and will only allow access to HTTP / HTTPS traffic. If you require any additional ports to be opened, please provide specific details on the booking form (72 hours notice).</li>
<li>The booking contact or other representative must arrive 1 hour - 30 minutes prior to booking if AV equipment is required. The booking contact / facilitator / trainer / leader must check in with reception for a venue briefing prior to commencement of the function.</li>
<li>Any large amount of rubbish generated from the meeting must be cleared at the client’s expense and time.</li>
<li>Whiteboards must be cleaned after use and all equipment left as found.</li>
<li>Room setup can be organised at your request as per details provided, alternatively, setup of rooms can be organised by the client. All chairs and tables are to be reinstated to the original formation at the conclusion of your meeting.</li>
<li>All bookings are taken in good faith, however, management accepts no responsibility should the double booking of a room occur.</li>
<li>Management does not accept responsibility for any loss or damage to personnel or property suffered by the client companies or individuals, their employees, guests or invitees.</li>
<li>Any damage or breakage to any equipment in the conference rooms will be charged to the client.</li>
<li>Tea and coffee facilities will be provided in the breakout kitchen and are included in the hire rates.</li>
<li>Limited administration services including photocopying, printing, faxing, binding and scanning are available from reception with associated costs. These costs will be added to the room hire fee. For administration charge rates, please check with reception.</li>
<li>All meeting room bookings include complimentary water, mints and self serve tea/coffee.</li>
</ul>";
        $spaceArray = [
            'host_id' => $host2->id,
            'building_id' => $building2->id,
            'floor_id' => $floor2->id,
            'private_slug' => $uuidService->generateUUID(),
            'room_number' => '',
            'room_name' => 'Test Space',
            'max_capacity' => 50,
            'description' => 'This is a test space where you can hold your test meetings',
            'active' => true,
            'is_available_mon' => true,
            'is_available_tue' => true,
            'is_available_wed' => true,
            'is_available_thu' => true,
            'is_available_fri' => true,
            'is_available_sat' => false,
            'is_available_sun' => false,
            'is_available_afterhours' => false,
            'day_start_time' => '8:30:00',
            'day_duration' => 510,
            'prep_time_before' => 30,
            'prep_time_after' => 0,
            'booking_window_min' => 10080,
            'pricing_hourly_enabled' => true,
            'pricing_halfdaily_enabled' => true,
            'pricing_daily_enabled' => true,
            'pricing_monthly_enabled' => false,
            'booking_type' => 'I',
            'payment_creditcard_allowed' => true,
            'payment_invoice_allowed' => false,
            'terms' => $terms,
            'currency' => 'AUD',
        ];
        $space = Space::create($spaceArray);

        //Capacity price
        $prices = new Capacityprice(['attendees_min' => 1, 'attendees_max' => 25, 'rate_hour' => 100.00, 'rate_halfday' => 107.06, 'rate_day' => 107.06]);
        $prices2 = new Capacityprice(['attendees_min' => 26, 'attendees_max' => 50, 'rate_hour' => 110.00, 'rate_halfday' => 117.76, 'rate_day' => 117.76]);
        $space->capacityprices()->save($prices);
        $space->capacityprices()->save($prices2);

        //Add the images
        $image_id = $imageService->saveImage(['file_size' => 195450, 'file_ext' => 'jpg'], 'd3e43e70-a45d-11e6-af41-7748fb20b270', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('gallery')]);

        $image_id = $imageService->saveImage(['file_size' => 190843, 'file_ext' => 'jpg'], 'd3e43810-a45d-11e6-8a7e-47029f8418a6', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('gallery')]);

        $image_id = $imageService->saveImage(['file_size' => 22051, 'file_ext' => 'jpg'], 'd3e44480-a45d-11e6-b456-c1c8dbbdec3b', new Image);
        $space->images()->attach($image_id, ['imagetype_id' => $imageService->getImageTypeId('thumbnail')]);

        //Add the other space settings
        $spaceTypes = Spacetype::whereIn('name' ,['Boardroom','Meeting room'])->lists('id')->toArray();
        $space->spacetypes()->attach($spaceTypes);

        $spaceUses = Spaceuse::whereIn('name' ,['Presentations','Presentations'])->lists('id')->toArray();
        $space->spaceuses()->attach($spaceUses);

        $spaceFacilities = Spacefacility::whereIn('name' ,['High speed wifi', 'Video conferencing', 'Tea/coffee', 'Bathroom(s)', 'Kitchenette', 'Phone chargers', 'Biscuits'])->lists('id')->toArray();
        $space->spacefacilities()->attach($spaceFacilities);

        $spaceConfigurations = Spaceconfiguration::whereIn('name' ,['Boardroom'])->lists('id')->toArray();
        $space->spaceconfigurations()->attach($spaceConfigurations);
    }
}
