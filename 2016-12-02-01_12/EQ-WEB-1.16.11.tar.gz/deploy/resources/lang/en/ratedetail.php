<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Rate details language lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the RateEndine service to build
    | the totla price breakdown.
    |
    */

    'hour'                  => 'Hour|Hours',
    'after_hours'           => 'After Hours',
    'total'                 => 'Total',

];
