<div class="booking-summary m-bot-50">
    <h2>Booking Summary</h2>
    <div class="payment-summary">
        <div class="alert alert-danger alert-light collapse"></div>
        <p><strong>{{ $space->room_name }}</strong><br />{{ $space->building->street_address_1 }}</p>
        <div class="row">
            @if ($bookingDetails['widgetSource']=='hourly')
                <div class="col-md-6">
                    {!! Form::label('date', 'Date') !!}
                    {!! Form::text('date', $bookingDetails['date'], ['class' => 'form-control', 'readonly']) !!}
                </div>
                <div class="col-md-6">
                    {!! Form::label('num_attendees', 'Attendees') !!}
                    {!! Form::number('num_attendees', $bookingDetails['num_attendees'], ['class' => 'form-control', 'id' => 'booking-summary-attendees', 'readonly']) !!}
                </div>
            @elseif ($bookingDetails['widgetSource']=='daily')
                <div class="col-md-6">
                    {!! Form::label('date_from', 'Date From') !!}
                    {!! Form::text('date_from', $bookingDetails['date_from'], ['class' => 'form-control', 'readonly']) !!}
                </div>
                <div class="col-md-6">
                    {!! Form::label('date_to', 'Date To') !!}
                    {!! Form::text('date_to', $bookingDetails['date_to'], ['class' => 'form-control', 'readonly']) !!}
                </div>
            @endif
        </div>
        <div class="row m-top-20">
            @if ($bookingDetails['widgetSource']=='hourly')
                <div class="col-md-6">
                    {!! Form::label('time_from', 'Time from') !!}
                    {!! Form::text('time_from', $bookingDetails['time_from'], ['class' => 'form-control', 'readonly']) !!}
                </div>
                <div class="col-md-6">
                    {!! Form::label('time_to', 'Time To') !!}
                    {!! Form::text('time_to', $bookingDetails['time_to'], ['class' => 'form-control', 'readonly']) !!}
                </div>
            @elseif ($bookingDetails['widgetSource']=='daily')
                <div class="col-md-12">
                    {!! Form::label('num_attendees', 'Attendees') !!}
                    {!! Form::number('num_attendees', $bookingDetails['num_attendees'], ['class' => 'form-control', 'id' => 'booking-summary-attendees', 'readonly']) !!}
                </div>
            @endif
        </div>
        <div class="row m-top-20">
            <div class="col-md-12">
                @if ($bookingDetails['widgetSource']=='hourly')
                    <p id="rateHour"></p>
                    <p id="rateAfterHours"></p>
                @elseif ($bookingDetails['widgetSource']=='daily')
                    <p id="rateDay"></p>
                    <p id="rateMonth"></p>
                @endif
                <hr />
                <p class="text-large">Total <span class="pull-right" id="payment_total"></span></p>
                <p><small><a href="#" type="button" class="" data-toggle="modal" data-target="#termsModal">Cancellation policy details</a>.</small></p>
            </div>
        </div>
    </div>
</div>