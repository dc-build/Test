

<div class="page-hero-wrapper space-detail hero-lightbox">
    <div class="page-hero-inner">
        <div class="lightbox-section">
            <div class="lightbox-img">
                @forelse ($space->galleryImages as $galleryImage)
                    <a href="{{ asset('images/uploads/'.$galleryImage->image_uuid.'.'.$galleryImage->file_ext) }}" data-lightbox="gallery" data-caption=""><img class="" src="{{ asset('images/uploads/'.$galleryImage->image_uuid.'.'.$galleryImage->file_ext) }}" alt=""></a>
                @empty
                    <img class="" src="{{ $space->building->headerImage[0]->filePath('header') }}">
                @endforelse
            </div>
            {{--
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner overlay" role="listbox">

                    @forelse ($space->galleryImages as $galleryImage)
                        <div class="item">
                            <img class="first-slide img-responsive" src="{{ asset('images/uploads/'.$galleryImage->image_uuid.'.'.$galleryImage->file_ext) }}" alt="">
                        </div>
                    @empty
                        <div class="item active">
                            <img class="first-slide img-responsive" src="{{ asset('images/gallery4.jpg') }}" alt="First slide">
                        </div>
                    @endforelse

                </div>
                <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div><!-- /.carousel -->
            --}}
        </div>
        <div class="cover-container cover-bottom">
            <div class="cover">
                <p>{{ $space->room_name }}<span class="location m-left-40">{{ $space->building->street_address_1 }} @if($space->floor->name)<a href="{{ url('buildings', $space->building->private_slug) . '?floor=' . $space->floor->id }}">{{ $space->floor->name }}</a>@endif @if($space->building->name), <a href="{{ url('buildings', $space->building->private_slug) }}">{{ $space->building->name }}</a>@endif</span></p>
            </div>
        </div>
    </div>
</div>
