@section('message-host-cta')
    <?php $user = Auth::user() ?>
    <div class="row support-section">
        <div class="avatar">
            @if ($host && isset($host->profileImage[0]) && $host->profileImage[0]->image_uuid)
                <img class='img-responsive' src="{{ asset('images/uploads/'.$host->profileImage[0]->image_uuid.'.'.$host->profileImage[0]->file_ext.'') }}"/>
            @else
                <img class='img-responsive' src="{{ asset('images/missing_profile.png') }}"/>
            @endif
        </div>
        <div class="details m-top-20">
            <p>
                <span class="text-light-gray">YOUR HOST IS</span><br/>
                <span class="text-dark">
                    @if ($space->host && $space->host->contact_name)
                        {{ $space->host->contact_name }}
                    @else
                        Sally
                    @endif
            </span><br/>
            </p>
            <p class="m-top-10">
                <button class="btn btn-black text-capitalize" role="button" data-toggle="modal" data-target="#message-host-dialog">MESSAGE HOST</button>
            </p>
        </div>
    </div>
@endsection

@section('message-host-modal')
    <div class="modal fade" id="message-host-dialog" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h2 id="modal-title" class="text-center">Send a message to {{ $space->host->contact_name }}</h2>
                </div>
                {!! Form::open(['route' => ['hosts.message', 'host_id' => $space->host->id, 'space_id' => $space->id], 'method' => '', 'id' => 'message-host-form', 'role' => 'form']) !!}
                {!! Form::hidden('_method', 'post') !!}
                {!! Form::hidden('space_id', $space->id) !!}
                <div class="modal-body">
                    <div class="message-host-alert alert alert-success alert-light collapse"></div>
                    <div class="message-host-alert alert alert-danger alert-light collapse"></div>
                    <div class="form-group has-feedback">
                        <label for="message" class="control-label">Your Name <i class="fa fa-asterisk text-danger"></i></label>
                        {!! Form::text('name', !is_null($user) ? $user->full_name : '', ['id' => 'name', 'class' => 'form-control', 'data-error' => "Please tell us your name.", 'required' => 'required']) !!}
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group has-feedback">
                        <label for="message" class="control-label">Your Email <i class="fa fa-asterisk text-danger"></i></label>
                        {!! Form::email('email', !is_null($user) ? $user->email : '', ['id' => 'email', 'class' => 'form-control', 'data-error' => "Please enter a vbalid email address.", 'required' => 'required']) !!}
                        <div class="help-block with-errors"></div>
                    </div>

                    <div class="form-group has-feedback">
                        <label for="user_message" class="control-label">Your Message <i class="fa fa-asterisk text-danger"></i></label>
                        {!! Form::textarea('user_message', null, ['id' => 'user_message', 'placeholder' => 'Tell us what\'s on your mind', 'data-error' => "Please enter a message.", 'class' => 'form-control', 'required' => 'required']) !!}
                        <div class="help-block with-errors"></div>
                    </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="submit"> Send</button>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection

@section('message-form-script')
    <script type="text/javascript">
        $(function () {
            var submitButton = $('#message-host-form [name="submit"]');
            $('[data-toggle="tooltip"]').tooltip({placement: 'top', container: 'body'});
            $('#message-host-form').validator().on('submit', function (event) {
                $('.message-host-alert').hide();
                if (!event.isDefaultPrevented()) {
                    submitThrobber(submitButton, true);
                    event.preventDefault();
                    $.ajax({
                        method: 'post',
                        url: $(this).prop('action'),
                        data: $(this).serialize(),
                        success: function (data) {
                            $('.message-host-alert.alert-success').html(data.message).show();
                            submitThrobber(submitButton, false);
                        },
                        error: function (data) {
                            $('.message-host-alert.alert-danger').html(data.responseJSON.message).show();
                            submitThrobber(submitButton, false);
                        }
                    });
                }
            });
            $('#message-host-dialog').on('show.bs.modal', function () {
                $('.message-host-alert').hide();
                $('#message-host-form').get(0).reset();
                submitThrobber(submitButton, false);
            });

            var submitThrobber = function(element, disabled) {
                $(element).prop('disabled', disabled);
                var throbber = $('<i class="fa fa-circle-o-notch fa-spin">');
                if (disabled) {
                    $(element).prepend(throbber);
                } else {
                    $(element).children('i').remove();
                }
            };
        });
    </script>
@endsection