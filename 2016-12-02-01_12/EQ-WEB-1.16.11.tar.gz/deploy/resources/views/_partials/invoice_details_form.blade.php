<div class="row m-top-20">
    <div class="col-md-6">
        <div class="form-group has-feedback">
            {!! Form::label('company_name', 'Company Name') !!} 
            {!! Form::text('company_name', null, ['id' => 'company_name', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Company Name.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group has-feedback">
            {!! Form::label('company_address', 'Address') !!} 
            {!! Form::text('company_address', null, ['id' => 'company_address', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Company Address.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group has-feedback">
            {!! Form::label('company_city', 'City') !!} 
            {!! Form::text('company_city', null, ['id' => 'company_city', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter City.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group has-feedback">
            {!! Form::label('company_postcode', 'Postcode') !!} 
            {!! Form::number('company_postcode', null, ['id' => 'company_postcode', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Postcode.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="form-group has-feedback">
            {!! Form::label('company_state', 'State') !!} 
            {!! Form::text('company_state', null, ['id' => 'company_state', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter State.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group has-feedback">
            {!! Form::label('company_country', 'Country') !!} 
            {!! Form::text('company_country', null, ['id' => 'company_country', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Country.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group has-feedback person_responsible">
            {!! Form::label('contact_name', 'Person responsible for paying invoice (if different to person logged in') !!} 
            {!! Form::text('contact_name', Auth::user()->first_name.' '.Auth::user()->last_name, ['id' => 'contact_name', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Name.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback m-top-20" aria-hidden="true"></span>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6">
        <div class="form-group has-feedback">
            {!! Form::label('purchase_order', 'Purchase Order') !!} 
            {!! Form::text('purchase_order', null, ['id' => 'purchase_order', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Purchase Order.']) !!}
            <div class="help-block with-errors"></div>
            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
        </div>
    </div>
</div>