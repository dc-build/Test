<div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="loginmodal-container">
            <h1>Login to Your Account</h1><br>
            {!! Form::open(['route' => 'login.post']) !!}
                <div class="form-group {{ ($errors->has('email')) ? 'has-error' : '' }}">
                    {!! Form::label('email', 'Email Address') !!}
                    {!! Form::text('email' ,null , ['required']) !!}
                    <span class='label label-danger text-center'>{{ ($errors->has('email') ? $errors->first('email') : '') }}</span>
                </div>
                <div class="form-group {{ ($errors->has('password')) ? 'has-error' : '' }}">
                    {!! Form::label('password', 'Password') !!}
                    {!! Form::password('password', ['required']) !!}
                    <span class='label label-danger text-center'>{{ ($errors->has('password') ? $errors->first('password') : '') }}</span>
                </div>
                {!! Form::submit('SUBMIT', ['class' => 'login loginmodal-submit']) !!}
            {!! Form::close() !!}

            <div class="login-help">
                <a href="#" data-dismiss="modal" data-toggle="modal" data-target="#password-modal">Forgot Password</a>
            </div>
        </div>
    </div>
</div>