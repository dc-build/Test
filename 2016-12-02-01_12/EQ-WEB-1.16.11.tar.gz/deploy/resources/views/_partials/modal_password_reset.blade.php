<div class="modal fade" id="password-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <div class="loginmodal-container">
            <h1>Forgot Password</h1><br>
            @if(Session::has('success'))
                <div class="alert alert-success"><i class="fa fa-check"></i>  {{ session('success') }} </div>
            @endif
            {!! Form::open(['route' => 'password-reset.request']) !!}
                <div class="form-group {{ ($errors->has('email')) ? 'has-error' : '' }}">
                    {!! Form::label('email', 'Email Address') !!}
                    {!! Form::text('email',null,['required']) !!}
                    <span class='label label-danger text-center'>{{ ($errors->has('email') ? $errors->first('email') : '') }}</span>
                </div>
                {!! Form::submit('SUBMIT', ['class' => 'login loginmodal-submit']) !!}
            {!! Form::close() !!}
        </div>
    </div>
</div>