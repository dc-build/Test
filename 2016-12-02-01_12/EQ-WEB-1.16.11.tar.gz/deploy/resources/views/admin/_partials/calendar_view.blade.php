@section('calendar-select')
    
@stop

@section('calendar-section')
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <select class="form-horizontal selectpicker" id="calendar_space_id" name="calendar_space_id">
                        <option value="">Display All</option>
                        <optgroup label="Spaces">
                            @foreach ($spaces as $space)
                                <option value="{{ $space->id }}">{{ $space->room_name }}</option>
                            @endforeach
                        </optgroup>
                    </select>
                </div>
                <div class="panel-body">
                    <div id='calendar' class="calendarView"></div>
                </div>
            </div>
        </div>
    </div>
@stop

@section('calendar-modal')
<div class="modal fade" id="calendarModal" tabindex="-1" role="dialog">
    <div class="modal-dialog  modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id='calendar' class="calendarView"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
            </div>
        </div>
    </div>
</div>
@stop

@section('calendar-scripts-all')
    <script>
        $(document).ready(function () {
            function displayCalendar(route) {
                $('#calendar').generateCalendar({
                    events_route : route,
                    height : '400',
                    eventLimit : false
                });
            }
            
            var default_route = "{{ route('api.calendars.index') }}";
            displayCalendar(default_route);

            $("#calendar_space_id").change(function() {
                var space_id = $(this).val();
                if (space_id) {
                    var new_route = default_route+"/spaces/"+space_id;
                    displayCalendar(new_route);
                }
                else {
                    displayCalendar(default_route);
                }
            });
        });
    </script>
@stop