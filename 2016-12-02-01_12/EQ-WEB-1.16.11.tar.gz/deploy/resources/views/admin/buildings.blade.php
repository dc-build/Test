@extends('admin.layout')

@section('title')
    Buildings
@stop



@section('custom-scripts')
    
    <script>

        CKEDITOR.config.toolbar = [
            ['Styles','Format','Font','FontSize'],
            ['Bold','Italic','Underline','StrikeThrough','-','Undo','Redo','-','Cut','Copy','Paste','Find','Replace'],
            '/',
            ['NumberedList','BulletedList','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
            ['Image','Table','-','Link','Smiley','TextColor','BGColor','Source']
        ] ;

        CKEDITOR.replace("other_services");

        for ( instance in CKEDITOR.instances ) {
            var editor = CKEDITOR.instances[instance];
            editor.on('change', editor.updateElement);
        }

        $(document).ready(function() {
            $(".buildings-table").DataTable({
                "language": {
                    "emptyTable": "NO BUILDINGS FOUND."
                },
                "ajax" : "/api/buildings",
                "columns": [
                    { "data": "id" },
                    { "data": "name"},
                    { "data": "street_address_1" },
                    { "data": "street_address_2" },
                    { "data": "locality.name" },
                    { "data": "region.name" },
                    { "data": "country.nicename" },
                    { "data": "postcode" },
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.logo_image[0] && row.logo_image[0].image_uuid) {
                                var img = "{{ asset('images/uploads') }}/"+row.logo_image[0].image_uuid+"."+row.logo_image[0].file_ext;
                                return '<img class="img-responsive" src="'+img+'">';
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.header_image[0] && row.header_image[0].image_uuid) {
                                var img = "{{ asset('images/uploads') }}/"+row.header_image[0].image_uuid+"."+row.header_image[0].file_ext;
                                return '<img class="img-responsive" src="'+img+'">';
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { "data": "other_services" },
                    {"data": "direct_url"},
                    {
                        "data": "created_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "createdby",
                        "render": function (data) {
                            if (data) {
                                return data.full_name;
                            }
                        }
                    },
                    {
                        "data": "updated_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "updatedby",
                        "render": function (data) {
                            if (data) {
                                return data.full_name;
                            }
                        }
                    },
                    {
                        "className": "text-right",
                        "width" : '225',
                        "data": "dummy",
                        "orderable": false,
                        "render": function(data, type, row, meta) {
                            return '<a class="btn btn-danger" data-id="' + row.id + '" data-title="Delete Building" data-action="delete" data-name="' + Object.escapeHtml(row.name) + '"  data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;' +
                                '<a  class="btn btn-primary" data-id="' + row.id + '" data-title="Edit Building" data-action="edit" data-name="' + Object.escapeHtml(row.name) + '" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                        }
                    }
                ],
                "deferRender" : true,
                "paging" : true,
                "responsive" : true
            });

            $("#modalForm").fsm({
                modalId: '#formModal',
                useBootstrapValidator: true,
                showErrorSummary: true,
                addApiUrl: '/api/buildings',
                editApiUrl: '/api/buildings/',
                deleteApiUrl: '/api/buildings/',
                onPreSubmitHook: function (e) {
                    $('#formSubmit').innerHTML = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>';
                },
                onAddHook: function () {
                    $('#modal-title').text('Add Building');
                    $('#country_id').trigger('related.needs_update');
                    $('#previewLogo').empty();
                    $('#previewHeader').empty();
                    CKEDITOR.instances['other_services'].setData('');
                },
                onPrePopulateHook: function () {
                },
                onEditHook: function (data) {
                    $('#modal-title').text('Edit Building');
                    $('#country_id').trigger('related.needs_update');
                    CKEDITOR.instances['other_services'].setData(data.description);

                    //turn the hosts array into an array of just the ids
                    var hostIds = data.hosts.map(function(a) {return a.id;});
                    $.each(hostIds, function(i,e){
                        $("#hosts_id option[value='" + e + "']").prop("selected", true);
                    });
                    $('#hosts_id').multiSelect('refresh');

                    if (data.logo_image[0] && data.logo_image[0].image_uuid) {
                        var img = "<img class='img-responsive thumbnail' src='{{ asset('images/uploads') }}/"+data.logo_image[0].image_uuid+"."+data.logo_image[0].file_ext+"' />";
                        $('#previewLogo').html(img);
                    }
                    if (data.header_image[0] && data.header_image[0].image_uuid) {
                        var img = "<img class='img-responsive thumbnail' src='{{ asset('images/uploads') }}/"+data.header_image[0].image_uuid+"."+data.header_image[0].file_ext+"' />";
                        $('#previewHeader').html(img);
                    }

                },
                onDeleteHook: function () {
                    $('#modal-title').text('Delete Building');
                    return true;
                },
                onHideModalHook: function () {
                    // Reload the grid
                    $('.data-table').DataTable().ajax.reload();
                }
            });

            //Create the multiselect field for hosts
            $('#hosts_id').multiSelect({cssClass: 'fsm-multiselect', selectableHeader: "<div class='custom-header'>Available Hosts</div>", selectionHeader: "<div class='custom-header'>Hosts in this building</div>",});

            $('#country_id').relatedSelect({url: '/api/countries/true', child: '#region_id'});
            $('#region_id').relatedSelect({
                url: '/api/countries/{country_id}/regions/true',
                child: '#locality_id',
                urlParser: function (baseUrl, countryId) {
                    return typeof countryId != 'undefined' && countryId != "" ?
                        baseUrl.replace('{country_id}', countryId) : '';
                }
            });
            $('#locality_id').relatedSelect({
                url: '/api/regions/{region_id}/localities',
                urlParser: function (baseUrl, regionId) {
                    return typeof regionId != 'undefined' && regionId != "" ?
                        baseUrl.replace('{region_id}', regionId) : '';
                }
            });


            /* Preview uploaded files on browse */
            function readURL(input,preview,value) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function (e) {
                        $(preview).html('<img id="preview" class="img-responsive thumbnail" src="'+e.target.result+'" />');
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }
            
            $("#logo_image").change(function(){
                readURL(this, "#previewLogo");
            });
            
            $("#header_image").change(function(){
                readURL(this, "#previewHeader");
            });
            
        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Buildings <button type="button" class="pull-right btn btn-primary" data-title="Add Building" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New Building</button></h1>
        </section>
        
        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="buildings-table display table responsive stripe compact" width="100%">
                                <thead>
                                    <tr>
                                        <th class="all">ID</th>
                                        <th class="all">Name</th>
                                        <th class="all">Street Address 1</th>
                                        <th class="none">Street Address 2</th>
                                        <th class="all">Locality</th>
                                        <th class="all">Region</th>
                                        <th class="all">Country</th>
                                        <th class="all">Post Code</th>
                                        <th class="none">Logo</th>
                                        <th class="none">Header</th>
                                        <th class="none">Other Services</th>
                                        <th class="none">Date Created</th>
                                        <th class='none'>Direct Url</th>
                                        <th class="none">Created by</th>
                                        <th class="all">Date Updated</th>
                                        <th class="all">Updated by</th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
        </section>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->

    <!-- Modal to edit buildings -->
    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light"></div>
                    <div class="alert alert-danger alert-light"></div>
                    <hr />
                    {!! Form::open(['route' => ['api.buildings.create', 'id' => ''], 'method' => '', 'id' => 'modalForm', 'class' => 'modalForm']) !!}
                        <input type="hidden" name="_method" value="">
                        <div id="deleteMessage">
                            <p class="text-center" id="confirmation"></p>
                            <p class="text-center" id="details"></p>
                        </div>
                        <div id="formContainer">
                            <div class="col-md-6">
                                <div class="form-group has-feedback">
                                    <label for="name" class="control-label">Name</label>
                                    {!! Form::text('name', null, ['id' => 'name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group has-feedback">
                                    <label for="street_address_1" class="control-label">Street Address 1 <i class="fa fa-asterisk text-danger"></i></label>
                                    {!! Form::text('street_address_1', null, ['id' => 'street_address_1', 'placeholder' => '', 'class' => 'form-control', 'required' => 'required']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group has-feedback">
                                    <label for="street_address_2" class="control-label">Street Address 2</label>
                                    {!! Form::text('street_address_2', null, ['id' => 'street_address_2', 'placeholder' => '', 'class' => 'form-control']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group has-feedback">
                                    <label for="postcode" class="control-label">Post Code <i class="fa fa-asterisk text-danger"></i></label>
                                    {!! Form::text('postcode', null, ['id' => 'postcode', 'placeholder' => '', 'class' => 'form-control', 'required' => 'required']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group has-feedback">
                                    <label for="country_id" class="control-label">Country <i class="fa fa-asterisk text-danger"></i></label>
                                    {!! Form::select('country_id', [], null, ['id' => 'country_id', 'placeholder' => '- Select a Country -', 'class' => 'form-control', 'required' => 'required']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group has-feedback">
                                    <label for="region_id" class="control-label">Region <i class="fa fa-asterisk text-danger"></i></label>
                                    {!! Form::select('region_id', [], null, ['id' => 'region_id', 'placeholder' => '- Select a Region -', 'class' => 'form-control', 'required' => 'required']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group has-feedback">
                                    <label for="locality_id" class="control-label">Locality <i class="fa fa-asterisk text-danger"></i></label>
                                    {!! Form::select('locality_id', [], null, ['id' => 'locality_id', 'placeholder' => '- Select a Locality -', 'class' => 'form-control', 'required' => 'required']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group has-feedback">
                                    <label for="postcode" class="control-label">Direct Url <i class="fa fa-asterisk text-danger"></i></label>
                                    {!! Form::text('direct_url', null, ['id' => 'direct_url', 'placeholder' => '', 'class' => 'form-control', 'required' => 'required']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>

                            <div class="col-xs-12">
                                <hr />
                                <label for="hosts" class="control-label">Hosts</label>
                                {!! Form::select('hosts[]', $hosts, null, ['id' =>"hosts_id", 'class' => 'form-control', 'multiple' => 'multiple']) !!}
                                <div class="text-warning"><strong><i class="fa fa-warning"></i> Warning:</strong> Removing a Host from a Building will also remove the Host Admins that have been assigned to this Building for that host</div>
                            </div>
                            <div class="col-xs-12">
                                <hr />
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group has-feedback">
                                            <label for="logo_image" class="control-label">Logo Image</label>
                                            <span id="previewLogo"></span>
                                            <span class="fileupload fileupload-new" data-provides="fileupload">
                                                <span class="btn btn-default btn-file form-control">
                                                    <i class="fa fa-picture-o" aria-hidden="true"></i> Add Logo Image
                                                    <input type="file" name="logo_image" id="logo_image" accept="image/*" />
                                                </span>
                                            </span>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group has-feedback">
                                            <label for="header_image" class="control-label">Header Image</label>
                                            <span id="previewHeader"></span>
                                            <span class="fileupload fileupload-new" data-provides="fileupload">
                                                <span class="btn btn-default btn-file form-control">
                                                    <i class="fa fa-picture-o" aria-hidden="true"></i> Add Header Image
                                                    <input type="file" name="header_image" id="header_image" accept="image/*" />
                                                </span>
                                            </span>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                </div>
                                <hr />
                                <div class="form-group has-feedback">
                                    <label for="other_services" class="control-label">Other Services</label>
                                    {!! Form::textarea('other_services', null, ['id' => 'other_services', 'placeholder' => '', 'class' => 'form-control']) !!}
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <hr style="clear:both" />
                        </div>
                        <div class="text-left">
                            {!! Form::hidden('id', null, ['id' => 'buildingID']) !!}
                            <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                            <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                        </div>
                    {!! Form::close() !!} 
                </div>
            </div>
        </div>
    </div>

@stop
