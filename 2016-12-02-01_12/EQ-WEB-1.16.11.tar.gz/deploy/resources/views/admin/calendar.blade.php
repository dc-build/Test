@extends('admin.layout')
@include('admin._partials.calendar_view')

@section('title')
    Calendar
@stop

@section('custom-scripts')
    @yield('calendar-scripts-all')
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                Calendar
                @yield('calendar-select')
            </h1>
        </section>

        <section class="content">
            @yield('calendar-section')
        </section>
    </div>
@stop