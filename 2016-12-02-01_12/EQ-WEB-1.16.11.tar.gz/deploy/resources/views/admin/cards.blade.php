@extends('admin.layout')

@section('title')
    Cards
@stop

@section('custom-scripts')
    
    <script>
        $(document).ready(function () {
            $(".data-table").DataTable({
                "language": {
                    "emptyTable": "NO CARDS FOUND."
                },
                "ajax": "/api/cards",
                "columns": [
                    { "data": "id"},
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.hosts && row.hosts[0].company_name && row.hosts[0].id) {
                                return row.hosts[0].company_name +" (ID "+row.hosts[0].id+")";
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.user && row.user.email && row.user.id) {
                                return row.user.email +" (ID "+row.user.id+")";
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { "data": "card_name" },
                    {
                        "data": "last_four",
                        "render": function(data, type, row, meta) {
                            return $.fn.creditcard(data);
                        }
                    },
                    {
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            return sprintf("%02d / %04d", row.expiry_month, row.expiry_year);
                        }
                    },
                    { "data": "gateway_customer_id" },
                    { "data": "gateway_card_id" },
                    {
                        "data": "created_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "updated_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                ],
                "deferRender": true,
                "paging": true,
                "responsive": true
            });
            
            

        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Cards</h1>
        </section>

        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="data-table display table responsive stripe compact" width="100%">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Host</th>
                                    <th>User</th>
                                    <th>Name</th>
                                    <th>Card Number</th>
                                    <th>Expiry</th>
                                    <th class="none">Gateway Customer ID</th>
                                    <th class="none">Gateway Card ID</th>
                                    <th class="none">Date Created</th>
                                    <th class="all">Date Updated</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>

    

@stop