@extends('admin.layout')

@section('title')
    Floors
@stop

@section('custom-scripts')
    <script>
        $(document).ready(function () {

            $(".data-table").DataTable({
                "language": {
                    "emptyTable": "NO FLOORS FOUND."
                },
                "ajax": "/api/floors",
                "columns": [
                    { "data": "id" },
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.building && row.building.name) {
                                return Object.escapeHtml(row.building.name);
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { "data": "name"
                    },
                    { "data": "order" },
                    {
                        "data": "created_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "createdby",
                        "render": function (data) {
                            if (data) {
                                return data.full_name;
                            }
                        }
                    },
                    {
                        "data": "updated_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "updatedby",
                        "render": function (data) {
                            if (data) {
                                return data.full_name;
                            }
                        }
                    },
                    {
                        "className": "text-right",
                        "width": '225',
                        "data": "dummy",
                        "orderable": false,
                        "render": function (data, type, row, meta) {
                            var editButton =  '<a  class="btn btn-primary" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Edit Floor" data-action="edit" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                            var deleteButton = '<a class="btn btn-danger" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Delete Floor" data-action="delete" data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;';
                            return deleteButton + editButton;
                        }
                    }
                ],
                "deferRender": true,
                "paging": true,
                "responsive": true
            });

            $("#modalForm").fsm({
                modalId: '#formModal',
                useBootstrapValidator: true,
                showErrorSummary: true,
                addApiUrl: '/api/floors',
                editApiUrl: '/api/floors/',
                deleteApiUrl: '/api/floors/',
                onPreSubmitHook: function(e) {
                    $('#formSubmit').innerHTML = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>';
                },
                onAddHook: function() {
                    $('#modal-title').text('Add Floor');
                },
                onPrePopulateHook: function() {
                },
                onEditHook: function(data) {
                    $('#modal-title').text('Edit Floor');
                },
                onDeleteHook: function() {
                    $('#modal-title').text('Delete Floor');
                    return true;
                },
                onHideModalHook: function() {
                    // Reload the grid
                    $('.data-table').DataTable().ajax.reload();
                }
            });

        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Floors <button type="button" class="pull-right btn btn-primary" data-title="Add Floor" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New Floor</button></h1>
        </section>

        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="data-table display table responsive stripe compact" width="100%">
                                <thead>
                                <tr>
                                    <th class="all">ID</th>
                                    <th class="all">Building</th>
                                    <th class="all">Name</th>
                                    <th class="all">Order</th>
                                    <th class="none">Date Created</th>
                                    <th class="none">Created by</th>
                                    <th class="all">Date Updated</th>
                                    <th class="all">Updated by</th>
                                    <th class="text-right">Action</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>
    <!-- /#page-wrapper -->

    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light"></div>
                    <div class="alert alert-danger alert-light"></div>
                    <hr/>
                    {!! Form::open(['route' => ['api.spaceconfigurations.create', 'id' => ''], 'method' => '', 'id' => 'modalForm', 'class' => 'modalForm']) !!}
                    <input type="hidden" name="_method" value="">
                    <div id="deleteMessage">
                        <p class="text-center" id="confirmation"></p>
                        <p class="text-center" id="details"></p>
                    </div>
                    <div id="formContainer">
                        <div class="form-group has-feedback">
                            <label for="name" class="control-label">Name <i class="fa fa-asterisk text-danger"></i></label>
                            {!! Form::text('name', null, ['id' => 'name', 'placeholder' => '', 'class' => 'form-control', 'required' => 'required']) !!}
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group has-feedback">
                            <label for="building_id" class="control-label">Building <i class="fa fa-asterisk text-danger"></i></label>
                            {!! Form::select('building_id', $buildings->lists('name', 'id'), null, ['id' => 'building_id', 'placeholder' => 'Select a Building', 'class' => 'form-control', 'required' => 'required']) !!}
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group has-feedback">
                            <label for="order" class="control-label">Order <i class="fa fa-asterisk text-danger"></i></label>
                            {!! Form::text('order', null, ['id' => 'order', 'placeholder' => '', 'class' => 'form-control', 'required' => 'required']) !!}
                            <div class="help-block with-errors"></div>
                        </div>
                         <hr style="clear:both"/>
                    </div>
                    <div class="text-left">
                        {!! Form::hidden('id', null, ['id' => 'floorID']) !!}
                        <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

@stop