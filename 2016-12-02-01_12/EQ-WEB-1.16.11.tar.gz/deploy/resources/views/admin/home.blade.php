@extends('admin.layout')

@section('title')
    Dashboard
@stop

@section('custom-css')
   
@stop

@section('custom-scripts')

@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Dashboard</h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="fa fa-users"></i></span>
                    <a href="{{ route('admin.users') }}">
                        <div class="info-box-content">
                          <span class="info-box-text">Users</span>
                          <span class="info-box-number">10</span>
                        </div>
                    </a>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-red"><i class="fa fa-map-marker"></i></span>
                    <a href="{{ route('admin.buildings') }}">
                        <div class="info-box-content">
                          <span class="info-box-text">Buildings</span>
                          <span class="info-box-number">10</span>
                        </div>
                    </a>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->

                <!-- fix for small devices only -->
                <div class="clearfix visible-sm-block"></div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="fa fa-th"></i></span>
                    <a href="{{ route('admin.spaces') }}">
                        <div class="info-box-content">
                          <span class="info-box-text">Spaces</span>
                          <span class="info-box-number">10</span>
                        </div>
                    </a>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="info-box">
                    <span class="info-box-icon bg-yellow"><i class="fa fa-calendar"></i></span>
                    <a href="{{ route('admin.spacebookings') }}">
                        <div class="info-box-content">
                          <span class="info-box-text">Bookings</span>
                          <span class="info-box-number">10</span>
                        </div>
                    </a>
                    <!-- /.info-box-content -->
                  </div>
                  <!-- /.info-box -->
                </div>
                <!-- /.col -->
              </div>
            
        </section>
    </div>
        <!-- /#page-wrapper -->
@stop
