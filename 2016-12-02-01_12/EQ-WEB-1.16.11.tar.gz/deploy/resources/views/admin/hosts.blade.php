@extends('admin.layout')

@section('title')
    Hosts
@stop

@section('custom-css')
@stop

@section('custom-scripts')
    <script>
        $(document).ready(function () {
            $(".hosts-table").DataTable({
                language: {
                    emptyTable: "NO HOSTS FOUND."
                },
                ajax: "/api/hosts",
                columns: [
                    {data: "id"},
                    {data: "company_name"},
                    {data: "company_abn"},
                    {data: "street_address_1"},
                    {data: "street_address_2"},
                    {
                        data: "locality.name",
                        render: function (data, type, row, meta) {
                            return typeof data == 'undefined' ? 'Not Specified' : data;
                        }
                    },
                    {
                        data: "region.name",
                        render: function (data, type, row, meta) {
                            return typeof data == 'undefined' ? 'Not Specified' : data;
                        }
                    },
                    {data: "country.nicename"},
                    {data: "postcode"},
                    {data: "contact_name"},
                    {data: "contact_email"},
                    {data: "contact_phone"},
                    {data: "contact_position"},
                    {
                        data: "creditcard",
                        render: function(data, type, row, meta)
                        {
                            return data ? data.card_name + ' (' + data.last_four + ')' : 'None specified';
                        }
                    },
                    {data: "created_at"},
                    {data: "updated_at"},
                    {
                        className: "text-right",
                        width: '225',
                        data: "dummy",
                        orderable: false,
                        render: function (data, type, row, meta)
                        {
                            var actions = '';
                            @can('destroy', 'App\Http\Controllers\HostController')
                            actions += '<a class="btn btn-danger" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.company_name) + '"   data-title="Delete Host" data-action="delete" data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;';
                            @endcan

                            actions += '<a  class="btn btn-primary" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.company_name) + '"   data-title="Edit Host" data-action="edit" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                            return actions;
                        }
                    }
                ],
                deferRender: true,
                paging: true,
                responsive: true
            });

            @can('assignHostAdmin', 'App\Http\Controllers\HostController')
                //Create the multiselect field for hosts
                $('#hostadmins_id').multiSelect({cssClass: 'fsm-multiselect', selectableHeader: "<div class='custom-header'>Available Users</div>", selectionHeader: "<div class='custom-header'>Host Administrators</div>",});
            @endcan

            $('#hostbuildingadminids').multiSelect({cssClass: 'fsm-multiselect', selectableHeader: "<div class='custom-header'>Available Users</div>", selectionHeader: "<div class='custom-header'>Building Administrators</div>",
                afterSelect: function(values){
                    hostBuildingAdminsChangeHandler(values);
                },
                afterDeselect: function(values){
                    hostBuildingAdminsChangeHandler(values);
                }});
            $('select#hostbuildingsid').change(buildingAdminSelectChangeHandler);

            $('#country_id').relatedSelect({url: '/api/countries/true', child: '#region_id'});
            $('#region_id').relatedSelect({
                url: '/api/countries/{country_id}/regions/true',
                child: '#locality_id',
                urlParser: function (baseUrl, countryId) {
                    return typeof countryId != 'undefined' && countryId != "" ?
                        baseUrl.replace('{country_id}', countryId) : '';
                }
            });
            $('#locality_id').relatedSelect({
                url: '/api/regions/{region_id}/localities',
                urlParser: function (baseUrl, regionId) {
                    return typeof regionId != 'undefined' && regionId != "" ?
                        baseUrl.replace('{region_id}', regionId) : '';
                }
            });

            $("#modalForm").fsm({
                modalId: '#formModal',
                isMultiPart: true,
                useBootstrapValidator: true,
                showErrorSummary: true,
                addApiUrl: '/api/hosts',
                editApiUrl: '/api/hosts/',
                deleteApiUrl: '/api/hosts/',
                onPreSubmitHook: function(e) {
                    $('#formSubmit').innerHTML = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>';
                },
                onAddHook: function() {
                    $('#country_id').trigger('related.needs_update');

                    @can('assignHostAdmin', 'App\Http\Controllers\HostController')
                    $("select#hostadmins_id option").prop("selected", false);
                    $('#hostadmins_id').multiSelect('refresh');
                    @endcan

                    $('#buildingadminstab').hide();
                },
                onPrePopulateHook: function() {
                },
                onEditHook: function(data) {
                    $('#country_id').trigger('related.needs_update');

                    @can('assignHostAdmin', 'App\Http\Controllers\HostController')
                    //turn the hosts array into an array of just the ids
                    $("select#hostadmins_id option").prop("selected", false);
                    var hostAdminsIds = data.hostadmins.map(function(a) {return a.id;});
                    $.each(hostAdminsIds, function(i,e){
                        $("#hostadmins_id option[value='" + e + "']").prop("selected", true);
                    });
                    $('#hostadmins_id').multiSelect('refresh');
                    @endcan

                    //Building Administrators
                    $('#buildingadminstab').show();

                    //populate the buildings drop down with the buildings in this host
                    prepareBuildingAdmin(data.buildingadmins, data.hostadmins);

                    if (data.logo_image[0] && data.logo_image[0].url) {
                        $('#previewLogo').empty().append(
                            $("<img class='img-responsive thumbnail' />").prop('src', data.logo_image[0].url)
                        );
                    }
                    
                    if (data.profile_image[0] && data.profile_image[0].url) {
                        $('#previewProfile').empty().append(
                            $("<img class='img-responsive thumbnail' />").prop('src', data.profile_image[0].url)
                        );
                    }

                    var toggleCardButton = $('[name="toggle_card_form"]');

                    if (data.creditcard) {
                        prepareCardDisplay(data, $('#creditcard-container'));
                        toggleCardButton.data('action', 'delete');
                    } else {
                        toggleCardButton.data('action', 'add');
                    }
                    setCardButtonDisplay(toggleCardButton);
                },
                onDeleteHook: function() {
                    return true;
                },
                onHideModalHook: function() {
                    // Reload the grid
                    $('.hosts-table').DataTable().ajax.reload();
                }
            });

            /* Preview uploaded files on browse */
            function readURL(input,preview,value) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function (e) {
                        $(preview).html('<img id="preview" class="img-responsive thumbnail" src="'+e.target.result+'" />');
                    };

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#host_image").change(function(){
                readURL(this, "#previewHost");
            });

            $("#logo_image").change(function(){
                readURL(this, "#previewLogo");
            });
            
            $("#profile_image").change(function(){
                readURL(this, "#previewProfile");
            });

            var creditcardFormElements = [
                {name: 'card_name', id: 'card_name', is_required: true, label_text: 'Card Name', placeholder: 'Name the card', type: 'text'},
                {name: 'name_on_card', id: 'name_on_card', is_required: true, label_text: 'Name on Card', placeholder: 'Card holder\'s name', type: 'text'},
                {name: 'card_number', id: 'card_number', is_required: true, label_text: 'Card Number', placeholder: 'Card Number', type: 'text'},
                {name: 'expiry_month', id: 'expiry_month', is_required: true, label_text: 'Expiry Month', placeholder: '--Month--', type: 'select', options: $.fn.arrayOfMonths()},
                {name: 'expiry_year', id: 'expiry_year', is_required: true, label_text: 'Expiry Year', placeholder: '--Year--', type: 'select', options: $.fn.arrayOfYears(10)},
                {name: 'cvv', id: 'cvv', is_required: true, label_text: 'CVV', placeholder: '', type: 'text'}
            ];

            $('[name="toggle_card_form"]').on('click', function() {
                if ($(this).data('action') === 'add') {
                    $.fn.addFormElements(creditcardFormElements, $('#creditcard-container'));
                    $(this).data('action', 'delete');
                } else {
                    $('#creditcard-container div').remove();
                    $('input[name="delete_card"]').val('true');
                    $(this).data('action', 'add');
                }

                setCardButtonDisplay(this);
                $('#modalForm').validator('update');
            });
        });

        var currentBuildingAdminConf = { changed : false, data : null};
        function prepareBuildingAdmin(buildingAdmins, hostAdmins)
        {
            currentBuildingAdminConf.data = buildingAdmins;

            //add the buildings
            $('select#hostbuildingsid').empty().append('<option value="">Select a building</option>');
            $('select#hostbuildingadminids').empty();
            $.each(currentBuildingAdminConf.data, function(i,e)
            {
                $('select#hostbuildingsid').append('<option value="' + e.id + '">' + e.name + '</option>');
            });

            //add the host admins
            $.each(hostAdmins, function(i,e)
            {
                $('select#hostbuildingadminids').append('<option value="' + e.id + '">' + e.email + '</option>');
            });

            $('select#hostbuildingadminids').prop('disabled', 'disabled');
            $('#hostbuildingadminids').multiSelect('refresh');

            $('#hostadmindata').val(JSON.stringify(currentBuildingAdminConf));
        }

        function buildingAdminSelectChangeHandler(e)
        {
            //set all to unselected
            $("#hostbuildingadminids option").prop("selected", false);

            //update the hostadmins when a building is selected
            if(this.value !== '')
            {
                var admins = currentBuildingAdminConf.data[this.value].admins;
                $('select#hostbuildingadminids').prop('disabled', false);

                //loop through the admins already assigned to this building and select them
                $.each(admins, function(i,e)
                {
                    $("#hostbuildingadminids option[value='" + e + "']").prop("selected", true);
                });
            }
            else
            {
                $('select#hostbuildingadminids').prop('disabled', 'disabled');
            }

            $('#hostbuildingadminids').multiSelect('refresh');
        }

        function hostBuildingAdminsChangeHandler(values)
        {
            var buildingId = $('select#hostbuildingsid').val();
            var selectedOptions = $("#hostbuildingadminids").children("option").filter(":selected");

            currentBuildingAdminConf.data[buildingId].admins = [];
            $.each(selectedOptions, function(i,e){
                currentBuildingAdminConf.data[buildingId].admins.push($(e).val());
            });

            currentBuildingAdminConf.changed = true;
            //Add the jsonified array of buildingadmins to a hidden field for later submission
            $('#hostadmindata').val(JSON.stringify(currentBuildingAdminConf));
        }

        function prepareCardDisplay(data, container)
        {
            var cardDisplayTempl = '\
                <input type="hidden" name="creditcard_id" value="{creditcard_id}" />\
                <input type="hidden" name="delete_card" value="false" />\
                <div>\
                    <dl>\
                        <dt>Card Name</dt> <dd>{card_name}</dd></p>\
                        <dt>Name on Card</dt> <dd>{name_on_card}</dd></p>\
                        <dt>Last four digits</dt> <dd>{last_four}</dd></p>\
                        <dt>Expiry</dt> <dd>{expiry_month} / {expiry_year}</dd></p>\
                    </dl>\
                </div>\
            ';

            var cardTranslations = {
                creditcard_id: 'creditcard_id',
                card_name: 'creditcard.card_name',
                name_on_card: 'creditcard.name_on_card',
                last_four: 'creditcard.last_four',
                expiry_month: 'creditcard.expiry_month',
                expiry_year: 'creditcard.expiry_year'
            }

            $(container).empty().append($.fn.parseTempl(cardDisplayTempl, cardTranslations, data));
        }

        function setCardButtonDisplay(button) {
            var add = $('<span>ADD CREDITCARD <i class="fa fa-plus"></i></span>');
            var remove = $('<span>REMOVE CREDITCARD <i class="fa fa-times"></i></span>');

            if ($(button).data('action') === 'add') {
                $(button).html(add).toggleClass('btn-danger', false);
            } else {
                $(button).html(remove).toggleClass('btn-danger', true);
            }
        }
    </script>
@stop

@section('content')


    <div class="content-wrapper">
        <section class="content-header">
            <h1>Hosts
                @can('store', 'App\Http\Controllers\HostController')
                    <button type="button" class="pull-right btn btn-primary" data-title="Add Host" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New Host</button>
                @endcan
            </h1>
        </section>

        <section class="content">

            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="hosts-table display table responsive stripe compact" width="100%">
                                <thead>
                                <tr>
                                    <th class="all">ID</th>
                                    <th class="all">Company</th>
                                    <th class="all">ABN</th>
                                    <th class="none">Street Address 1</th>
                                    <th class="none">Street Address 2</th>
                                    <th class="none">Locality</th>
                                    <th class="none">Region</th>
                                    <th class="all">Country</th>
                                    <th class="none">Postcode</th>
                                    <th class="all">Contact Name</th>
                                    <th class="none">Contact Email</th>
                                    <th class="none">Contact Phone</th>
                                    <th class="none">Contact Position</th>
                                    <th class="none">Credit Card</th>
                                    <th class="none">Date Created</th>
                                    <th class="none">Date Updated</th>
                                    <th class="all text-right">Action</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
        </section>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->

    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light collapse"></div>
                    <div class="alert alert-danger alert-light collapse"></div>
                    <hr/>
                    {!! Form::open(['route' => ['api.hosts.create', 'id' => ''], 'method' => 'POST', 'id' => 'modalForm', 'class' => 'modalForm ', 'files' => true]) !!}
                    <input type="hidden" name="_method" value="">
                    <div id="deleteMessage" class="hidden">
                        <p class="text-center" id="confirmation"></p>
                        <p class="text-center" id="details"></p>
                    </div>
                    <div id="formContainer">

                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active">
                                <a href="#home" aria-controls="home" role="tab" data-toggle="tab">Address</a>
                            </li>
                            <li role="presentation">
                                <a href="#contact" aria-controls="contact" role="tab" data-toggle="tab">Contact</a>
                            </li>
                            <li role="presentation">
                                <a href="#images" aria-controls="images" role="tab" data-toggle="tab">Images</a>
                            </li>
                            @can('assignHostAdmin', 'App\Http\Controllers\HostController')
                            <li role="presentation">
                                <a href="#hostadmins" aria-controls="hostadmins" role="tab" data-toggle="tab">Administrators</a>
                            </li>
                            @endcan

                            <li role="presentation" id="buildingadminstab">
                                <a href="#hostadminsbuildings" aria-controls="hostadminsbuildings" role="tab" data-toggle="tab">Buildings Administrators</a>
                            </li>

                            <li role="presentation" id="creditcardtab">
                                <a href="#creditcard" aria-controls="creditcard" role="tab" data-toggle="tab">Credit Card</a>
                            </li>

                        </ul>


                        <div class="tab-content p-20">
                            <div role="tabpanel" class="tab-pane fade in active" id="home">
                                <fieldset>
                                    <legend>Address</legend>
                                    <div class="form-group has-feedback">
                                        <label for="company_name" class="control-label">Company <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::text('company_name', null, ['id' => 'company_name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="company_abn" class="control-label">ABN </label>
                                        {!! Form::text('company_abn', null, ['id' => 'company_abn', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="street_address_1" class="control-label">Address 1 <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::text('street_address_1', null, ['id' => 'street_address_1', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="street_address_2" class="control-label">Address 2 </label>
                                        {!! Form::text('street_address_2', null, ['id' => 'street_address_2', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="country_id" class="control-label">Country <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::select('country_id', [], null, ['id' => 'country_id', 'placeholder' => 'Select a Country', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="region_id" class="control-label">Region <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::select('region_id', [], null, ['id' => 'region_id', 'placeholder' => 'Select a Region', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="locality_id" class="control-label">Locality <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::select('locality_id', [], null, ['id' => 'locality_id', 'placeholder' => 'Select a Locality', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="postcode" class="control-label">Postcode <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::text('postcode', null, ['id' => 'postcode', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </fieldset>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="contact">
                                <fieldset>
                                    <legend>Contact</legend>
                                    <div class="form-group has-feedback">
                                        <label for="contact_name" class="control-label">Contact Name <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::text('contact_name', null, ['id' => 'contact_name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="contact_email" class="control-label">Contact Email <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::text('contact_email', null, ['id' => 'contact_email', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="contact_phone" class="control-label">Contact Phone <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::text('contact_phone', null, ['id' => 'contact_phone', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group has-feedback">
                                        <label for="contact_position" class="control-label">Contact Position <i class="fa fa-asterisk text-danger"></i></label>
                                        {!! Form::text('contact_position', null, ['id' => 'contact_position', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </fieldset>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="images">
                                <fieldset>
                                    <legend>Images</legend>

                                    <div class="form-group {{ ($errors->has('logo_image')) ? 'has-error' : '' }}">
                                        <label for="logo_image" class="control-label">Logo <i class="fa fa-asterisk text-danger"></i></label>
                                        <span id="previewLogo"></span>
                                        <span class="fileupload fileupload-new" data-provides="fileupload">
                                            <span class="btn btn-default btn-file form-control">
                                                <i class="fa fa-picture-o" aria-hidden="true"></i> Change Image
                                                <input type="file" name="logo_image" id="logo_image" accept="image/*"/>
                                            </span>
                                        </span>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                    <div class="form-group {{ ($errors->has('host_profile_image')) ? 'has-error' : '' }}">
                                        <label for="host_profile_image" class="control-label">Profile <i class="fa fa-asterisk text-danger"></i></label>
                                        <span id="previewProfile"></span>
                                        <span class="fileupload fileupload-new" data-provides="fileupload">
                                            <span class="btn btn-default btn-file form-control">
                                                <i class="fa fa-picture-o" aria-hidden="true"></i> Change Image
                                                <input type="file" name="profile_image" id="profile_image" accept="image/*"/>
                                            </span>
                                        </span>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </fieldset>
                            </div>

                            @can('assignHostAdmin', 'App\Http\Controllers\HostController')
                                <div role="tabpanel" class="tab-pane fade" id="hostadmins">
                                    <fieldset>
                                        <legend>Host Administrators</legend>
                                        <div class="form-group">
                                            <label for="hostadmins" class="control-label">Host Administrators <i class="fa fa-asterisk text-danger"></i></label>
                                            {!! Form::select('hostadmins[]', $hostadmins, null, ['id' =>"hostadmins_id", 'class' => 'form-control', 'multiple' => 'multiple']) !!}
                                            <div class="text-warning"><strong><i class="fa fa-warning"></i> Warning:</strong> Removing an Administrator from a Host will remove them from any Buildings they have been assigned to for that host</div>
                                        </div>
                                    </fieldset>
                                </div>
                            @endcan

                            <div role="tabpanel" class="tab-pane fade" id="hostadminsbuildings">
                                <fieldset>
                                    <legend>Building Administrators</legend>

                                    <div class="form-group">
                                        <div class="">
                                            <label for="hostbuildingsid" class="control-label">Add administrators for the following building <i class="fa fa-asterisk text-danger"></i></label>
                                            <input type="hidden" name="hostadmindata" id="hostadmindata">
                                            <select name="host_building_id" id="hostbuildingsid" class="form-control">
                                                <option value="">Select a building</option>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <select name="hostbuildingadmins[]" id="hostbuildingadminids" class="form-control" multiple="multiple"></select>
                                    </div>
                                </fieldset>
                            </div>

                            <div role="tabpanel" class="tab-pane fade" id="creditcard">
                                <fieldset>
                                    <legend>Credit Card</legend>
                                    <div id="creditcard-container"></div>
                                </fieldset>
                                <button type="button" class="btn btn-primary pull-right" data-action="add" name="toggle_card_form">ADD CREDITCARD <i class="fa fa-plus"></i></button>
                            </div>
                        </div>
                    </div>
                    <hr style="clear:both"/>
                    <div class="text-left">
                        {!! Form::hidden('id', null, ['id' => 'hostID']) !!}
                        <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

@stop
