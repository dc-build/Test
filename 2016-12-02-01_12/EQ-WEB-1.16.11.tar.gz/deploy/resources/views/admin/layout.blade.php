<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Lendlease">
    <meta name="author" content="Digital Carpenter Pty Ltd">
    <meta name="_token" content="{{ Session::token() }}">

    <title>@yield('title', 'Dashboard')</title>
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}" type="image/x-icon"/>
    <link rel="icon" href="{{ asset('favicon.ico') }}" type="image/x-icon"/>

    @yield('custom-css-before')

            <!-- build:css(public) /css/admin.min.css -->
    <!-- bower:css -->
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-select/dist/css/bootstrap-select.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/fullcalendar/dist/fullcalendar.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-css-only/css/bootstrap.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/AdminLTE/dist/css/AdminLTE.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/datatables.net-bs/css/dataTables.bootstrap.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/datatables.net-responsive-bs/css/responsive.bootstrap.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-toggle/css/bootstrap-toggle.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/ion.rangeSlider/css/ion.rangeSlider.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/ion.rangeSlider/css/ion.rangeSlider.skinFlat.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/related-selects/css/related-selects.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-combobox-blur/css/bootstrap-combobox.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap3-dialog/dist/css/bootstrap-dialog.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/multiselect/css/multi-select.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/lightbox2/dist/css/lightbox.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/jt.timepicker/jquery.timepicker.css') }}" />
    <!-- endbower -->
    <link rel="stylesheet" href="{{ asset('/bower_components/jquery-ui/themes/base/jquery-ui.min.css') }}">
    <link rel="stylesheet" href="{{ asset('/js/vendor/file_upload/fileupload.css') }}">
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}" type='text/css'>
    <link rel="stylesheet" href="{{ asset('/bower_components/AdminLTE/dist/css/skins/_all-skins.min.css') }}"/>
    <!-- endbuild -->

    @yield('custom-css')

</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- CONTENT -->
<div id="wrapper">
    <header class="main-header">
        <!-- Logo -->
        <a href="{{ route('admin.home') }}" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini">E</span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b>Equiem Dashboard</b></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>

            <div class="navbar-custom-menu">
                <ul class="nav navbar-nav">


                    <!-- User Account: style can be found in dropdown.less -->
                    <li class="dropdown user user-menu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="{{ asset('images/missing_profile.png') }}" class="user-image" alt="User Image">
                            <span class="hidden-xs">{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}</span>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- User image -->
                            <li class="user-header">
                                <img src="{{ asset('images/missing_profile.png') }}" class="img-circle" alt="User Image">

                                <p>
                                    {{ Auth::user()->first_name }} {{ Auth::user()->last_name }}
                                </p>
                            </li>

                            <!-- Menu Footer-->
                            <li class="user-footer">
                                <div class="pull-left">
                                    <a href="#" class="btn btn-default btn-flat">Profile</a>
                                </div>
                                <div class="pull-right">
                                    <a href="{{ route('logout') }}" class="btn btn-default btn-flat">Sign out</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar" style="height: auto;">
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu">
                <li class="header">MAIN NAVIGATION</li>

                <li class="{{ set_active(['admin.home']) }}">
                    <a href="{{ route('admin.home') }}"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                </li>

                @can('calendar', 'App\Http\Controllers\CalendarController')
                <li class="{{ set_active(['admin.calendar']) }}">
                    <a href="{{ route('admin.calendar') }}"><i class="fa fa-calendar"></i> <span>Calendar</span></a>
                </li>
                @endcan

                @can('buildings', 'App\Http\Controllers\BuildingController')
                <li class="treeview {{ set_active(['admin.buildings','admin.localities','admin.floors']) }}">
                    <a href="#">
                        <i class="fa fa-map-marker"></i>
                        <span>Locations</span>
                        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
                    </a>
                    <ul class="treeview-menu">
                        @can('buildings', 'App\Http\Controllers\BuildingController')
                        <li class="{{ set_active(['admin.buildings']) }}">
                            <a href="{{ route('admin.buildings') }}"><i class="fa fa-circle-o fa-fw"></i><span>Buildings</span></a>
                        </li>
                        @endcan

                        @can('floors', 'App\Http\Controllers\FloorController')
                        <li class="{{ set_active(['admin.floors']) }}">
                            <a href="{{ route('admin.floors') }}"><i class="fa fa-circle-o fa-fw"></i><span>Floors</span></a>
                        </li>
                        @endcan

                        @can('localities', 'App\Http\Controllers\LocalityController')
                        <li>
                            <a href="{{ route('admin.localities') }}"><i class="fa fa-circle-o fa-fw"></i> Localities</a>
                        </li>
                        @endcan
                    </ul>
                </li>
                @endcan

                @can('hosts', 'App\Http\Controllers\HostController')
                <li class="{{ set_active(['admin.hosts']) }}">
                    <a href="{{ route('admin.hosts') }}"><i class="fa fa-black-tie"></i> <span>Hosts</span></a>
                </li>
                @endcan

                <li class="treeview {{ set_active(['admin.space*']) }}">
                    <a href="#">
                        <i class="fa fa-th"></i>
                        <span>Spaces</span>
                        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
                    </a>
                    <ul class="treeview-menu">
                        @can('spaces', 'App\Http\Controllers\SpaceController')
                        <li class="{{ set_active(['admin.spaces']) }}">
                            <a href="{{ route('admin.spaces') }}"><i class="fa fa-circle-o fa-fw"></i><span>Spaces</span></a>
                        </li>
                        @endcan

                        @can('spacebookings', 'App\Http\Controllers\SpacebookingController')
                        <li class="{{ set_active(['admin.spacebookings']) }}">
                            <a href="{{ route('admin.spacebookings') }}"><i class="fa fa-circle-o fa-fw"></i><span>Bookings</span></a>
                        </li>
                        @endcan

                        @can('spacetypes', 'App\Http\Controllers\SpacetypeController')
                        <li class="{{ set_active(['admin.spacetypes']) }}">
                            <a href="{{ route('admin.spacetypes') }}"><i class="fa fa-circle-o fa-fw"></i><span>Types</span></a>
                        </li>
                        @endcan

                        @can('spaceuses', 'App\Http\Controllers\SpaceuseController')
                        <li class="{{ set_active(['admin.spaceuses']) }}">
                            <a href="{{ route('admin.spaceuses') }}"><i class="fa fa-circle-o fa-fw"></i><span>Uses</span></a>
                        </li>
                        @endcan

                        @can('spacefacilities', 'App\Http\Controllers\SpacefacilityController')
                        <li class="{{ set_active(['admin.spacefacilities']) }}">
                            <a href="{{ route('admin.spacefacilities') }}"><i class="fa fa-circle-o fa-fw"></i><span>Facilities</span></a>
                        </li>
                        @endcan

                        @can('spaceconfigurations', 'App\Http\Controllers\SpaceconfigurationController')
                        <li class="{{ set_active(['admin.spaceconfigurations']) }}">
                            <a href="{{ route('admin.spaceconfigurations') }}"><i class="fa fa-circle-o fa-fw"></i><span>Configurations</span></a>
                        </li>
                        @endcan
                    </ul>
                </li>

                @can('transactions', 'App\Http\Controllers\TransactionController')
                <li class="treeview {{ set_active(['admin.transactions','admin.cards']) }}">
                    <a href="#">
                        <i class="fa fa-credit-card"></i>
                        <span>Payments</span>
                        <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
                    </a>

                    <ul class="treeview-menu">
                        @can('transactions', 'App\Http\Controllers\TransactionController')
                        <li class="{{ set_active(['admin.transactions']) }}">
                            <a href="{{ route('admin.transactions') }}"><i class="fa fa-circle-o fa-fw"></i><span>Transactions</span></a>
                        </li>
                        @endcan

                        @can('cards', 'App\Http\Controllers\CardController')
                        <li class="{{ set_active(['admin.cards']) }}">
                            <a href="{{ route('admin.cards') }}"><i class="fa fa-circle-o fa-fw"></i> <span>Cards</span></a>
                        </li>
                        @endcan
                    </ul>
                </li>
                @endcan

                @can('users', 'App\Http\Controllers\UserController')
                <li>
                    <a href="{{ route('admin.users') }}"><i class="fa fa-user"></i> <span>Users</span></a>
                </li>
                @endcan

                @can('roles', 'App\Http\Controllers\RoleController')
                <li>
                    <a href="{{ route('admin.roles') }}"><i class="fa fa-users"></i> <span>Roles</span></a>
                </li>
                @endcan

                @can('imagetypes', 'App\Http\Controllers\ImagetypeController')
                <li>
                    <a href="{{ route('admin.imagetypes') }}"><i class="fa fa-file-image-o"></i><span>Image Types</span></a>
                </li>
                @endcan

                @can('blacklistdates', 'App\Http\Controllers\BlacklistdateController')
                <li>
                    <a href="{{ route('admin.blacklistdates') }}"><i class="fa fa-calendar-times-o"></i><span>Blacklist</span></a>
                </li>
                @endcan

                @can('whitelistdates', 'App\Http\Controllers\WhitelistdateController')
                <li>
                    <a href="{{ route('admin.whitelistdates') }}"><i class="fa fa-calendar-check-o"></i><span>Whitelist</span></a>
                </li>
                @endcan

            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>

    @yield('content')

</div>

<script>
    var AdminLTEOptions = {
        enableBSToppltip: false
    };
</script>

<!-- build:js(public) /js/app.admin.min.js -->
<!-- bower:js -->
<script src="{{ asset('/bower_components/jquery/dist/jquery.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrap/dist/js/bootstrap.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrap-select/dist/js/bootstrap-select.js') }}"></script>
<script src="{{ asset('/bower_components/underscore/underscore.js') }}"></script>
<script src="{{ asset('/bower_components/underscore.string/dist/underscore.string.js') }}"></script>
<script src="{{ asset('/bower_components/sprintf/src/sprintf.js') }}"></script>
<script src="{{ asset('/bower_components/moment/moment.js') }}"></script>
<script src="{{ asset('/bower_components/fullcalendar/dist/fullcalendar.js') }}"></script>
<script src="{{ asset('/bower_components/jquery-ui/jquery-ui.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrap3-ie10-viewport-bug-workaround/ie10-viewport-bug-workaround.js') }}"></script>
<script src="{{ asset('/bower_components/AdminLTE/dist/js/app.js') }}"></script>
<script src="{{ asset('/bower_components/datatables.net/js/jquery.dataTables.js') }}"></script>
<script src="{{ asset('/bower_components/datatables.net-responsive/js/dataTables.responsive.js') }}"></script>
<script src="{{ asset('/bower_components/datatables.net-bs/js/dataTables.bootstrap.js') }}"></script>
<script src="{{ asset('/bower_components/datatables.net-responsive-bs/js/responsive.bootstrap.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrapck4-skin/ckeditor.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrap-toggle/js/bootstrap-toggle.min.js') }}"></script>
<script src="{{ asset('/bower_components/ion.rangeSlider/js/ion.rangeSlider.js') }}"></script>
<script src="{{ asset('/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrap-validator/dist/validator.js') }}"></script>
<script src="{{ asset('/bower_components/related-selects/js/related-selects.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrap-combobox-blur/js/bootstrap-combobox.js') }}"></script>
<script src="{{ asset('/bower_components/bootstrap3-dialog/dist/js/bootstrap-dialog.min.js') }}"></script>
<script src="{{ asset('/bower_components/multiselect/js/jquery.multi-select.js') }}"></script>
<script src="{{ asset('/bower_components/js-cookie/src/js.cookie.js') }}"></script>
<script src="{{ asset('/bower_components/js-storage/js.storage.js') }}"></script>
<script src="{{ asset('/bower_components/lightbox2/dist/js/lightbox.js') }}"></script>
<script src="{{ asset('/bower_components/jt.timepicker/jquery.timepicker.js') }}"></script>
<!-- endbower -->
<script src="{{ asset('/js/vendor/file_upload/fileupload.js') }}"></script>
<script src="{{ asset('/js/vendor/dc/generateCalendar.js') }}"></script>
<script src="{{ asset('/js/vendor/dc/fsm.js') }}"></script>
<script src="{{ asset('/js/vendor/dc/utils.js') }}"></script>
<script src="{{ asset('/js/vendor/dc/template.js') }}"></script>
<script src="{{ asset('/js/vendor/dc/add_form_elements.js') }}"></script>
<!-- endbuild -->

<script>
    $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
        $('[rel="tooltip"]').tooltip();
    });
</script>

@yield('custom-scripts')
</body>
</html>
