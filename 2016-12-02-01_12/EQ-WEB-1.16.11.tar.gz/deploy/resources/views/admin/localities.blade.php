@extends('admin.layout')

@section('title')
    Localities
@stop

@section('custom-css')
@stop

@section('custom-scripts')
    <script>
        $(document).ready(function () {
            $(".data-table").DataTable({
                "language" : {
                    "emptyTable" : "NO LOCALITIES FOUND."
                },
                "ajax" : "/api/localities",
                "columns" : [
                    { "data" : "id" },
                    { "data" : "region.country.nicename" },
                    { "data" : "region.name" },
                    { "data" : "name" },
                    { "data" : "region.country.iso3" },
                    { "data" : "region.country.iso_code" },
                    { "data" : "region.country.numcode" },
                    { "data" : "region.country.phonecode" },
                    { "data" : "timezone" },
                    {
                        "data": "created_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "createdby",
                        "render": function (data) {
                            if (data) {
                                return data.full_name;
                            }
                        }
                    },
                    {
                        "data": "updated_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "updatedby",
                        "render": function (data) {
                            if (data) {
                                return data.full_name;
                            }
                        }
                    },
                    {
                        "className" : "text-right",
                        "width" : '225',
                        "data" : "dummy",
                        "orderable" : false,
                        "render" : function (data, type, row, meta) {
                            return '<a class="btn btn-danger" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Delete Locality" data-action="delete" data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;' +
                                '<a  class="btn btn-primary" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Edit Locality" data-action="edit" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                        }
                    }
                ],
                deferRender: true,
                paging: true,
                responsive: true
            });

            $("#modalForm").fsm({
                modalId: '#formModal',
                useBootstrapValidator: true,
                showErrorSummary: true,
                addApiUrl: '/api/localities',
                editApiUrl: '/api/localities/',
                deleteApiUrl: '/api/localities/',
                onPreSubmitHook: function(e) {
                    $('#formSubmit').innerHTML = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>';
                },
                onAddHook: function() {
                    $('#modal-title').text('Add Locality');
                    $('#region-country_id').trigger('related.needs_update');
                },
                onPrePopulateHook: function() {
                },
                onEditHook: function(data) {
                    $('#modal-title').text('Edit Locality');
                    $('#region-country_id').trigger('related.needs_update');
                },
                onDeleteHook: function() {
                    $('#modal-title').text('Delete Locality');
                    return true;
                },
                onHideModalHook: function() {
                    // Reload the grid
                    $('.data-table').DataTable().ajax.reload();
                }
            });


            $('#region-country_id').relatedSelect({url: '/api/countries', child: '#region_id'});
            $('#region_id').relatedSelect({
                url: '/api/countries/{country_id}/regions',
                urlParser: function (baseUrl, countryId) {
                    return countryId ? baseUrl.replace('{country_id}', countryId) : '';
                },
                loaded: function(select) {
                    select.combobox('refresh');
                }
            }).combobox({acceptsNewValue: true});

        });
    </script>
@stop

@section('content')


    <div class="content-wrapper">
        <section class="content-header">
            <h1>Localities
                <button type="button" class="pull-right btn btn-primary" data-title="Add Locality" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New Locality</button>
            </h1>
        </section>

        <section class="content">

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="data-table display table responsive stripe compact" width="100%">
                                <thead>
                                <tr>
                                    <th class="all">ID</th>
                                    <th class="all">Country</th>
                                    <th class="all">Region</th>
                                    <th class="all">Locality</th>
                                    <th class="none">Country ISO3</th>
                                    <th class="none">Country ISO Code</th>
                                    <th class="none">Country Number</th>
                                    <th class="none">Country Phone prefix</th>
                                    <th class="none">Timezone</th>
                                    <th class="none">Date Created</th>
                                    <th class="none">Created by</th>
                                    <th class="all">Date Updated</th>
                                    <th class="all">Updated by</th>
                                    <th class="all text-right">Action</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>

    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light collapse"></div>
                    <div class="alert alert-danger alert-light collapse"></div>
                    <hr/>
                    {!! Form::open(['route' => ['api.localities.create', 'id' => ''], 'method' => '', 'id' => 'modalForm', 'class' => 'modalForm']) !!}
                    <input type="hidden" name="_method" value="">
                    <div id="deleteMessage" class="hidden">
                        <p class="text-center" id="confirmation"></p>
                        <p class="text-center" id="details"></p>
                    </div>
                    <div id="formContainer">
                        <div class="form-group has-feedback">
                            <label for="region-country_id" class="control-label">Country <i class="fa fa-asterisk text-danger"></i></label>
                            {!! Form::select('region.country_id', [], null, ['id' => 'region-country_id', 'placeholder' => 'Select a Country', 'class' => 'form-control', 'required' => 'required']) !!}
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group has-feedback">
                            <label for="region_id" class="control-label">Region <i class="fa fa-asterisk text-danger"></i></label>
                            {!! Form::select('region_id', [], null, ['id' => 'region_id', 'placeholder' => '- Select or enter a new Region -', 'class' => 'form-control', 'required' => 'required']) !!}
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group has-feedback">
                            <label for="name" class="control-label">Locality <i class="fa fa-asterisk text-danger"></i></label>
                            {!! Form::text('name', null, ['id' => 'name', 'placeholder' => 'Town, Suburb or City', 'class' => 'form-control', 'required' => 'required']) !!}
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group has-feedback">
                            <label for="timezone" class="control-label">Timezone <i class="fa fa-asterisk text-danger"></i></label>
                            {!! Form::select('timezone', array_combine(timezone_identifiers_list(), timezone_identifiers_list()), null, ['id' => 'timezone', 'placeholder' => '- Select a Timezone -', 'class' => 'form-control', 'required' => 'required']) !!}
                            <div class="help-block with-errors"></div>
                        </div>

                    </div>
                    <hr style="clear:both"/>
                    <div class="text-left">
                        {!! Form::hidden('id', null, ['id' => 'localityID']) !!}
                        <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

@stop
