@extends('admin.layout')

@section('title')
    Roles
@stop

@section('custom-scripts')
    <script>
        $(document).ready(function() {
            $(".roles-table").DataTable({
                "language": {
                    "emptyTable": "NO ROLES FOUND."
                },
                "ajax" : "/api/roles",
                "columns": [
                    { "data": "id" },
                    { "data": "name"},
                    { "data": "created_at" },
                    { "data": "updated_at" },
                    {
                        "className": "text-right",
                        "width" : '225',
                        "data": "dummy",
                        "orderable": false,
                        "render": function(data, type, row, meta) {
                            return '<a class="btn btn-danger" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Delete Role" data-action="delete" data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;' +
                                '<a  class="btn btn-primary" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Edit Role" data-action="edit" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                        }
                    }
                ],
                "deferRender" : true,
                "paging" : true,
                "responsive" : true
            });
            
            $('.alert').hide();
            
            var form = $('form.modalForm'), submitButton = form.find(":submit");

            form.submit(function(e) {
                e.preventDefault();
                submitButton.attr({disabled: true});
                document.getElementById('formSubmit').innerHTML = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>';
                $.ajax({
                    url : $(this).attr('action') || window.location.pathname,
                    type: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function (data) {
                        if (data.status == "success") {
                            $(".alert-danger").hide();
                            $(".alert-success").show();
                            $(".alert-success").text(data.message);
                            $('#displayForm').hide();
                        }
                        else {
                            $(".alert-success").hide();
                            $(".alert-danger").show();
                            $(".alert-danger").text("");
                            $.each(data.message, function(index, value){
                                $(".alert-danger").append(value + "<br />");
                            }); 
                        }
                        submitButton.attr({disabled: false});
                        document.getElementById('formSubmit').innerHTML = 'Submit';
                    },
                    error: function () {
                        submitButton.attr({disabled: false});
                        $(".alert-success").hide();
                        $(".alert-danger").show();
                        $(".alert-danger").html("One or more required fields were missing or invalid. Please try again.");
                        document.getElementById('formSubmit').innerHTML = 'Submit';
                    }
                });
            });
            
            $('#formModal').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget);
                var id = button.data('id');
                var title = button.data('title');
                var action = button.data('action');
                var name = button.data('name');
                var modal = $(this);
                modal.find('.modal-body #modal-title').text(title);
                modal.find('.modal-body #displayForm').show();
                modal.find('.modal-body #deleteMessage').hide();
                
                if (action == "add") {
                    $("#modalForm").trigger( "reset" );
                    modal.find('.modal-body #modalForm').attr('action', '/api/roles');
                    modal.find('.modal-body #modalForm').attr('method', 'POST');
                    modal.find('.modal-body #getMethod').html('');
                }
                if (action == "edit") {
                    $.getJSON("/api/roles/"+id, function( json ) {
                        modal.find('.modal-body #name').val(json.name);
                        modal.find('.modal-body #roleID').val(json.id);
                    });
                    modal.find('.modal-body #modalForm').attr('action', '/api/roles/'+id);
                    modal.find('.modal-body #modalForm').attr('method', 'POST');
                    modal.find('.modal-body #getMethod').html('<input name="_method" type="hidden" value="PUT">');
                }
                if (action == "delete") {
                    modal.find('.modal-body #displayForm').hide();
                    modal.find('.modal-body #deleteMessage').show();
                    modal.find('.modal-body #confirmation').text("Are you sure you want to delete this role?");
                    modal.find('.modal-body #details').text(name + " (ID: "+ id +")");
                    modal.find('.modal-body #modalForm').attr('action', '/api/roles/'+id);
                    modal.find('.modal-body #modalForm').attr('method', 'POST');
                    modal.find('.modal-body #getMethod').html('<input name="_method" type="hidden" value="DELETE">');
                }
            });
            
            $('#formModal').on('hidden.bs.modal', function (event) {
                if ($("#formModal .alert-success").text()!="") {
                    $('.roles-table').DataTable().ajax.reload();
                }
                $("#formModal .alert-success").hide();
                $("#formModal .alert-danger").hide();
            });
        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Roles <button type="button" class="pull-right btn btn-primary" data-title="Add Role" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New Role</button></h1>
        </section>

        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="roles-table display table responsive stripe compact" width="100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Date Created</th>
                                        <th>Date Updated</th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
        </section>
    </div>

    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light"></div>
                    <div class="alert alert-danger alert-light"></div>
                    <hr />
                    {!! Form::open(['route' => ['api.roles.create', 'id' => ''], 'method' => '', 'id' => 'modalForm', 'class' => 'modalForm']) !!}
                        <span id="getMethod"></span>
                        <div id="deleteMessage">
                            <p class="text-center" id="confirmation"></p>
                            <p class="text-center" id="details"></p>
                        </div>
                        <div id="displayForm">
                            <div class="form-group {{ ($errors->has('name')) ? 'has-error' : '' }}">
                                {!! Form::label('name', 'Name', ['class' => 'control-label']) !!}
                                {!! Form::text('name', null, ['id' => 'name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('name') ? $errors->first('name') : '') }}</span>
                            </div>
                            <hr style="clear:both" />
                        </div>
                        <div class="text-left">
                            {!! Form::hidden('id', null, ['id' => 'roleID']) !!}
                            <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                            <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                        </div>
                    {!! Form::close() !!} 
                </div>
            </div>
        </div>
    </div>

@stop
