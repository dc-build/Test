@extends('admin.layout')
@include('admin._partials.calendar_view')

@section('title')
    Space Bookings
@stop

@section('custom-scripts')
    
    <script>
        function CKupdate(){
            for ( instance in CKEDITOR.instances )
                CKEDITOR.instances[instance].updateElement();
        }
        
        $(document).ready(function () {
            $(".data-table").DataTable({
                "language": {
                    "emptyTable": "NO SPACE BOOKINGS FOUND."
                },
                "ajax": "/api/spacebookings",
                "columns": [
                    { "data": "id"},
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.spaces && row.spaces.room_name && row.spaces.id) {
                                return Object.escapeHtml(row.spaces.room_name) + " (ID "+row.spaces.id+")";
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.users && row.users.email && row.users.id) {
                                return Object.escapeHtml(row.users.email) + " (ID "+row.users.id+")";
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { "data": "company_name"},
                    { "data": "company_address" },
                    { "data": "event_title" },
                    { "data": "num_attendees" },
                    { "data": "start_datetime" },
                    { "data": "end_datetime" },
                    {  
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.spaceconfigurations && row.spaceconfigurations.name && row.spaceconfigurations.id) {
                                return Object.escapeHtml(row.spaceconfigurations.name) +" (ID "+row.spaceconfigurations.id+")";
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { "data": "total_price" },
                    { "data": "rate_hour" },
                    { "data": "rate_halfday" },
                    { "data": "rate_day" },
                    { "data": "rate_month" },
                    { "data": "rate_afterhours" },
                    { "data": "booking_type" },
                    { "data": "payment_type" },
                    { "data": "payment_received" },
                    {
                        "className": "text-right",
                        "width": '225',
                        "data": "dummy",
                        "orderable": false,
                        "render": function (data, type, row, meta) {
                            return '<a  class="btn btn-primary" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Edit Space Booking" data-action="edit" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                        }
                    }
                ],
                "deferRender": true,
                "paging": true,
                "responsive": true
            });
            
            $("#viewCalendar").click(function() {
                $("[id=toggleCalendar]").toggle();
                function displayCalendar(route) {
                    $('#calendar').generateCalendar({
                        events_route : route,
                        height : '400',
                        events_backgroundColor : '#dddddd',
                        events_textColor : '#000000',
                        eventLimit : false
                    });
                }

                var default_route = "{{ route('calendar.spacebookings') }}";
                displayCalendar(default_route);

                $("#calendar_space_id").change(function() {
                    var space_id = $(this).val();
                    if (space_id) {
                        var new_route = default_route+"/"+space_id;
                        displayCalendar(new_route);
                        console.log(new_route);
                    }
                    else {
                        displayCalendar(default_route);
                        console.log(default_route);
                    }
                });
            });
            
            $("[id=toggleCalendar]").hide();
            $('.alert').hide();

            var form = $('form.modalForm');
            var submitButton = form.find(":submit");
            var successContainer = $('.alert.alert-success');
            var dangerContainer = $('.alert.alert-danger');
            var formContainer = $('#formContainer');
            var deleteMessageContainer = $('#deleteMessage');

            // Prevent submitting the form from within an input (required to stop submission after the form has already been submitted)
            $('#modalForm input:text, #modalForm textarea').on('keydown', function (event) {
                if (event.which == 13) {
                    event.preventDefault();
                }
            });

            form.submit(function (e) {
                CKupdate();
                e.preventDefault();
                submitButton.attr({disabled: true});
                submitButton.html('<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>');
                $.ajax({
                    url: $(this).attr('action') || window.location.pathname,
                    type: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function (data) {
                        if (data.status == "success") {
                            dangerContainer.hide();
                            successContainer.text(data.message).show();
                            formContainer.hide();
                            deleteMessageContainer.hide();
                            submitButton.hide();
                        }
                        else {
                            successContainer.hide();
                            if (typeof data.message == 'string') {
                                dangerContainer.text(data.message).show();
                            } else {
                                dangerContainer.text('').show();
                                $.each(data.message, function (index, value) {
                                    dangerContainer.append(value + "<br />");
                                });
                            }
                            submitButton.html('Submit').attr({disabled: false}).show();
                        }
                    },
                    error: function (data) {
                        successContainer.hide();
                        dangerContainer.html(data.responseJSON.message).show();
                        submitButton.html('Submit').attr({disabled: false}).show();
                    }
                });
            });

            $('#formModal').on('show.bs.modal', function (event) {
                $('#formContainer').css('overflow-y', 'auto'); 
                $('#formContainer').css('max-height', $(window).height() * 0.65);
                
                submitButton.html('Submit').attr({disabled: false}).show();
                var button = $(event.relatedTarget);
                var id = button.data('id');
                var title = button.data('title');
                var action = button.data('action');
                var name = button.data('name');
                var modal = $(this);
                $('#modal-title').text(title);
                formContainer.show();
                deleteMessageContainer.hide();

                if (action == "add") {
                    $("#modalForm").trigger("reset").attr('action', '/api/spacebookings');
                    $('#getMethod').html('');
                }
                if (action == "edit") {
                    $.getJSON("/api/spacebookings/" + id, function (json) {
                        for (var item in json) {
                            var input = $('#' + item);
                            if (typeof item != 'undefined') {
                                $(input).val(json[item]);
                            }
                        }
                        $('#imagetypeID').val(json.id);
                    });
                    $('#modalForm').attr('action', '/api/spacebookings/' + id);
                    $('#getMethod').html('<input name="_method" type="hidden" value="PUT">');
                }
                if (action == "delete") {
                    formContainer.hide();
                    deleteMessageContainer.show();
                    $('#confirmation').text("Are you sure you want to delete this space booking?");
                    $('#details').text(name + " (ID: " + id + ")");
                    form.attr('action', '/api/spacebookings/' + id);
                    $('#getMethod').html('<input name="_method" type="hidden" value="DELETE">');
                }
            }).on('hidden.bs.modal', function (event) {
                if (successContainer.text() != "") {
                    $('.data-table').DataTable().ajax.reload();
                }
                successContainer.hide();
                dangerContainer.hide();
            });
        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Space Bookings <span class="pull-right"><button type="button" class="btn btn-success" id="viewCalendar"><i class="fa fa-calendar" aria-hidden="true"></i></button> <button type="button" class="btn btn-primary" data-title="Add Space Booking" data-action="add" data-toggle="modal" id="addButton">New Space Booking</button></span></h1>
        </section>
        
        <div id="toggleCalendar">
            <section class="content">
                @yield('calendar-section')
            </section>
        </div>
        
        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="data-table display table responsive stripe compact" width="100%">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Space</th>
                                    <th>Booked By</th>
                                    <th>Company Name</th>
                                    <th class="none">Company Address</th>
                                    <th>Event Title</th>
                                    <th>Number of Attendees</th>
                                    <th>Start DateTime</th>
                                    <th>End DateTime</th>
                                    <th>Configuration</th>
                                    <th class="none">Total Price</th>
                                    <th class="none">Hourly rate</th>
                                    <th class="none">Halfday rate</th>
                                    <th class="none">Daily Rate</th>
                                    <th class="none">Monthly Rate</th>
                                    <th class="none">After Hours Rate</th>
                                    <th class="none">Booking Type</th>
                                    <th class="none">Payment Type</th>
                                    <th class="none">Payment Received</th>
                                    <th class="text-right">Action</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>

    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light"></div>
                    <div class="alert alert-danger alert-light"></div>
                    <hr/>
                    {!! Form::open(['route' => ['api.spacebookings.create', 'id' => ''], 'method' => 'POST', 'id' => 'modalForm', 'class' => 'modalForm']) !!}
                    <span id="getMethod"></span>
                    <div id="deleteMessage">
                        <p class="text-center" id="confirmation"></p>
                        <p class="text-center" id="details"></p>
                    </div>
                    <div id="formContainer">
                        <div class="col-md-6">
                            <div class="form-group {{ ($errors->has('contact_name')) ? 'has-error' : '' }}">
                                {!! Form::label('contact_name', 'Contact Name', ['class' => 'control-label']) !!}
                                {!! Form::text('contact_name', null, ['id' => 'contact_name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('contact_name') ? $errors->first('contact_name') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('company_name')) ? 'has-error' : '' }}">
                                {!! Form::label('company_name', 'Company Name', ['class' => 'control-label']) !!}
                                {!! Form::text('company_name', null, ['id' => 'company_name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('company_name') ? $errors->first('company_name') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('company_address')) ? 'has-error' : '' }}">
                                {!! Form::label('company_address', 'Company Address', ['class' => 'control-label']) !!}
                                {!! Form::text('company_address', null, ['id' => 'company_address', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('company_address') ? $errors->first('company_address') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('company_city')) ? 'has-error' : '' }}">
                                {!! Form::label('company_city', 'City', ['class' => 'control-label']) !!}
                                {!! Form::text('company_city', null, ['id' => 'company_city', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('company_city') ? $errors->first('company_city') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('company_state')) ? 'has-error' : '' }}">
                                {!! Form::label('company_state', 'State', ['class' => 'control-label']) !!}
                                {!! Form::text('company_state', null, ['id' => 'company_state', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('company_state') ? $errors->first('company_state') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('company_country')) ? 'has-error' : '' }}">
                                {!! Form::label('company_country', 'Country', ['class' => 'control-label']) !!}
                                {!! Form::text('company_country', null, ['id' => 'company_country', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('company_country') ? $errors->first('company_country') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('company_postcode')) ? 'has-error' : '' }}">
                                {!! Form::label('company_postcode', 'Post Code', ['class' => 'control-label']) !!}
                                {!! Form::text('company_postcode', null, ['id' => 'company_postcode', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('company_postcode') ? $errors->first('company_postcode') : '') }}</span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group {{ ($errors->has('event_title')) ? 'has-error' : '' }}">
                                {!! Form::label('event_title', 'Event Title', ['class' => 'control-label']) !!}
                                {!! Form::text('event_title', null, ['id' => 'event_title', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('event_title') ? $errors->first('event_title') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('event_description')) ? 'has-error' : '' }}">
                                {!! Form::label('event_description', 'Event Description', ['class' => 'control-label']) !!}
                                {!! Form::textarea('event_description', null, ['id' => 'event_description', 'placeholder' => '', 'class' => 'form-control', 'rows' => '8']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('event_description') ? $errors->first('event_description') : '') }}</span>
                            </div>
                            <div class="form-group {{ ($errors->has('num_attendees')) ? 'has-error' : '' }}">
                                {!! Form::label('num_attendees', 'Number of Attendees', ['class' => 'control-label']) !!}
                                {!! Form::text('', null, ['id' => 'num_attendees', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                <span class='label label-danger text-center'>{{ ($errors->has('num_attendees') ? $errors->first('num_attendees') : '') }}</span>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('start_datetime')) ? 'has-error' : '' }}">
                                        {!! Form::label('start_datetime', 'Start DateTime', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'start_datetime', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('start_datetime') ? $errors->first('start_datetime') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('end_datetime')) ? 'has-error' : '' }}">
                                        {!! Form::label('end_datetime', 'End DateTime', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'end_datetime', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('end_datetime') ? $errors->first('end_datetime') : '') }}</span>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-xs-12">
                            <hr />
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('total_price')) ? 'has-error' : '' }}">
                                        {!! Form::label('total_price', 'Total Price', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'total_price', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('total_price') ? $errors->first('total_price') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('rate_hour')) ? 'has-error' : '' }}">
                                        {!! Form::label('rate_hour', 'Hourly Rate', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'rate_hour', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('rate_hour') ? $errors->first('rate_hour') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('rate_halfday')) ? 'has-error' : '' }}">
                                        {!! Form::label('rate_halfday', 'Halfday rate', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'rate_halfday', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('rate_halfday') ? $errors->first('rate_halfday') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('rate_day')) ? 'has-error' : '' }}">
                                        {!! Form::label('rate_day', 'Daily Rate', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'rate_day', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('rate_day') ? $errors->first('rate_day') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('rate_month')) ? 'has-error' : '' }}">
                                        {!! Form::label('rate_month', 'Monthly Rate', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'rate_month', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('rate_month') ? $errors->first('rate_month') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group {{ ($errors->has('rate_afterhours')) ? 'has-error' : '' }}">
                                        {!! Form::label('rate_afterhours', 'After Hours Rate', ['class' => 'control-label']) !!}
                                        {!! Form::text('', null, ['id' => 'rate_afterhours', 'placeholder' => '', 'class' => 'form-control', 'disabled']) !!}
                                        <span class='label label-danger text-center'>{{ ($errors->has('rate_afterhours') ? $errors->first('rate_afterhours') : '') }}</span>
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group {{ ($errors->has('booking_type')) ? 'has-error' : '' }}">
                                        {!! Form::label('booking_type', 'Booking Type', ['class' => 'control-label']) !!}
                                        <select class="form-control" id="booking_type" name="" disabled>
                                            <option value="1">REQUEST</option>
                                            <option value="2">INSTANT</option>
                                        </select>
                                        <span class='label label-danger text-center'>{{ ($errors->has('booking_type') ? $errors->first('booking_type') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group {{ ($errors->has('payment_type')) ? 'has-error' : '' }}">
                                        {!! Form::label('payment_type', 'Payment Type', ['class' => 'control-label']) !!}
                                        <select class="form-control" id="payment_type" name="" disabled>
                                            <option value="INVOICE">INVOICE</option>
                                            <option value="CREDITCARD">CREDITCARD</option>
                                        </select>
                                        <span class='label label-danger text-center'>{{ ($errors->has('payment_type') ? $errors->first('payment_type') : '') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group {{ ($errors->has('payment_received')) ? 'has-error' : '' }}">
                                        {!! Form::label('payment_received', 'Payment Received', ['class' => 'control-label']) !!}
                                        <select class="form-control" id="payment_received" name="" disabled>
                                            <option value="1">YES</option>
                                            <option value="0">NO</option>
                                        </select>
                                        <span class='label label-danger text-center'>{{ ($errors->has('payment_received') ? $errors->first('payment_received') : '') }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <hr style="clear:both" />
                    <div class="text-left">
                        <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

@stop