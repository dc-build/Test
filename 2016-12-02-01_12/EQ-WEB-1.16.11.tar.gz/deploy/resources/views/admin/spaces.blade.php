@extends('admin.layout')

@section('title')
    Spaces
@stop

@section('custom-scripts')
    <script>
        $('#building_id').change(function() {
            loadFloors($(this).val());
            loadHosts($(this).val());
        });

        function createSlider(id, min, max, step, prefix, postfix, tbId) {
            $(id).ionRangeSlider({
                grid: true,
                min: min,
                max: max,
                from: min,
                step: step,
                prefix: prefix,
                postfix: postfix,
                prettify_enabled: true,
                onChange: function(data) {
                    $(tbId).val(data.from);
                }
            });
            var slider = $(id).data("ionRangeSlider");
            $(tbId).on("change", function() {
                slider.update({ from: $(this).val() });
            });
        }
        function ajaxDropDown($selector, apiUrl, selectMsg, itemFunc) {
            $.ajax({
                type: 'GET',
                url: apiUrl,
                data: {},
                async: false,
                success: function (data) {
                    if (data) {
                        data.unshift({ id: '', name: selectMsg});
                        $selector.empty();
                        $.each(data, function(i, item) {
                            if (itemFunc && $.isFunction(itemFunc)) {
                                itemFunc.call(this, i, item);
                            }
                        });
                    }
                },
                error: function () {}
            });
        }
        function loadBuildings() {
            ajaxDropDown($('#building_id'), '/api/buildings/list', 'Select Building',
                function(i, item) {
                    $('#building_id').append($('<option>', {
                        value: item.id,
                        text : item.name
                    }));
            });
        }
        function loadFloors(buildingId) {
            ajaxDropDown($('#floor_id'), '/api/buildings/' + buildingId + '/floors', 'Select Floor',
                function(i, item) {
                    $('#floor_id').append($('<option>', {
                        value: item.id,
                        text : item.name
                    }));
                }
            );
        }
        function loadHosts(buildingId) {
            ajaxDropDown($('#host_id'), '/api/buildings/' + buildingId + '/hosts', 'Select Host',
                function(i, item) {
                    console.log(item);
                    var text = '';
                    if (item.name) {
                        text = item.name;
                    }
                    else if (item.company_name) {
                        text = item.company_name;
                    }
                    else {
                        text = item.contact_name;
                    }
                    $('#host_id').append($('<option>', {
                        value: item.id,
                        text : text
                    }));
            });
        }

        $(function() {
            CKEDITOR.config.toolbar = [
                ['Styles','Format','Font','FontSize'],
                ['Bold','Italic','Underline','StrikeThrough','-','Undo','Redo','-','Cut','Copy','Paste','Find','Replace'],
                '/',
                ['NumberedList','BulletedList','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
                ['Image','Table','-','Link','Smiley','TextColor','BGColor','Source']
            ] ;

            CKEDITOR.replace("description");
            CKEDITOR.replace("terms");

            for ( instance in CKEDITOR.instances ) {
                var editor = CKEDITOR.instances[instance];
                editor.on('change', editor.updateElement);
            }


// DTT: Related still doesn't work quite right
//            $('#building_id').relatedSelect({url: '/api/buildings/lazy', child: '#floor_id'});
//            $('#floor_id').relatedSelect({
//                url: '/api/buildings/{building_id}/floors',
//                urlParser: function (baseUrl, buildingId) {
//                    if (buildingId && buildingId != "") {
//                        return baseUrl.replace('{building_id}', buildingId);
//                    }
//                    return "";
//                }
//            });
//            $('#host_id').relatedSelect({url: '/api/hosts/lazy'});


            $("#modalForm").fsm({
                modalId: '#formModal',
                isMultiPart: true,
                useBootstrapValidator: true,
                showErrorSummary: true,
                addApiUrl: '/api/spaces',
                editApiUrl: '/api/spaces/',
                deleteApiUrl: '/api/spaces/',
                onPreSubmitHook: function(e) {
                    $('#formSubmit').innerHTML = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>';
                },
                onAddHook: function() {
//                    $('#building_id').trigger('related.needs_update');
//                    $('#host_id').trigger('related.needs_update');
                    $('.nav-tabs a:first').tab('show');
                    loadBuildings();
                    $('#modal-title').text('Add Space');
                    $('#previewThumbnail').empty();
                    $('#previewExistingGallery').empty();
                    $('#previewGallery').empty();
                    $('button[name="activate"]').toggle(true);
                    $('button[name="deactivate"]').toggle(false);
                    capacitypricesTable.ajax.url('/api/spaces/_/capacityprices').load();
                    CKEDITOR.instances['description'].setData('');
                    CKEDITOR.instances['terms'].setData('');
                },
                onPrePopulateHook: function() {
//                    $('#building_id').trigger('related.needs_update');
//                    $('#host_id').trigger('related.needs_update');
                    loadBuildings();
                },
                onEditHook: function(data) {
                    $('.nav-tabs a:first').tab('show');
                    $('#modal-title').text('Edit Space');
                    CKEDITOR.instances['description'].setData(data.description);
                    CKEDITOR.instances['terms'].setData(data.terms);
                    $('#active').val(data.active).trigger('change');
                    $('#floor_id').val($('#floor_id').data('delayed_val'));
                    $('#floor_id').blur();
                    $('#host_id').val($('#host_id').data('delayed_val'));
                    $('#host_id').blur();

                    var active = data.active === 1 || data.active == 'true' || data.active === true;
                    $('button[name="activate"]').toggle(!active);
                    $('button[name="deactivate"]').toggle(active);

                    $('#activeStatus_active').toggle(active);
                    $('#activeStatus_inactive').toggle(!active);

                    if (data.thumb_image[0] && data.thumb_image[0].image_uuid) {
                        $('#previewThumbnail').empty().append(
                            $("<img class='img-responsive thumbnail' src='{{ asset('images/uploads') }}/"+data.thumb_image[0].image_uuid+"."+data.thumb_image[0].file_ext+"' />")
                        );
                    }
                    $('#previewExistingGallery').empty();
                    $('#previewGallery').empty();
                    $.each(data.gallery_images, function(idx, item) {
                        $('#previewExistingGallery').append(
                            $("<img class='img-responsive thumbnail' src='{{ asset('images/uploads') }}/" + item.image_uuid + "." + item.file_ext + "' />")
                        );
                    });

                    $('#spacetypes').val($.map(data.spacetypes, function (item) {
                        return item.id;
                    })).selectpicker('refresh');

                    $(':checkbox[name*="sharedfacilities"]').prop('checked', false);
                    $.each(data.sharedfacilities, function (idx, item) {
                        $('#sharedfacilities_' + item.id).prop('checked', 'checked');
                    });

                    $(':checkbox[name*="spacefeatures"]').prop('checked', false);
                    $.each(data.spacefeatures, function (idx, item) {
                        $('#spacefeatures_' + item.id).prop('checked', 'checked');
                    });

                    $('#deleted_capacityprices').val('');
                    capacitypricesTable.ajax.url('/api/spaces/' + data.id + '/capacityprices').load();
                },
                onDeleteHook: function() {
                    $('#modal-title').text('Delete Space');
                    $(':submit[name*="activate"]').hide();
                    return true;
                },
                onHideModalHook: function() {
                    // Reload the grid
                    $('.spaces-table').DataTable().ajax.reload();
                    capacitypricesTable.clear();
                },
                onSubmitSuccessHook: function() {
                    $('[name*="activate"]').hide();
                },
                onSubmitErrorHook: function() {
                    $('[name*="activate"]').hide();
                }

            });

            $(".spaces-table").DataTable({
                "language": {
                    "emptyTable": "NO SPACES FOUND."
                },
                "ajax" : "/api/spaces",
                "columns": [
                    { "data": "id" },
                    {
                        "orderable": false,
                        "className": "text-center",
                        "width" : '75',
                        "data": "active",
                        "render": function(data, type, row, meta) {
                            if (data) {
                                return '<i class="fa fa-check-circle fa-2x text-success"></i>';
                            }
                            else {
                                return '<i class="fa fa-times-circle fa-2x text-danger"></i>';
                            }
                        }
                    },
                    { "data": "room_number" },
                    { "data": "room_name" },
                    { "data": "host",
                        "render": function(data, type, row, meta){
                            return Object.escapeHtml(row.host.company_name);
                        }
                    },
                    { "data": "description" },
                    { "data": "booking_type" },
                    {
                        "className": "text-right",
                        "width" : '225',
                        "data": "dummy",
                        "orderable": false,
                        "render": function(data, type, row, meta) {
                            return '<a class="btn btn-danger btn-delete" data-id="' + row.id + '" data-title="Delete Space" data-action="delete" data-name="' + Object.escapeHtml(row.name) + '"  data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;' +
                                    '<a  class="btn btn-primary" data-id="' + row.id + '" data-title="Edit Space" data-action="edit" data-name="' + Object.escapeHtml(row.name) + '" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                        }
                    }
                ],
                "deferRender" : true,
                "paging" : true,
                "responsive" : true
            });

            createSlider("#day_duration_slider  ", 0, (24 * 60), 1, null, " min(s)", "#day_duration");
            createSlider("#month_duration_slider  ", 0, 31, 1, null, " day(s)", "#month_duration");
            createSlider("#after_hours_duration_slider  ", 0, (24 * 60), 1, null, " min(s)", "#after_hours_duration");
            createSlider("#rate_hour_slider", 0, 1000, 1, "$", null, "#rate_hour");
            createSlider("#rate_halfday_slider", 0, 1000, 1, "$", null, "#rate_halfday");
            createSlider("#rate_day_slider", 0, 1000, 1, "$", null, "#rate_day");
            createSlider("#rate_month_slider", 0, 100000, 100, "$", null, "#rate_month");
            createSlider("#rate_afterhours_slider", 0, 1000, 1, "$", null, "#rate_afterhours");
            createSlider("#cancellation_percent_slider", 0, 100, 1, null, " %", "#cancellation_percent");
            createSlider("#cancellation_hours_slider", 0, 100, 1, null, " min(s)", "#cancellation_hours");
            createSlider("#booking_window_min_slider", 0, 10000, 1, null, " min(s)", "#booking_window_min");
            createSlider("#booking_window_max_slider", 0, 600000, 1, null, " min(s)", "#booking_window_max");
            createSlider("#prep_time_before_slider", 0, 10000, 1, null, " min(s)", "#prep_time_before");
            createSlider("#prep_time_after_slider", 0, 10000, 1, null, " min(s)", "#prep_time_after");

            $('#day_start_time_input_group').datetimepicker({
                format: 'HH:mm:ss'
            });

            var toggleActivateSpace = function (evt) {
                var active = $(this).data('active');
                $('input[name="active"]').val(active ? 1 : 0);
                if (confirm("Are you sure you want to make this Space " + (active ? "" : "in") + "active?")) {
                    return;
                }
                evt.preventDefault();
            };

            $('button[name="activate"]').on('click', toggleActivateSpace);
            $('button[name="deactivate"]').on('click', toggleActivateSpace);

            /* Preview uploaded files on browse */
            function readURL(input, preview, value) {
                $(preview).html('');
                $.each(input.files, function(idx, item) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $(preview).append($('<img id="preview" class="img-responsive thumbnail" src="'+e.target.result+'" />'));
                    };
                    reader.readAsDataURL(item);
                });
            }

            $("#thumb_image").change(function(){
                readURL(this, "#previewThumbnail");
            });

            $("#gallery_images").change(function(){
                readURL(this, "#previewGallery");
            });

            var capacitypricesTable = $('.capacityprices-table').DataTable({
                "dom": '<"toolbar">lrtip',
                "language": {
                    "emptyTable": "NO CAPACITY PRICES FOR THIS SPACE"
                },
                "columns": [
                    { "data": "attendees_min",
                      "render": function (data, type, row, meta)
                        {
                            return data;
                        }},
                    { "data": "attendees_max" ,
                        "render": function (data, type, row, meta)
                        {
                            return data;
                        }},
                    { "data": "rate_hour" ,
                        "render": function (data, type, row, meta)
                        {
                            return data;
                        }},
                    { "data": "rate_halfday" ,
                        "render": function (data, type, row, meta)
                        {
                            return data;
                        }},
                    { "data": "rate_day" ,
                        "render": function (data, type, row, meta)
                        {
                            return data;
                        }},
                    { "data": "rate_month" ,
                        "render": function (data, type, row, meta)
                        {
                            return data;
                        }},
                    { "data": "rate_afterhours" ,
                        "render": function (data, type, row, meta)
                        {
                            return data;
                        }},
                    {
                        className: "text-right",
                        width: '100',
                        data: "dummy",
                        orderable: false,
                        render: function (data, type, row, meta)
                        {
                            return '<a class="btn btn-danger" data-id="' + row.id + '" data-title="Delete Space">Delete <i class="fa fa-eraser"></i></a>&nbsp;';
                        }
                    }
                ],
                "deferRender" : true,
                "paging" : true,
                "responsive" : true
            });

            var addCapacityPriceButton = $('<button id="add-capacityprice" class="pull-right btn btn-primary">Add Capacity <i class="fa fa-plus"></i></button>').on('click', function(event) {
                event.preventDefault();
                var count = capacitypricesTable.rows().count();
                capacitypricesTable.row.add({
                    "attendees_min": '<input class="form-control form-control-dt" name="capacityprices[' + count + '][attendees_min]" />',
                    "attendees_max": '<input class="form-control form-control-dt" name="capacityprices[' + count + '][attendees_max]" />',
                    "rate_hour": '<input class="form-control form-control-dt" name="capacityprices[' + count + '][rate_hour]" />',
                    "rate_halfday": '<input class="form-control form-control-dt" name="capacityprices[' + count + '][rate_halfday]" />',
                    "rate_day": '<input class="form-control form-control-dt" name="capacityprices[' + count + '][rate_day]" />',
                    "rate_month": '<input class="form-control form-control-dt" name="capacityprices[' + count + '][rate_month]" />',
                    "rate_afterhours": '<input class="form-control form-control-dt" name="capacityprices[' + count + '][rate_afterhours]" />'
                }).draw(true);
            });

            capacitypricesTable.on('draw.dt', function() {
                $('.capacityprices-table .btn-danger').off('click').on('click', function(event) {
                    event.preventDefault();
                    var capacityPriceId = $(this).data('id');
                    if (capacityPriceId !== 'undefined') {
                        var deletedCapacityPrices = $('#deleted_capacityprices').val().split(',');
                        deletedCapacityPrices.push(capacityPriceId);
                        $('#deleted_capacityprices').val(deletedCapacityPrices.join(','));
                    }
                    capacitypricesTable.row($(this).closest('tr')).remove().draw();
                });
            });

            $('div.toolbar').append(addCapacityPriceButton);


        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Spaces <button type="button" class="pull-right btn btn-primary" data-title="Add Space" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New Space</button></h1>
        </section>

        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            ﻿<table class="spaces-table display table responsive stripe compact" width="100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Is Active?</th>
                                        <th>Room #</th>
                                        <th>Room Name</th>
                                        <th>Host</th>
                                        <th>Description</th>
                                        <th>Booking Type</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>

    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center">Add Space</h2>

                    <div class="alert alert-success alert-light collapse"></div>
                    <div class="alert alert-danger alert-light collapse"></div>
                    <hr/>
                    {!! Form::open(['route' => ['api.spaces.create', 'id' => ''], 'method' => 'POST', 'id' => 'modalForm', 'class' => 'modalForm', 'files' => true]) !!}
                    {!! Form::hidden('active', 'false', ['id' => 'active']) !!}
                    {!! Form::hidden('deleted_capacityprices', '', ['id' => 'deleted_capacityprices']) !!}
                    <input type="hidden" name="_method" value="">
                    <div id="deleteMessage">
                        <p class="text-center" id="confirmation"></p>
                        <p class="text-center" id="details"></p>
                    </div>
                    <div id="formContainer">
                        <ul class="nav nav-tabs">
                            <li class="active"><a  href="#space_details" data-toggle="tab">Details</a></li>
                            <li><a href="#features" data-toggle="tab">Features</a></li>
                            <li><a href="#avail" data-toggle="tab">Availability</a></li>
                            <li><a href="#capacity_prices" data-toggle="tab">Capacity Prices</a></li>
                            <li><a href="#booking_details" data-toggle="tab">Booking Details</a></li>
                            <li><a href="#images" data-toggle="tab">Images</a></li>
                        </ul>

                        <div class="tab-content p-20">
                            <div class="tab-pane active" id="space_details">
                                <fieldset>
                                    <legend>Details</legend>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <h4>
                                                {!! Form::label('active', 'Status', ['class' => 'control-label']) !!}
                                                <div id="activeStatus_inactive" class="label label-warning" style="display:none;">INACTIVE</div>
                                                <div id="activeStatus_active" class="label label-success" style="display:none;">ACTIVE</div>
                                            </h4>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group has-feedback">
                                            <span class="fa fa-star text-danger"></span>
                                            {!! Form::label('building_id', 'Building', ['class' => 'control-label']) !!}
                                            {!! Form::select('building_id', ['' => 'Select Building'], NULL, ['id' => 'building_id', 'class' => 'form-control', 'required' => 'required']) !!}
                                            <div class="help-block with-errors"></div>
                                        </div>
                                        <div class="form-group has-feedback">
                                            {!! Form::label('room_number', 'Room Number', ['class' => 'control-label']) !!}
                                            {!! Form::text('room_number', null, ['id' => 'room_number', 'placeholder' => 'Enter Room Number', 'class' => 'form-control']) !!}
                                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group has-feedback">
                                            <span class="fa fa-star text-danger"></span>
                                            {!! Form::label('floor_id', 'Floor', ['class' => 'control-label']) !!}
                                            {!! Form::select('floor_id', ['' => 'Select Floor'], NULL, ['id' => 'floor_id', 'class' => 'form-control', 'required' => 'required', 'data-skip' => 'true']) !!}
                                            <div class="help-block with-errors"></div>
                                        </div>
                                        <div class="form-group has-feedback">
                                            <span class="fa fa-star text-danger"></span>
                                            {!! Form::label('room_name', 'Room Name', ['class' => 'control-label']) !!}
                                            {!! Form::text('room_name', null, ['id' => 'room_name', 'placeholder' => 'Enter Room Name', 'class' => 'form-control', 'required' => 'required']) !!}
                                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group has-feedback">
                                            <span class="fa fa-star text-danger"></span>
                                            {!! Form::label('host_id', 'Host', ['class' => 'control-label']) !!}
                                            {!! Form::select('host_id', ['' => 'Select Host'], NULL, ['id' => 'host_id', 'class' => 'form-control', 'required' => 'required', 'data-skip' => 'true']) !!}
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>
                                    <div class="col-md-12"><hr /></div>
                                    <div class="p-l-15 p-r-15">
                                        <div class="row">
                                            <div class="form-group has-feedback">
                                                <div class="col-md-3">
                                                    <span class="fa fa-star text-danger"></span>
                                                    {!! Form::label('day_start_time', 'Day Start Time', ['class' => 'control-label']) !!}
                                                    <div class='input-group date' id='day_start_time_input_group'>
                                                        {!! Form::text('day_start_time', null, ['id' => 'day_start_time', 'placeholder' => 'Day Start', 'class' => 'form-control', 'required' => 'required', 'data-fname' => 'Day Start Time']) !!}
                                                        <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                                                    </div>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group has-feedback">
                                                <div class="col-md-12 m-t-10">
                                                    <span class="fa fa-star text-danger"></span>
                                                    <label>Day Duration</label>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        {!! Form::text('day_duration', null, ['id' => 'day_duration', 'placeholder' => 'Duration', 'class' => 'form-control', 'required' => 'required', 'data-fname' => 'Day Duration']) !!}
                                                        <span class="input-group-addon">Min(s)</span>
                                                    </div>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                                <div class="col-md-9 m-t-15-neg">
                                                    <div id="day_duration_slider"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group has-feedback">
                                                <div class="col-md-12 m-t-10">
                                                    <span class="fa fa-star text-danger"></span>
                                                    <label>Month Duration</label>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        {!! Form::text('month_duration', null, ['id' => 'month_duration', 'placeholder' => 'Duration', 'class' => 'form-control', 'required' => 'required', 'data-fname' => 'Month Duration']) !!}
                                                        <span class="input-group-addon">Day(s)</span>
                                                    </div>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                                <div class="col-md-9 m-t-15-neg">
                                                    <div id="month_duration_slider"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group has-feedback">
                                                <div class="col-md-12 m-t-10">
                                                    <label>After Hours Duration</label>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        {!! Form::text('after_hours_duration', null, ['id' => 'after_hours_duration', 'placeholder' => 'Duration', 'class' => 'form-control']) !!}
                                                        <span class="input-group-addon">Min(s)</span>
                                                    </div>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                                <div class="col-md-9 m-t-15-neg">
                                                    <div id="after_hours_duration_slider"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group has-feedback">
                                                <div class="col-md-12 m-t-10">
                                                    <span class="fa fa-star text-danger"></span>
                                                    <label>Prep Time Before</label>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        {!! Form::text('prep_time_before', null, ['id' => 'prep_time_before', 'placeholder' => 'Prep Time', 'class' => 'form-control', 'required' => 'required', 'data-fname' => 'Prep Time Before']) !!}
                                                        <span class="input-group-addon">Min(s)</span>
                                                    </div>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                                <div class="col-md-9 m-t-15-neg">
                                                    <div id="prep_time_before_slider"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group has-feedback">
                                                <div class="col-md-12 m-t-10">
                                                    <span class="fa fa-star text-danger"></span>
                                                    <label>Prep Time After</label>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="input-group">
                                                        {!! Form::text('prep_time_after', null, ['id' => 'prep_time_after', 'placeholder' => 'Prep Time', 'class' => 'form-control', 'required' => 'required', 'data-fname' => 'Prep Time After']) !!}
                                                        <span class="input-group-addon">Min(s)</span>
                                                    </div>
                                                    <div class="help-block with-errors"></div>
                                                </div>
                                                <div class="col-md-9 m-t-15-neg">
                                                    <div id="prep_time_after_slider"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12 m-t-10">
                                        <hr />
                                        <div class="form-group">
                                            {!! Form::label('description', 'Description', ['class' => 'control-label']) !!}
                                            {!! Form::textarea('description', null, ['id' => 'description', 'placeholder' => '', 'class' => 'form-control', 'data-skip' => 'true']) !!}
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                            <div class="tab-pane" id="features">
                                <fieldset>
                                    <legend>Types</legend>
                                    {!! Form::select('spacetypes[]', $spaceTypesList, null, ['id' => 'spacetypes', 'class' => 'form-control selectpicker', 'multiple' => true]) !!}
                                </fieldset>
                                <fieldset>
                                    <legend>Space Features</legend>
                                    @foreach ($spaceFeatures as $idx => $facility)
                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                            {!! Form::checkbox('spacefeatures[]', $facility->id, null, ['id' => 'spacefeatures_' . $facility->id]) !!}
                                            <label for="spacefeatures_{{ $facility->id }}">&nbsp;<i class="{{ $facility->icon_style }}"></i>&nbsp;<span> {{ $facility->name }}</span></label>
                                        </div>
                                    @endforeach
                                </fieldset>
                                <fieldset>
                                    <legend>Shared Facilities</legend>
                                    @foreach ($sharedFacilities as $idx => $facility)
                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                            {!! Form::checkbox('sharedfacilities[]', $facility->id, null, ['id' => 'sharedfacilities_' . $facility->id]) !!}
                                            <label for="sharedfacilities_{{ $facility->id }}">&nbsp;<i class="{{ $facility->icon_style }}"></i>&nbsp;<span> {{ $facility->name }}</span></label>
                                        </div>
                                    @endforeach
                                </fieldset>
                            </div>
                            <div class="tab-pane" id="avail">
                                <div class="row">
                                    <div class="col-md-6">
                                        <fieldset>
                                            <legend>Availability</legend>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_mon">Monday</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_mon', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_tue">Tuesday</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_tue', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_wed">Wednesday</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_wed', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_thu">Thursday</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_thu', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_fri">Friday</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_fri', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_sat">Saturday</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_sat', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_sun">Sunday</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_sun', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="is_available_afterhours">After Hours Available</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('is_available_afterhours', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                    <div class="col-md-6">
                                        <fieldset>
                                            <legend>Enable Pricing Periods</legend>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="pricing_hourly_enabled">Hourly</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('pricing_hourly_enabled', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="pricing_halfdaily_enabled">Half-Daily</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('pricing_halfdaily_enabled', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="pricing_daily_enabled">Daily</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('pricing_daily_enabled', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                            <div class="row p-5">
                                                <div class="col-md-2 col-md-offset-4 text-center">
                                                    <label for="pricing_monthly_enabled">Monthly</label>
                                                </div>
                                                <div class="col-md-1 text-center">
                                                    {!! Form::checkbox('pricing_monthly_enabled', true, null, ['data-toggle' => 'toggle']) !!}
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="capacity_prices">
                                <fieldset>
                                    <legend>Capacity Prices</legend>
                                    <div class="col-md-12">
                                        <table class="capacityprices-table display table responsive stripe compact" width="100%">
                                            <thead>
                                            <tr>
                                                <th>Min Attendees</th>
                                                <th>Max Attendees</th>
                                                <th>Rate per Hour</th>
                                                <th>Rate per Half Day</th>
                                                <th>Rate per Full Day</th>
                                                <th>Rate per Month</th>
                                                <th>Rate after Hours</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </fieldset>
                            </div>
                            <div class="tab-pane" id="booking_details">
                                <fieldset>
                                    <legend>Booking Details</legend>

                                    <div class="col-md-12">
                                        <div class="form-group has-feedback">
                                            <span class="fa fa-star text-danger"></span>
                                            {!! Form::label('booking_type', 'Booking Type', ['class' => 'control-label']) !!}
                                            {!! Form::select('booking_type', ['' => 'Select Booking Type', 'R' => 'Request', 'I' => 'Instant'], NULL, ['id' => 'booking_type', 'class' => 'form-control', 'required' => 'required']) !!}
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Cancellation Percent</label>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            {!! Form::text('cancellation_percent', null, ['id' => 'cancellation_percent', 'placeholder' => '', 'class' => 'form-control']) !!}
                                            <span class="input-group-addon">%</span>
                                        </div>
                                    </div>
                                    <div class="col-md-9 m-t-15-neg">
                                        <div id="cancellation_percent_slider"></div>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Cancellation Hours</label>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            {!! Form::text('cancellation_hours', null, ['id' => 'cancellation_hours', 'placeholder' => '', 'class' => 'form-control']) !!}
                                            <span class="input-group-addon">Hr(s)</span>
                                        </div>
                                    </div>
                                    <div class="col-md-9 m-t-15-neg">
                                        <div id="cancellation_hours_slider"></div>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Booking Window MIN</label>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            {!! Form::text('booking_window_min', null, ['id' => 'booking_window_min', 'placeholder' => '', 'class' => 'form-control']) !!}
                                            <span class="input-group-addon">Min(s)</span>
                                        </div>
                                    </div>
                                    <div class="col-md-9 m-t-15-neg">
                                        <div id="booking_window_min_slider"></div>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Booking Window MAX</label>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            {!! Form::text('booking_window_max', null, ['id' => 'booking_window_max', 'placeholder' => '', 'class' => 'form-control']) !!}
                                            <span class="input-group-addon">Min(s)</span>
                                        </div>
                                    </div>
                                    <div class="col-md-9 m-t-15-neg">
                                        <div id="booking_window_max_slider"></div>
                                    </div>
                                    <div class="col-md-12 m-t-10">
                                        <label for="payment_creditcard_allowed">Credit Card Payments</label>
                                    </div>
                                    <div class="col-md-12">
                                        {!! Form::checkbox('payment_creditcard_allowed', true, NULL, ['data-toggle' => 'toggle']) !!}
                                    </div>
                                    <div class="col-md-12 m-t-10">
                                        <label for="payment_invoice_allowed">Invoices Allowed</label>
                                    </div>
                                    <div class="col-md-12">
                                        {!! Form::checkbox('payment_invoice_allowed', true, NULL, ['data-toggle' => 'toggle']) !!}
                                    </div>

                                    <div class="col-md-12 m-t-10">
                                        <hr />
                                        <div class="form-group">
                                            {!! Form::label('terms', 'Terms & Conditions / Rules / Cancellation Policy', ['class' => 'control-label']) !!}
                                            {!! Form::textarea('terms', null, ['id' => 'terms', 'placeholder' => '', 'class' => 'form-control']) !!}
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                            <div class="tab-pane" id="images">
                                <fieldset>
                                    <legend>Images</legend>
                                    <div class="col-md-12">
                                        <div class="form-group has-feedback">
                                            {!! Form::label('thumb_image', 'Thumbnail Image', ['class' => 'control-label']) !!}
                                            <span id="previewThumbnail"></span>
                                            <span class="fileupload fileupload-new" data-provides="fileupload">
                                            <span class="btn btn-default btn-file form-control">
                                                <i class="fa fa-picture-o" aria-hidden="true"></i> Add Thumbnail Image
                                                <input type="file" name="thumb_image" id="thumb_image" accept="image/*" />
                                            </span>
                                        </span>
                                            <span class='label label-danger text-center'>{{ ($errors->has('thumb_image') ? $errors->first('thumb_image') : '') }}</span>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group has-feedback">
                                            {!! Form::label('gallery_images[]', 'Gallery Images', ['class' => 'control-label']) !!}
                                            <span id="previewExistingGallery"></span>
                                            <span id="previewGallery"></span>
                                            <span class="fileupload fileupload-new" data-provides="fileupload">
                                                <span class="btn btn-default btn-file form-control">
                                                    <i class="fa fa-picture-o" aria-hidden="true"></i> Add Gallery Image
                                                    <input type="file" name="gallery_images[]" id="gallery_images" multiple accept="image/*" />
                                                </span>
                                            </span>
                                            <span class='label label-danger text-center'>{{ ($errors->has('gallery_images[]') ? $errors->first('gallery_images[]') : '') }}</span>
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                        </div>

                    </div>
                    <hr style="clear:both"/>
                    <div class="text-left">
                        {!! Form::hidden('id', null, ['id' => 'hostID']) !!}
                        <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                        <button type="submit" class="btn btn-warning pull-right" name="deactivate" data-active="false">MAKE INACTIVE <i class="fa fa-undo"></i></button>
                        <button type="submit" class="btn btn-success pull-right" name="activate" data-active="true">MAKE ACTIVE <i class="fa fa-arrow-circle-right"></i></button>
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

@stop




