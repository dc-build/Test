@extends('admin.layout')

@section('title')
    Space Types
@stop

@section('custom-scripts')
    <script>
        $(document).ready(function () {
            $(".data-table").DataTable({
                "language": {
                    "emptyTable": "NO SPACE TYPES FOUND."
                },
                "ajax": "/api/spacetypes",
                "columns": [
                    { "data": "id" },
                    { "data": "name" },
                    {
                        "data": "description",
                        "className": "snippet"
                    },
                    {
                        "data": "created_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "createdby",
                        "render": function (data) {
                            if (data) {
                                return Object.escapeHtml(data.full_name);
                            }
                        }
                    },
                    {
                        "data": "updated_at",
                        "render": function (data) {
                            return $.fn.displayDate(data);
                        }
                    },
                    {
                        "data": "updatedby",
                        "render": function (data) {
                            if (data) {
                                return Object.escapeHtml(data.full_name);
                            }
                        }
                    },
                    {
                        "className": "text-right",
                        "width": '225',
                        "data": "dummy",
                        "orderable": false,
                        "render": function (data, type, row, meta) {
                            var editButton =  '<a  class="btn btn-primary" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Edit Space Type" data-action="edit" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                            var deleteButton = '<a class="btn btn-danger" data-id="' + row.id + '" data-name="' + Object.escapeHtml(row.name) + '"   data-title="Delete Space Type" data-action="delete" data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;';
                            return deleteButton + editButton;
                        }
                    }
                ],
                "deferRender": true,
                "paging": true,
                "responsive": true
            });
            
            $('.alert').hide();

            var form = $('form.modalForm');
            var submitButton = form.find(":submit");
            var successContainer = $('.alert.alert-success');
            var dangerContainer = $('.alert.alert-danger');
            var formContainer = $('#formContainer');
            var deleteMessageContainer = $('#deleteMessage');

            // Prevent submitting the form from within an input (required to stop submission after the form has already been submitted)
            $('#modalForm input:text, #modalForm textarea').on('keydown', function (event) {
                if (event.which == 13) {
                    event.preventDefault();
                }
            });

            form.submit(function (e) {
                e.preventDefault();
                submitButton.attr({disabled: true});
                submitButton.html('<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>');
                $.ajax({
                    url: $(this).attr('action') || window.location.pathname,
                    type: $(this).attr('method'),
                    data: $(this).serialize(),
                    success: function (data) {
                        if (data.status == "success") {
                            dangerContainer.hide();
                            successContainer.text(data.message).show();
                            formContainer.hide();
                            deleteMessageContainer.hide();
                            submitButton.hide();
                        }
                        else {
                            successContainer.hide();
                            if (typeof data.message == 'string') {
                                dangerContainer.text(data.message).show();
                            } else {
                                dangerContainer.text('').show();
                                $.each(data.message, function (index, value) {
                                    dangerContainer.append(value + "<br />");
                                });
                            }
                            submitButton.html('Submit').attr({disabled: false}).show();
                        }
                    },
                    error: function (data) {
                        successContainer.hide();
                        dangerContainer.html(data.responseJSON.message).show();
                        submitButton.html('Submit').attr({disabled: false}).show();
                    }
                });
            });

            $('#formModal').on('show.bs.modal', function (event) {
                submitButton.html('Submit').attr({disabled: false}).show();
                var button = $(event.relatedTarget);
                var id = button.data('id');
                var title = button.data('title');
                var action = button.data('action');
                var name = button.data('name');
                var modal = $(this);
                $('#modal-title').text(title);
                formContainer.show();
                deleteMessageContainer.hide();

                if (action == "add") {
                    $("#modalForm").trigger("reset")
                        .attr('action', '/api/spacetypes')
                        .attr('method', 'POST');
                    $('#getMethod').html('');
                }
                if (action == "edit") {
                    $.getJSON("/api/spacetypes/" + id, function (json) {
                        for (var item in json) {
                            var input = $('#' + item);
                            if (typeof item != 'undefined') {
                                $(input).val(json[item]);
                            }
                        }
                    });
                    $('#modalForm').attr('action', '/api/spacetypes/' + id)
                        .attr('method', 'PUT');
                    $('#getMethod').html('<input name="_method" type="hidden" value="PUT">');
                }
                if (action == "delete") {
                    formContainer.hide();
                    deleteMessageContainer.show();
                    $('#confirmation').text("Are you sure you want to delete this space type?");
                    $('#details').text(name + " (ID: " + id + ")");
                    form.attr('action', '/api/spacetypes/' + id)
                        .attr('method', 'DELETE');
                    $('#getMethod').html('<input name="_method" type="hidden" value="DELETE">');
                }
            }).on('hidden.bs.modal', function (event) {
                if (successContainer.text() != "") {
                    $('.data-table').DataTable().ajax.reload();
                }
                successContainer.hide();
                dangerContainer.hide();
            });
        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Space Types <button type="button" class="pull-right btn btn-primary" data-title="Add Space Type" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New Space Type</button></h1>
        </section>

        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="data-table display table responsive stripe compact" width="100%">
                                <thead>
                                <tr>
                                    <th class="all">ID</th>
                                    <th class="all">Name</th>
                                    <th class="all snippet">Description</th>
                                    <th class="none">Date Created</th>
                                    <th class="none">Created by</th>
                                    <th class="all">Date Updated</th>
                                    <th class="all">Updated by</th>
                                    <th class="text-right">Action</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>
    <!-- /#page-wrapper -->

    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light"></div>
                    <div class="alert alert-danger alert-light"></div>
                    <hr/>
                    {!! Form::open(['route' => ['api.spacetypes.create', 'id' => ''], 'method' => '', 'id' => 'modalForm', 'class' => 'modalForm']) !!}
                    <input type="hidden" name="_method" value="">
                    <div id="deleteMessage">
                        <p class="text-center" id="confirmation"></p>
                        <p class="text-center" id="details"></p>
                    </div>
                    <div id="formContainer">
                        <div class="form-group {{ ($errors->has('name')) ? 'has-error' : '' }}">
                            {!! Form::label('name', 'Name *', ['class' => 'control-label']) !!}
                            {!! Form::text('name', null, ['id' => 'name', 'placeholder' => '', 'class' => 'form-control']) !!}
                            <span class='label label-danger text-center'>{{ ($errors->has('name') ? $errors->first('name') : '') }}</span>
                        </div>
                        <div class="form-group {{ ($errors->has('description')) ? 'has-error' : '' }}">
                            {!! Form::label('description', 'Description', ['class' => 'control-label']) !!}
                            {!! Form::text('description', null, ['id' => 'description', 'placeholder' => '', 'class' => 'form-control']) !!}
                            <span class='label label-danger text-center'>{{ ($errors->has('description') ? $errors->first('description') : '') }}</span>
                        </div>
                         <hr style="clear:both"/>
                    </div>
                    <div class="text-left">
                        {!! Form::hidden('id', null, ['id' => 'spacetypesID']) !!}
                        <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                        <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

@stop