@extends('admin.layout')

@section('title')
    Transactions
@stop

@section('custom-scripts')
    
    <script>
        
        $(document).ready(function () {
            $(".data-table").DataTable({
                "language": {
                    "emptyTable": "NO TRANSACTIONS FOUND."
                },
                "ajax": "/api/transactions",
                "columns": [
                    { "data": "id"},
                    { 
                        "data": "dummy",
                        "render": function(data, type, row, meta) {
                            if (row.spacebookings && row.spacebookings.company_name && row.spacebookings.id) {
                                return Object.escapeHtml(row.spaces.room_name) +" (ID "+row.spaces.id+")";
                            }
                            else {
                                return '';
                            }
                        }
                    },
                    { "data": "name"},
                    { "data": "last_four" },
                    { "data": "expiry_month" },
                    { "data": "expiry_year" },
                    { "data": "status" },
                    { "data": "total_amount" },
                    { "data": "fees" },
                    { "data": "net_amount" },
                    { "data": "receipt_number" },
                    { "data": "created_at" },
                    { "data": "updated_at" },
                ],
                "deferRender": true,
                "paging": true,
                "responsive": true
            });
        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Transactions</h1>
        </section>

        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table class="data-table display table responsive stripe compact" width="100%">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Space Booking</th>
                                    <th>Name</th>
                                    <th>Last Four</th>
                                    <th>Expiry Month</th>
                                    <th>Expiry Year</th>
                                    <th>Status</th>
                                    <th>Total Amount</th>
                                    <th>Fees</th>
                                    <th>Net Amount</th>
                                    <th>Receipt Number</th>
                                    <th class="none">Date Created</th>
                                    <th class="none">Date Updated</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>

    

@stop