@extends('admin.layout')

@section('title')
    Users
@stop

@section('custom-scripts')
    <script>
        $(document).ready(function() {
            $(".data-table").DataTable({
                "language": {
                    "emptyTable": "NO USERS FOUND."
                },
                "ajax" : "/api/users",
                "columns": [
                    { "data": "id" },
                    { 
                        "data": "auth0id",
                        "render": function(data, type, row, meta) {
                            if (row.auth0id == null) {
                                return '<i>null</i>';
                            }
                            else {
                                return row.auth0id;
                            }
                        }
                    },
                    { "data": "first_name"},
                    { "data": "last_name" },
                    { 
                        "data": "dummy" ,
                        "render": function(data, type, row, meta) {
                            if (row.roles) {
                                return Object.escapeHtml(row.roles.name);
                            }
                            else {
                                return '<i>null</i>';
                            }
                        }
                    },
                    { "data": "email"},
                    { "data": "mobile_number" },
                    {
                        "className": "dt-body-center",
                        "data": "isActive",
                        "render": function(data, type, row, meta) {
                            if (row.isActive == "1") {
                                return '<i class="fa fa-check-circle fa-2x text-success"></i>';
                            }
                            else {
                                return '<i class="fa fa-times-circle fa-2x text-danger"></i>';
                            }
                        }
                    },
                    {
                        "className": "text-right",
                        "width" : '225',
                        "data": "dummy",
                        "orderable": false,
                        "render": function(data, type, row, meta) {
                            return '<a class="btn btn-danger" data-id="' + row.id + '" data-email="' + Object.escapeHtml(row.email) + '"   data-title="Delete User" data-action="delete" data-target="#formModal" data-toggle="modal">Delete <i class="fa fa-eraser"></i></a>&nbsp;' +
                                '<a  class="btn btn-primary" data-id="' + row.id + '" data-email="' + Object.escapeHtml(row.email) + '"   data-title="Edit User" data-action="edit" data-target="#formModal" data-toggle="modal">Edit <i class="fa fa-pencil"></i></a>';
                        }
                    }
                ],
                "deferRender" : true,
                "paging" : true,
                "responsive" : true
            });

            $("#modalForm").fsm({
                modalId: '#formModal',
                useBootstrapValidator: true,
                showErrorSummary: true,
                addApiUrl: '/api/users',
                editApiUrl: '/api/users/',
                deleteApiUrl: '/api/users/',
                onPreSubmitHook: function(e) {
                    $('#formSubmit').innerHTML = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>';
                },
                onAddHook: function() {
                    $('#modal-title').text('Add User');
                },
                onPrePopulateHook: function() {
                },
                onEditHook: function(data) {
                    $('#modal-title').text('Edit User');
                },
                onDeleteHook: function() {
                    $('#modal-title').text('Delete User');
                    return true;
                },
                onHideModalHook: function() {
                    // Reload the grid
                    $('.data-table').DataTable().ajax.reload();
                }
            });

        });
    </script>
@stop

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Users <button type="button" class="pull-right btn btn-primary" data-title="Add User" data-action="add" data-target="#formModal" data-toggle="modal" id="addButton">New User</button></h1>
        </section>

        <section class="content">
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            ﻿<table class="data-table display table responsive stripe compact" width="100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th class="none">Auth0 ID</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Role</th>
                                        <th>Email</th>
                                        <th>Mobile Number</th>
                                        <th>is Active</th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </section>
    </div>
    
    
    <div class="modal fade" id="formModal" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <h2 id="modal-title" class="text-center"></h2>

                    <div class="alert alert-success alert-light"></div>
                    <div class="alert alert-danger alert-light"></div>
                    <hr />
                    {!! Form::open(['route' => ['api.users.create', 'id' => ''], 'method' => '', 'id' => 'modalForm', 'class' => 'modalForm']) !!}
                    <input type="hidden" name="_method" value="">
                    <div id="deleteMessage">
                            <p class="text-center" id="confirmation"></p>
                            <p class="text-center" id="details"></p>
                        </div>
                        <div id="formContainer">
                            <div class="form-group has-feedback">
                                <label for="first_name" class="control-label">First Name </label>
                                {!! Form::text('first_name', null, ['id' => 'first_name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group has-feedback">
                                <label for="last_name" class="control-label">Last Name </label>
                                {!! Form::text('last_name', null, ['id' => 'last_name', 'placeholder' => '', 'class' => 'form-control']) !!}
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group has-feedback">
                                <label for="email" class="control-label">Email Address <i class="fa fa-asterisk text-danger"></i></label>
                                {!! Form::text('email', null, ['id' => 'email', 'placeholder' => '', 'class' => 'form-control', 'required' => 'required']) !!}
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group has-feedback">
                                <label for="mobile_number" class="control-label">Mobile Number </label>
                                {!! Form::text('mobile_number', null, ['id' => 'mobile_number', 'placeholder' => '', 'class' => 'form-control', 'required' => 'required']) !!}
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group has-feedback">
                                <label for="role_id" class="control-label">Role <i class="fa fa-asterisk text-danger"></i></label>
                                {!! Form::select('role_id', $roles->lists('name', 'id'), null, ['id' => 'role_id', 'placeholder' => 'Select a Role', 'class' => 'form-control', 'required' => 'required']) !!}
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group has-feedback">
                                <label for="isActive" class="control-label">Is Active <i class="fa fa-asterisk text-danger"></i></label>
                                {!! Form::select('isActive', ['1' => 'Yes', '0' => 'No'], null, ['class' => 'form-control']) !!}
                                <div class="help-block with-errors"></div>
                            </div>
                            <hr style="clear:both" />
                        </div>
                        <div class="text-left">
                            {!! Form::hidden('id', null, ['id' => 'userID']) !!}
                            <button type="button" class="btn btn-default" data-dismiss="modal">CLOSE</button>
                            <button type="submit" class="btn btn-primary pull-right" name="submit" id="formSubmit">SUBMIT</button>
                        </div>
                    {!! Form::close() !!} 
                </div>
            </div>
        </div>
    </div>

@stop
