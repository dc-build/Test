@extends('layout')

@section('title')
    Home
@stop

@section('custom-css')

@stop

@section('custom-scripts')
    <script type="text/javascript">

        var lock_inline = new Auth0Lock('{{ env("AUTH0_CLIENT_ID") }}', '{{ env("AUTH0_DOMAIN") }}', {
            container: 'auth0_loginForm',
            allowSignUp: false,
            theme: {
                logo: "",
                primaryColor: '#19ace2'
            },
            languageDictionary: {
                title: "To book a space you will need to Login or Sign up for an account"
            },
            auth: {
                redirectUrl: '{{ route("auth0.callback") }}?ref={{$referrer}}',
                responseType: 'code',
                params: { 
                  scope: 'openid email' // Learn about scopes: https://auth0.com/docs/scopes
                }
            }
        });
        lock_inline.show();
    </script>
@stop

@section('content')
    <div class="page-hero-wrapper bg-home">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p>Login</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row m-top-20 m-bot-50">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div id="auth0_loginForm" style="width: 320px; margin: 40px auto; padding: 10px; border: 1px solid #f1f1f1; box-sizing: border-box;">
                    
                </div>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>

    
@stop
