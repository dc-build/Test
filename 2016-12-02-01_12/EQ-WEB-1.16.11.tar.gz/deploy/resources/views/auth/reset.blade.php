@extends('layout')

@section('title')
    Home
@stop

@section('custom-css')

@stop

@section('custom-scripts')
    
@stop

@section('content')

    <div class="container">
        <!-- Example row of columns -->
        <div class="row">
            <div class="col-md-4">
                
            </div>
            <div class="col-md-4">
                <h2>Reset Password</h2>
                <form method="POST" action="{{ route('password-reset.complete.post') }}" accept-charset="UTF-8" class="auth-form">
                    {!! csrf_field() !!}

                    <input type="hidden" name="token" value="{{ $token }}">

                    <p class="txt-light text-center">
                        Enter your email address and a new password. <br/> For you security and piece of mind, passwords must be secure and contain:
                    </p>
                    <ul class="txt-light">
                        <li>A mix of uppercase (A-Z) and lowercase (a-z) letters</li>
                        <li>At least one number from 0-9</li>
                        <li>At least one special character (For example: !, $, #, or %)</li>
                    </ul>

                    <div class="form-group {{ ($errors->has('email')) ? 'has-error' : '' }}">
                        <input class="form-control" placeholder="EMAIL ADDRESS" autofocus="autofocus" name="email" type="text" value="{{ Input::old('email') }}" autocomplete="off">
                        <span class='label label-danger text-center'>{{ ($errors->has('email') ? $errors->first('email') : '') }}</span>
                    </div>

                    <div class="form-group {{ ($errors->has('password')) ? 'has-error' : '' }}">
                        <input class="form-control" placeholder="NEW PASSWORD" name="password" value="" type="password" autocomplete="off">
                        <span class='label label-danger text-center'>{{ ($errors->has('password') ?  $errors->first('password') : '') }}</span>
                    </div>

                    <div class="form-group {{ ($errors->has('password_confirmation')) ? 'has-error' : '' }}">
                        <input class="form-control" placeholder="PASSWORD CONFIRMATION" name="password_confirmation" value="" type="password" autocomplete="off">
                        <span class='label label-danger text-center'>{{ ($errors->has('password_confirmation') ?  $errors->first('password_confirmation') : '') }}</span>
                    </div>

                    <button type="submit" class="btn btn-cta pull-right">Reset Password  <i class="fa fa-chevron-circle-right"></i></button>

                </form>
            </div>
            <div class="col-md-4">
                
            </div>
        </div>
@stop