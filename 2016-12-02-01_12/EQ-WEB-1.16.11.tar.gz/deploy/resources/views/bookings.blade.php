@extends('layout')

@section('title')
    My Bookings
@stop

@section('custom-css')

@stop

@section('custom-scripts')
    
@stop

@section('content')
    <div class="page-hero-wrapper bg-home">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p>My Bookings</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container my-bookings">
        <div class="row  m-top-50">
            <div class="col-md-12">
                
                @forelse ($spacebookings as $month => $spacebooking)
                    <div class="col-md-12">
                        <h1>{{$month}}</h1>
                    </div>
                    @foreach ($spacebooking as $spacebooking)
                    
                        @section('logo')
                            <a class="navbar-brand" href="{{ url('buildings', $spacebooking->building_private_slug) }}"><img class="rounded img-responsive" src="{{ asset('images/uploads/'.$spacebooking->image_building_image_uuid.'.'.$spacebooking->image_building_file_ext) }}" /></a>
                        @stop

                        @section('find-spaces-link')
                            <a href="{{ url('buildings', $spacebooking->building_private_slug) }}" class="btn btn-clear">Find Spaces</a>
                        @stop
                        
                        @section('return-to-portal-link')
                            <a class="btn btn-clear-black" href="{{ $spacebooking->building_direct_url }}">Return to Portal</a>
                        @stop
                        
                        <hr />
                        <div class="col-md-2 m-bot-20" style="clear:both">
                            @if($spacebooking->image_space_image_uuid)
                                <img class="rounded img-responsive spaceThumb" src="{{ asset('images/uploads/'.$spacebooking->image_space_image_uuid.'.'.$spacebooking->image_space_file_ext) }}" />
                            @else
                                <img class="rounded img-responsive" src="{{ asset('images/building/sample_thumb2.png') }}" />
                            @endif
                        </div>
                        <div class="col-md-7 m-bot-20">
                            <p>{{ $spacebooking->event_title }}</p>
                            <p>
                                <a href="{{ route('detail',['building_private_slug' => $spacebooking->building_private_slug, 'space_private_slug' => $spacebooking->spaces_private_slug]) }}">{{ $spacebooking->spaces_room_name }}</a> 
                                <small><a href="{{ route('buildings.show',['idOrSlug' => $spacebooking->building_private_slug]) }}"><i class="fa fa-map-marker m-left-10" aria-hidden="true"></i> {{ $spacebooking->building_name }}</a></small>
                            </p>
                            <span class="text-blue text-large" id="total_price">${{ number_format($spacebooking->total_price) }}</span> <span class="text-large m-left-20"><i class="text-blue fa fa-user" aria-hidden="true"></i> {{ $spacebooking->num_attendees }}</span>
                        </div>

                        <div class="col-md-3 m-bot-50">
                            @if(isset($spacebooking->date)) 
                                <p class="text-right">{{ $spacebooking->date }}</p>
                                <p class="text-large text-right">{{ $spacebooking->start_time }} - {{ $spacebooking->end_time }}</p>
                            @else
                                <p class="text-right">{{ $spacebooking->start_datetime }} to {{ $spacebooking->end_datetime }}</p>
                                <p class="text-large text-right">{{ $spacebooking->start_time }} - {{ $spacebooking->end_time }}</p>
                            @endif
                            <div class="row">
                                <div class="col-xs-6">
                                    <a class="btn btn-black" href="{{ route('my.bookings.edit', ['idOrSlug' => $spacebooking->building_private_slug, 'id' => $spacebooking->id]) }}">Edit</a>
                                </div>
                                <div class="col-xs-6">
                                    <a class="btn btn-blue" href="{{ route('my.bookings.view', ['idOrSlug' => $spacebooking->building_private_slug, 'id' => $spacebooking->id]) }}">View</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @empty
                    <div class="text-center m-bot-50"><h1>No space bookings found</h1></div>
                @endforelse
                
                
                @if (!$spacebookingsarchive->isEmpty())
                    <div class="col-md-12">
                        <h1>Past Bookings</h1>
                    </div>
                    <hr />
                @endif
                
                @forelse ($spacebookingsarchive as $archivemonth => $spacebookingarchive)
                    <div class="col-md-12">
                        <h1>{{$archivemonth}}</h1>
                    </div>
                    @foreach ($spacebookingarchive as $spacebookingarchive)
                        <div class="col-md-2 m-bot-20" style="clear:both">
                            @if($spacebookingarchive->image_space_image_uuid)
                                <img class="rounded img-responsive spaceThumb" src="{{ asset('images/uploads/'.$spacebookingarchive->image_space_image_uuid.'.'.$spacebookingarchive->image_space_file_ext) }}" />
                            @else
                                <img class="rounded img-responsive" src="{{ asset('images/building/sample_thumb2.png') }}" />
                            @endif
                        </div>
                        <div class="col-md-7 m-bot-20">
                            <p>{{ $spacebookingarchive->event_title }}</p>
                            <p>
                                <a href="{{ route('detail',['building_private_slug' => $spacebookingarchive->building_private_slug, 'space_private_slug' => $spacebookingarchive->spaces_private_slug]) }}">{{ $spacebookingarchive->spaces_room_name }}</a> 
                                <small><a href="{{ route('buildings.show',['idOrSlug' => $spacebookingarchive->building_private_slug]) }}"><i class="fa fa-map-marker m-left-10" aria-hidden="true"></i> {{ $spacebookingarchive->building_name }}</a></small>
                            </p>
                            <span class="text-blue text-large" id="total_price">${{ number_format($spacebookingarchive->total_price) }}</span> <span class="text-large m-left-20"><i class="text-blue fa fa-user" aria-hidden="true"></i> {{ $spacebookingarchive->num_attendees }}</span>
                        </div>

                        <div class="col-md-3 m-bot-50">
                            @if(isset($spacebookingarchive->date)) 
                                <p class="text-right">{{ $spacebookingarchive->date }}</p>
                                <p class="text-large text-right">{{ $spacebookingarchive->start_time }} - {{ $spacebookingarchive->end_time }}</p>
                            @else
                                <p class="text-right">{{ $spacebookingarchive->start_datetime }} to {{ $spacebookingarchive->end_datetime }}</p>
                                <p class="text-large text-right">{{ $spacebookingarchive->start_time }} - {{ $spacebookingarchive->end_time }}</p>
                            @endif
                            <div class="row">
                                <div class="col-xs-6">
                                    
                                </div>
                                <div class="col-xs-6">
                                    <a class="btn btn-blue" href="{{ route('my.bookings.view', ['idOrSlug' => $spacebookingarchive->building_private_slug, 'id' => $spacebookingarchive->id]) }}">View</a>
                                </div>
                            </div>
                        </div>
                    @endforeach
                @empty
                @endforelse
                
            </div>
        </div>
        
    </div>


    
@stop
