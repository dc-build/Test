@extends('layout')

@section('title')
    {{ $spacebookings->event_title }} | My Bookings | {{ $space->building->name }} {{ $space->building->street_address_1 }}
@stop

@section('logo')
    <a class="navbar-brand" href="{{ url('buildings', $space->building->private_slug) }}"><img class="rounded img-responsive" src="{{ $space->building->logoImage[0]->filePath('logo') }}" /></a>
@stop

@section('find-spaces-link')
    <a href="{{ url('buildings', $space->building->private_slug) }}" class="btn btn-clear">Find Spaces</a>
@stop

@section('return-to-portal-link')
    <a class="btn btn-clear-black" href="{{ $space->building->direct_url }}">Return to Portal</a>
@stop

@section('custom-css')

@stop

@section('custom-scripts')
    <script>
        $(document).ready(function () {
            $('.payment_type_invoice').find('.col-md-6').each(function() {
                $(this).removeClass("col-md-6").addClass("col-md-12");
            });
            $('.payment_type_invoice').find('.col-md-3').each(function() {
                $(this).removeClass("col-md-3").addClass("col-md-6");
            });
            $('.payment_type_invoice').find('input').each(function() {
                $(this).attr('required', 'required');
            });
            $('.person_responsible').find('span.glyphicon').each(function() {
                $(this).removeClass("m-top-20");
            });
            $('#contact_name').val("{{ $spacebookings->contact_name }}");
            $('#company_name').val("{{ $spacebookings->company_name }}");
            $('#company_address').val("{{ $spacebookings->company_address }}");
            $('#company_postcode').val("{{ $spacebookings->company_postcode }}");
            $('#company_state').val("{{ $spacebookings->company_state }}");
            $('#company_city').val("{{ $spacebookings->company_city }}");
            $('#company_country').val("{{ $spacebookings->company_country }}");
            $('#purchase_order').val("{{ $spacebookings->purchase_order }}");
        })
    </script>
@stop

@section('content')
    <div class="page-hero-wrapper bg-home">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p>My Bookings</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container my-bookings">
        <div class="row  m-top-20 m-bot-50">
            <div class="col-md-12">
                <p><a href="{{ route('my.bookings') }}"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Back to My Bookings</a></p>
                <hr />
                
                @if(session()->has('success'))
                    <div class="alert alert-success alert-light">
                        {{ session('success') }}
                    </div>
                @endif

                @if (count($errors) > 0)
                    <div class="alert alert-danger alert-light">
                        @foreach ($errors->all() as $error)
                            {{ $error }} <br>
                        @endforeach
                    </div>
                @endif
                
                <div class="row">
                    <div class="col-md-6 m-bot-20">
                        {!! Form::open(['route' => ['my.bookings.edit.post', 'building_private_slug' => $space->building->private_slug, 'id' => $spacebookings->id], 'method' => 'post', 'id' => 'edit-spacebooking-form', 'data-error' => 'Event Title is required', 'data-toggle' => 'validator', 'role' => 'form']) !!}
                            <div class="form-group has-feedback">
                                <label for="message" class="control-label">Event Title <i class="fa fa-asterisk text-danger"></i></label>
                                {!! Form::text('event_title', $spacebookings->event_title, ['id' => 'event_title', 'class' => 'form-control', 'required']) !!}
                                <div class="help-block with-errors"></div>
                                <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                            </div>
                            <div class="form-group">
                                <label for="message" class="control-label">Your Description </label>
                                {!! Form::textarea('event_description', $spacebookings->event_description, ['id' => 'event_description', 'class' => 'form-control']) !!}
                            </div>
                            @if ($spacebookings->payment_type == 'INVOICE')
                                <div class="payment_type_invoice">
                                    @include('_partials.invoice_details_form')
                                </div>
                            @endif
                            
                            <div class="row">
                                <div class="col-md-6 text-right">
                                    <input class="btn btn-dark-blue" id="updateMyBooking" type="submit" value="Update My Booking Details">
                                </div>
                            </div>
                        {!! Form::close() !!}
                    </div>
                    <div class="col-md-6">
                        <div class="row m-bot-20">
                            <div class="col-md-6 text-left">
                                <strong>{{ $spacebookings->spaces->room_name }}</strong><br />{{ $space->building->name }}<br />{{ $space->building->street_address_1 }} {{ $space->building->locality->name }}<br />{{ $space->building->region->name }} {{ $space->building->country->name }}
                            </div>
                        </div>
                        @if ($spacebookings->widgetSource=="hourly")
                            
                            <div class="row">
                                <div class="col-md-6">
                                    {!! Form::label('date', 'Date') !!}
                                    {!! Form::text(null, $spacebookings->date, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                                <div class="col-md-6">
                                    {!! Form::label('num_attendees', 'Attendees') !!}
                                    {!! Form::number(null, $spacebookings->num_attendees, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                            </div>
                            <div class="row m-top-20">
                                <div class="col-md-6">
                                    {!! Form::label('time_from', 'Time from') !!}
                                    {!! Form::text(null, $spacebookings->start_time, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                                <div class="col-md-6">
                                    {!! Form::label('time_to', 'Time To') !!}
                                    {!! Form::text(null, $spacebookings->end_time, ['class' => 'form-control', 'disabled']) !!}
                                </div>  
                            </div>
                        @elseif ($spacebookings->widgetSource=="daily")
                            <div class="row">
                                <div class="col-md-6">
                                    {!! Form::label('date_from', 'Date From') !!}
                                    {!! Form::text(null, $spacebookings->start_datetime, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                                <div class="col-md-6">
                                    {!! Form::label('date_to', 'Date To') !!}
                                    {!! Form::text(null, $spacebookings->end_datetime, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                            </div>
                            <div class="row m-top-20">
                                <div class="col-md-12">
                                    {!! Form::label('num_attendees', 'Attendees') !!}
                                    {!! Form::number(null, $spacebookings->num_attendees, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        
    </div>


@stop
