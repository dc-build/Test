@extends('layout')

@section('title')
    {{ $spacebookings->event_title }} | My Bookings | {{ $space->building->name }} {{ $space->building->street_address_1 }}
@stop

@section('logo')
    <a class="navbar-brand" href="{{ url('buildings', $space->building->private_slug) }}"><img class="rounded img-responsive" src="{{ $space->building->logoImage[0]->filePath('logo') }}" /></a>
@stop

@section('find-spaces-link')
    <a href="{{ url('buildings', $space->building->private_slug) }}" class="btn btn-clear">Find Spaces</a>
@stop

@section('return-to-portal-link')
    <a class="btn btn-clear-black" href="{{ $space->building->direct_url }}">Return to Portal</a>
@stop

@section('custom-css')

@stop

@section('custom-scripts')
    
@stop

@section('content')
    <div class="page-hero-wrapper bg-home">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p>My Bookings</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container my-bookings">
        <div class="row  m-top-20 m-bot-50">
            <div class="col-md-12">
                <p><a href="{{ route('my.bookings') }}"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Back to My Bookings</a></p>
                <hr />

                <div class="row">
                    <div class="col-md-6">
                        <p><span class="text-large">{{ $spacebookings->event_title }}</span></p>

                        @if ($spacebookings->event_description)
                            <p><span class="">{{ $spacebookings->event_description }}</span></p>
                        @endif
                        
                        @if($spacebookings->payment_type == 'INVOICE')
                            <hr />
                            <div class="row">
                                <div class="col-md-8 text-left">

                                        <div class="m-top-20">
                                            <p><strong>Contact Name</strong> <br />{{ $spacebookings->contact_name }}</p>
                                            <p><strong>Company Name</strong> <br />{{ $spacebookings->company_name }}</p>
                                            <p><strong>Company Address</strong> <br />{{ $spacebookings->company_address }} {{ $spacebookings->company_city }} {{ $spacebookings->company_state }} {{ $spacebookings->company_postcode }} {{ $spacebookings->company_country }}</p>
                                            <p><strong>Purchase Order</strong> <br />{{ $spacebookings->purchase_order }}</p>
                                        </div>

                                </div>
                            </div>
                        @endif
                        
                        <hr />
                        <div class="row">
                            <div class="col-md-12">
                                <p>Payment via  {{ $spacebookings->payment_type }}</p>
                                <p class="text-large text-left">Total <span class="pull-right" id="payment_total">${{ number_format($spacebookings->total_price) }}</span></p>
                                <hr />
                                <p><small>The service fee for this space is included in the total listing price. <br />All prices are inclusive of GST.</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row m-bot-20">
                            <div class="col-md-6 text-left">
                                <strong>{{ $spacebookings->spaces->room_name }}</strong><br />{{ $space->building->name }}<br />{{ $space->building->street_address_1 }} {{ $space->building->locality->name }}<br />{{ $space->building->region->name }} {{ $space->building->country->name }}
                            </div>
                        </div>
                        @if ($spacebookings->widgetSource=="hourly")
                            
                            <div class="row">
                                <div class="col-md-6">
                                    {!! Form::label('date', 'Date') !!}
                                    {!! Form::text('date', $spacebookings->date, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                                <div class="col-md-6">
                                    {!! Form::label('num_attendees', 'Attendees') !!}
                                    {!! Form::number('num_attendees', $spacebookings->num_attendees, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                            </div>
                            <div class="row m-top-20">
                                <div class="col-md-6">
                                    {!! Form::label('time_from', 'Time from') !!}
                                    {!! Form::text('time_from', $spacebookings->start_time, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                                <div class="col-md-6">
                                    {!! Form::label('time_to', 'Time To') !!}
                                    {!! Form::text('time_to', $spacebookings->end_time, ['class' => 'form-control', 'disabled']) !!}
                                </div>  
                            </div>
                        @elseif ($spacebookings->widgetSource=="daily")
                            <div class="row">
                                <div class="col-md-6">
                                    {!! Form::label('date_from', 'Date From') !!}
                                    {!! Form::text('date_from', $spacebookings->start_datetime, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                                <div class="col-md-6">
                                    {!! Form::label('date_to', 'Date To') !!}
                                    {!! Form::text('date_to', $spacebookings->end_datetime, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                            </div>
                            <div class="row m-top-20">
                                <div class="col-md-12">
                                    {!! Form::label('num_attendees', 'Attendees') !!}
                                    {!! Form::number('num_attendees', $spacebookings->num_attendees, ['class' => 'form-control', 'disabled']) !!}
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        
    </div>


@stop
