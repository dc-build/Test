@extends('layout')

@section('title')
    Building: {{ $building->displayName }}
@stop

@section('logo')
    <a class="navbar-brand" href="{{ url('buildings', $building->private_slug) }}"><img class="rounded img-responsive" src="{{ $building->logoImage[0]->filePath('logo') }}" /></a>
@stop

@section('find-spaces-link')
    <a href="{{ url('buildings', $building->private_slug) }}" class="btn btn-clear">Find Spaces</a>
@stop

@section('return-to-portal-link')
    <a class="btn btn-clear-black" href="{{ $building->direct_url }}">Return to Portal</a>
@stop

@section('custom-scripts')
    <script>
        $(function () {

            $(".selectpicker").selectpicker();

            var populateFacilities = function (data) {
                var facilities = $('<div>');
                $.each(data, function (idx, item) {
                    facilities.append(
                        $('<div>').append(
                            $('<i>')
                                .addClass(item.icon_style)
                                .attr('aria-hidden', true)
                                .prop('title', Object.escapeHtml(item.name))
                                .attr('data-toggle', 'tooltip')
                                .attr('data-placement', 'top')
                                .html('&nbsp;&nbsp;')
                        )
                    )
                });
                return facilities.html();
            };

            var costTempl = '<span class="m-r-15"><span class="text-light-blue">${price}</span> / {period}</span>';

            var populateCosts = function (data) {
                var costs = $('<div>');
                $.each(
                    {maxHourlyPrice: 'HOUR', maxHalfDayPrice: 'HALF-DAY', maxFullDayPrice: 'DAY', maxMonthPrice: 'MONTH'},
                    function(price, period) {
                        if (data[price]) {
                            data.period = period;
                            costs.append(
                                $($.fn.parseTempl(costTempl, {price: price, period: 'period'}, data))
                            );
                        }
                    }
                );

                return costs.html();
            };

            var spacePage = {
                filterForm: '#filter',

                spaceTemplate: '\
                <div class="panel panel-default">\
                    <div class="panel-body">\
                        <div class="row">\
                            <div class="col-sm-4">\
                                <img class="img-responsive" src="{thumbnail_url}"/>\
                            </div>\
                            <div class="col-sm-8">\
                                <h1>{room_name}</h1>\
                                <div class="text-light-gray"><i class="fa fa-map-marker" aria-hidden="true"></i> {building}, {floor}, {full_address}</div>\
                                <hr />\
                                <div class="description">{description}</div>\
                                <div class="row">\
                                    <div class="col-sm-12 col-md-4">\
                                        <span class="text-large-blue">Capacity: {min_capacity}&ndash;{max_capacity}</span> \
                                    </div>\
                                    <div class="facilities flex-container col-sm-12 col-md-8">\
                                        <div>Amenities: </div>\
                                        {facilities}\
                                    </div>\
                                </div>\
                                <hr/>\
                                <div class="text-light-gray">\
                                    {costs}\
                                </div>\
                                <hr />\
                                <div class="row">\
                                    <div class="col-xs-6 col-md-4">\
                                        <img class="img-responsive" src="{logo_url}"/>\
                                    </div>\
                                    <div class="col-xs-6 col-md-offset-4 col-md-4"><a class="btn btn-black rounded" href="/buildings/{{ $id }}/spaces/{private_slug}?{query_mod}">View Details</a></div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>\
                </div>',

                translations: {
                    space_id: 'id',
                    logo_url: {
                        locator: 'host.logo_image.0.url',
                        callback: function(data) {
                            if (typeof data == 'undefined')
                            {
                                return '/images/missing_logo.png';
                            }
                            else {
                                return data;
                            }
                        }
                    },
                    thumbnail_url: {
                        locator: 'thumb_image.0.url',
                        callback: function(data) {
                            if (typeof data == 'undefined')
                            {
                                return '/images/missing_thumbnail.png';
                            }
                            else
                            {
                                return data;
                            }
                        }
                    },
                    room_name: {
                        locator: 'room_name',
                        callback: function(data) {
                            return Object.escapeHtml(data);
                        }
                    },
                    floor: 'floor.name',
                    building: {
                        locator: 'building.display_name',
                        callback: function(data) {
                            return Object.escapeHtml(data);
                        }
                    },
                    full_address: {
                        locator: 'building.full_address',
                        callback: function(data) {
                            return Object.escapeHtml(data);
                        }
                    },
                    description: {
                        locator: 'description',
                        callback: function(data) {
                            return $.fn.truncate(data, 20);
                        }
                    },
                    min_capacity: 'min_capacity',
                    max_capacity: 'max_capacity',
                    private_slug: 'private_slug',
                    facilities: {
                        locator: 'spacefacilities',
                        callback: populateFacilities
                    },
                    query_mod: {
                        locator: 'query_mod',
                        callback: function(){
                            var urlData = '';
                            if(($('#max_capacity').val()) && $.isNumeric($('#max_capacity').val()))
                            {
                                urlData += 'people=' + $('#max_capacity').val() + '&';
                            }

                            if(($('#start_date').val()))
                            {

                                urlData += 'start_date=' + $('#start_date').data("DateTimePicker").date().format('YYYY-MM-DD') + '&' + 'start_time=' + $('#start_date').data("DateTimePicker").date().format('HH:mm') + "&";
                            }

                            if(($('#end_date').val()))
                            {
                                var endTime = '';
                                if(($('#start_date').val()))
                                {
                                    if($('#start_date').data("DateTimePicker").date().isSame($('#end_date').data("DateTimePicker").date(), 'day'))
                                    {
                                        endTime = $('#end_date').data("DateTimePicker").date().format('HH:mm');
                                    }
                                    else
                                    {
                                        endTime = $('#start_date').data("DateTimePicker").date().add(1, 'hours').format('HH:mm');
                                    }
                                }
                                urlData += 'end_date=' + $('#end_date').data("DateTimePicker").date().format('YYYY-MM-DD') + '&' + 'end_time=' + endTime + "&";
                            }

                            if($('#floor').val())
                            {
                                urlData += 'floor='+$("#floor").val();
                            }

                            if($("#pricing").val())
                            {
                                urlData += 'duration=' + $("#pricing").val();
                            }

                            return urlData;
                        }
                    },
                    costs: {
                        locator: '',
                        callback: populateCosts
                    }
                },

                handleSuccess: function (data) {
                    spacePage.showCount(data.length);
                    $('#search-results-listing').empty();
                    $.each(data, function (idx, item) {
                        this.addSpace($('#search-results-listing'), item);
                    }.bind(this));
                    $('[data-toggle="tooltip"]').tooltip();
                },

                handleError: function () {
                    spacePage.showCount(0);
                    $('#search-results-listing').empty().append(
                        $('<p class="tt-upper text-center text-weight-400 m-top-50">')
                            .text('No spaces match your search criteria.')
                    );
                },

                addSpace: function (container, data) {
                    var space = $.fn.parseTempl(this.spaceTemplate, this.translations, data);
                    container.append($(space));
                },

                doFilter: function (data) {
                    spacePage.showCountThrobber();
                    $.ajax('/buildings/{{ $id }}/spaces', {
                        data: data,
                        success: spacePage.handleSuccess.bind(spacePage),
                        error: spacePage.handleError.bind(spacePage)
                    });
                },

                filter: function () {
                    this.doFilter($(this.filterForm).serialize());
                },

                showCountThrobber: function() {
                    $('#search-count-value').addClass('fa fa-circle-o-notch fa-spin').html(' ');
                },

                showCount: function(count) {
                    $('#search-count-value').removeClass('fa fa-circle-o-notch fa-spin').html(count);
                }
            };


            $('.datepicker').datetimepicker({
                format:'YYYY-MM-DD HH:mm'
            });

            var filter = $('#filter');

            $('#filter input[type="text"]').on('blur', spacePage.filter.bind(spacePage));
            $('#filter input[type="radio"]').on('change', spacePage.filter.bind(spacePage));
            $('#filter input[type="checkbox"]').on('change', spacePage.filter.bind(spacePage));
            $('#filter select').on('change', spacePage.filter.bind(spacePage));

            spacePage.doFilter($(spacePage.filterForm).serialize());

            $('#search-extras-row')
                .on('shown.bs.collapse', function () {
                    $('#search-extras .search-extras-drop').removeClass('fa-chevron-down').addClass('fa-chevron-up');
                })
                .on('hidden.bs.collapse', function () {
                    $('#search-extras .search-extras-drop').removeClass('fa-chevron-up').addClass('fa-chevron-down');
                });
        });
    </script>
@stop

@section('content')
    {!! Form::open(['url' => route('buildings.spaces', [$id]), 'id' => 'filter']) !!}
    <div class="page-hero-wrapper" style="background-image: linear-gradient(rgba(0, 0, 0, 0.60), rgba(0, 0, 0, 0.60)), url({{ $building->headerImage[0]->filePath('header') }})">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p><span class="text-blue">{{ $building->display_name }}</span> Spaces</p>
                </div>
                <div class="cover-container cover-bottom">
                    <div class="cover">
                        <div class="search-bar row">
                            <div class="col-sm-2">
                                {!! Form::text('start_date', null, ['class' => 'form-control datepicker', 'id' => 'start_date', 'placeholder' => 'FROM DATE/TIME' ]) !!}
                            </div>
                            <div class="col-sm-2">
                                {!! Form::text('end_date', null, ['class' => 'form-control datepicker', 'id' => 'end_date', 'placeholder' => 'TO DATE/TIME' ]) !!}
                            </div>
                            <div class="col-sm-2">
                                {!! Form::select('spacetype_id', $typesList, null, ['class' => 'form-control selectpicker text-uppercase', 'placeholder' => 'ROOM TYPE']) !!}
                            </div>
                            <div class="col-sm-2">
                                {!! Form::select('floor', $floors, $floor, ['id' => 'floor', 'class' => 'form-control selectpicker text-uppercase', 'placeholder' => 'Any Floor']) !!}
                            </div>
                            <div class="col-sm-2">
                                {!! Form::text('max_capacity', '', ['class' => 'form-control text-uppercase', 'id' => 'max_capacity', 'placeholder' => 'No. of people']) !!}
                            </div>
                            <div class="col-sm-2">
                                {!! Form::select('pricing', $pricingTypes, null, ['id' => 'pricing', 'class' => 'form-control selectpicker text-uppercase', 'placeholder' => 'Hourly, Daily or Monthly']) !!}
                            </div>
                        </div>
                        <div class="search-bar row">
                            <div class="col-sm-12">
                                <a href="#search-extras-row" class="pull-left btn btn-sm" role="button" id="search-extras" data-toggle="collapse">
                                    More Options <span class="search-extras-drop fa fa-chevron-up"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="search-extras row collapse" id="search-extras-row">
                                    <div class="search-bar row">
                                        <div class="col-lg-12"><h3>Features available in the space</h3></div>
                                    </div>
                                    <div class="row">
                                        @foreach ($spaceFeatures as $idx => $facility)
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                {!! Form::checkbox('facilities[]', $facility->id, null, ['id' => 'facilities_' . $facility->id]) !!}
                                                <label for="facilities_{{ $facility->id }}">&nbsp;<i class="{{ $facility->icon_style }}"></i>&nbsp;<span> {{ $facility->name }}</span></label>
                                            </div>
                                        @endforeach
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12"><h3>Shared facilities useable by attendees</h3></div>
                                    </div>
                                    <div class="row">
                                        @foreach ($sharedFacilities as $idx => $facility)
                                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                                {!! Form::checkbox('facilities[]', $facility->id, null, ['id' => 'facilities_' . $facility->id]) !!}
                                                <label for="facilities_{{ $facility->id }}">&nbsp;<i class="{{ $facility->icon_style }}"></i>&nbsp;<span> {{ $facility->name }}</span></label>
                                            </div>
                                        @endforeach
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="pull-right">
                                            Find spaces with
                                            {!! Form::select('facilities_cardinality', ['all' => 'All', 'any' => 'Any'], 'all', ['class' => 'form-control form-control-inline selectpicker no-borders text-uppercase']) !!}
                                            of the selected features.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
        </div>
        <div class="row">
            <div class="search-count">
                <div class="col-sm-4"></div>
                <div class="col-sm-4">
                    <p><span class="text-blue fa fa-circle-o-notch fa-spin" id="search-count-value"></span> SPACES AVAILABLE</p>
                </div>
                <div class="col-sm-4"></div>
            </div>
        </div>
    </div>

    <div class="search-body">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="search-results-section">
                        <div id="search-results-listing">

                        </div>
                        <div>
                            <p class="tt-upper text-center text-weight-400 m-top-50">
                                Can't find your perfect space? We're available now to help.
                                <a href="#">Click Here</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {!! Form::close() !!}
@stop
