@extends('layout')
@include('_partials.host_support_section')

@section('title')
    Details | {{ $space->building->name }} {{ $space->building->street_address_1 }}  | {{ $space->room_name }}
@stop

@section('logo')
    <a class="navbar-brand" href="{{ url('buildings', $space->building->private_slug) }}"><img class="rounded img-responsive" src="{{ $space->building->logoImage[0]->filePath('logo') }}" /></a>
@stop

@section('find-spaces-link')
    <a href="{{ url('buildings', $space->building->private_slug) }}" class="btn btn-clear">Find Spaces</a>
@stop

@section('return-to-portal-link')
    <a class="btn btn-clear-black" href="{{ $space->building->direct_url }}">Return to Portal</a>
@stop

@section('custom-scripts')
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAvASlduDINxD7pO13SZgAU8byCt2LsezY&callback=initMap" async defer></script>
    <script>
        function initMap() {
            {{-- get space address --}}
            var address = '{{ $space->building->street_address_1 }} {{ $space->building->locality->name }} {{ $space->building->region->name }} {{ $space->building->country->name }}';

            {{-- generate map popup --}}
            var infowindow = new google.maps.InfoWindow({
                content: "<p class='text-center tt-upper'><strong>{{ $space->room_name }} ({{ $space->floor->name }})<br /><span class='text-white'>{{ $space->building->name }}<br />{{ $space->building->region->name }} {{ $space->building->postcode }}</span></strong></p>",
                closeBoxURL: "",
                maxWidth: 500
            });

            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 16,
                scrollwheel: false,
                draggable: false,
                clickableIcons: false
            });

            var geocoder = new google.maps.Geocoder();

            geocoder.geocode({
               'address': address
            },
            function(results, status) {
               if(status == google.maps.GeocoderStatus.OK) {
                    var marker = new google.maps.Marker({
                       position: results[0].geometry.location,
                       map: map
                    });
                    map.setCenter(results[0].geometry.location);
                    infowindow.open(map, marker);
               }
            });
        }

        $(document).ready(function () {
            
        
            $(".selectpicker").selectpicker();
            
            {{-- get space booking details --}}
            var authUser = null;
            var dayStartTime = '{{ $space->day_start_time }}';
            var dayDuration = '{{ $space->day_duration }}';
            var afterHoursDuration = '{{ $space->after_hours_duration }}';
            var isAfterHours = '{{ $space->is_available_afterhours }}';
            var startTime = dayStartTime.split(':');
            var maxtime = 0;
            var maxtimeFull = 0;

            {{-- check if user is looged in and if event belongs to the current user --}}
            @if (Auth::check()) 
                authUser = {{ Auth::user()->id }};
            @endif
            
            {{-- get and calculate day duration and after hours --}}
            if (isAfterHours && isAfterHours!=false) {
                //maxtime = parseInt(startTime, 10) + parseInt(dayDuration, 10) + parseInt(afterHoursDuration, 10);
                maxtimeDuration = moment("2016-12-25 "+ dayStartTime).add(dayDuration, 'minutes').add(afterHoursDuration, 'minutes');
            }
            else {
                //var maxtime = parseInt(startTime, 10) + parseInt(dayDuration, 10);
                maxtimeDuration = moment("2016-12-25 "+ dayStartTime).add(dayDuration, 'minutes');
            }

            maxtime = moment(maxtimeDuration).format("HH:mm");
            maxtimeFull = moment(maxtimeDuration).format("HH:mm:ss");
            
            {{-- calendar used for popup (view full calendar) --}}
            
            var hiddenDays = new Array();
            
            @if ($space->is_available_mon=="0") { hiddenDays.push(1); } @endif
            @if ($space->is_available_tue=="0") { hiddenDays.push(2); } @endif
            @if ($space->is_available_wed=="0") { hiddenDays.push(3); } @endif
            @if ($space->is_available_thu=="0") { hiddenDays.push(4); } @endif
            @if ($space->is_available_fri=="0") { hiddenDays.push(5); } @endif
            @if ($space->is_available_sat=="0") { hiddenDays.push(6); } @endif
            @if ($space->is_available_sun=="0") { hiddenDays.push(0); } @endif
            
            {{-- configure booking widget dates --}}
            var today = moment();

            {{-- get allowed booking start date --}}
            var allowedBookingDateFrom = moment(today).add({{ $space->booking_window_min }}, 'minute');
            var dayafterallowedBookingDateFrom = moment(allowedBookingDateFrom).add(1, 'day');
            var formatBookingDateFrom = moment(allowedBookingDateFrom).format("YYYY-MM-DD HH:mm");
            var formatBookingDateFromChunks = formatBookingDateFrom.split(" ");
            var allowedBookingDate = formatBookingDateFromChunks[0];
            var allowedBookingTime = moment(allowedBookingDate+" "+dayStartTime).format("YYYY-MM-DD HH:mm");
            
            {{-- render calendar above on popup --}}
            var getSelectedDate = null;
            
            $("#calendar-modal-button").on("click", function (e) {
                getSelectedDate = $("#date").val(); 
                $('.schedule_view').remove();
                $('.fc-state-highlight').removeClass("fc-today fc-state-highlight");
                $('td .fc-day[data-date="'+getSelectedDate+'"]').addClass('fc-today fc-state-highlight');
            });
            
            $('#calendar-modal').on('shown.bs.modal', function () {
                $("#calendar").fullCalendar('render');
                $('#calendar').fullCalendar('gotoDate', getSelectedDate);
            });
            
            $('#calendar').fullCalendar({
                header: {
                    left: 'prev',
                    center: 'title',
                    right: 'next'
                },
                navLinks: false, 
                editable: false,
                eventLimit: true, 
                height: 550,
                hiddenDays: hiddenDays,
                contentHeight: 'auto',
                defaultDate: getSelectedDate,
                eventStartEditable : false,
                dayClick: function(date, allDay, jsEvent, view) {

                    var dateFormat = "YYYY-MM-DD";
                    var datetimeFormat = "YYYY-MM-DD HH:mm";
                    var timeFormat = "HHmm";
                    var clickedDate = date.format(dateFormat);
                    var i_start = moment(clickedDate+" "+dayStartTime, datetimeFormat).format(timeFormat);
                    var i_end = moment(clickedDate+" "+maxtimeFull, datetimeFormat).subtract(30,'m').format(timeFormat);
                    var d_starttime= moment(clickedDate+" "+dayStartTime, datetimeFormat).format(timeFormat);
                    var d_endtime= moment(clickedDate+" "+maxtimeFull, datetimeFormat).format(timeFormat);
                    var formattedTime = 0;
                    
                    $('.schedule_view').remove();
                    $('.fc-state-highlight').removeClass("fc-today fc-state-highlight");
                    
                    if (clickedDate >= allowedBookingDate) {
                        $(this).addClass("fc-today fc-state-highlight");
                        {{-- generate day view on click --}}
                        $(this).parent().closest('div.fc-row').after("<div class='schedule_view'></div>"); 
                        $('.schedule_view').html('<table id="scheduleGrid"><tr id="dayViewRow1"></tr><tr id="dayViewRow2"></tr></table><ul class="legend m-top-10"><li><span class="available"></span> Available</li><li><span class="unavailable"></span> Unavailable</li></ul>');

                        while (i_start <= i_end) {
                            $("#scheduleGrid tr").each(function(){
                                var trow = $(this);
                                if(trow.index() === 0){
                                    if(i_start==d_starttime) {
                                        formattedTime = moment(i_start, ["HH:mm"]).format("h:mm a");
                                        trow.append('<td class="text-left">'+formattedTime+'</td>');
                                    }
                                    else if(i_start==i_end) {
                                        formattedTime = moment(i_start, ["HH:mm"]).add(30,'m').format("h:mm a");
                                        trow.append('<td class="text-right">'+formattedTime+'</td>');
                                    }
                                    else {
                                        formattedTime = moment(i_start, ["HH:mm"]).format("h:mm");

                                        if(formattedTime.includes("30")) {
                                            formattedTime = "";
                                        }
                                        else {
                                            formattedTime = moment(i_start, ["HH:mm"]).format("h");
                                        }
                                        trow.append('<td class="text-left">'+formattedTime+'</td>');
                                    }
                                }
                                else{
                                    trow.append('<td class="td-'+i_start+' dayViewtd" style="border-left: 2px solid #ffffff"></td>');
                                }
                            });
                            i_start = moment(clickedDate+" "+i_start, datetimeFormat).add(30,'m').format(timeFormat);
                        }

                        $('#calendar').fullCalendar('clientEvents', function(event) {

                            {{-- format moment.js dates --}}
                            var clickedDate = date.format(dateFormat);
                            var startDate = event.start.format(dateFormat);
                            var startTime = event.start.format(timeFormat);
                            var startDateTime = event.start.format(datetimeFormat);
                            var endDate = event.end.format(dateFormat);
                            var endTime = event.end.format(timeFormat);
                            var endDateTime = event.end.format(datetimeFormat);

                            {{-- get only events for the clicked day --}}
                            if (startDate==clickedDate) {
                                while (startTime <= endTime) {
                                    if (authUser) {
                                        $('.td-'+startTime).css('background-color', '#263032');
                                        if (event.bookedById == authUser) {
                                            $('.td-'+startTime).css('background-color', '#263032');
                                        }
                                    }
                                    else {
                                        $('.td-'+startTime).css('background-color', '#263032');
                                    }

                                    startTime = moment(clickedDate+" "+startTime, datetimeFormat).add(30,'m').format(timeFormat);
                                }
                            }

                            if (endDate==clickedDate) {

                                while (startTime <= endTime) {
                                    if (authUser) {
                                        $('.td-'+startTime).css('background-color', '#263032');
                                        if (event.bookedById == authUser) {
                                            $('.td-'+startTime).css('background-color', '#263032');
                                        }
                                    }
                                    else {
                                        $('.td-'+startTime).css('background-color', '#263032');
                                    }

                                    startTime = moment(clickedDate+" "+startTime, datetimeFormat).add(30,'m').format(timeFormat);
                                }
                            }

                            return false;
                        });
                    }
                },
                eventSources: [
                    {
                        url: "/api/public/calendars/spacebookings/"+"{{ $space->id }}"
                    },
                    {
                        url: "/api/public/calendars/blacklist/"+"{{ $space->id }}"
                    }
                ],
                eventRender: function(){
                    $('.fc-state-highlight').removeClass("fc-today fc-state-highlight");
                    $('td .fc-day[data-date="'+getSelectedDate+'"]').addClass('fc-today fc-state-highlight');
                },
                loading: function(isLoading, view) {
                    var viewStart = moment(view.start.format('YYYY-MM-DD')+" "+dayStartTime, 'YYYY-MM-DD HH:mm');
                    var minAllowedBookingDate = moment(allowedBookingDate+" "+dayStartTime, 'YYYY-MM-DD HH:mm');
                    if (viewStart.isBefore(minAllowedBookingDate)) {
                        // Disable the previous button
                        $('#calendar .fc-prev-button').prop('disabled', true);
                        $('#calendar .fc-prev-button').addClass('fc-state-disabled', true);
                    }
                    else {
                        $('#calendar .fc-prev-button').prop('disabled', false);
                        $('#calendar .fc-prev-button').removeClass('fc-state-disabled');
                    }
                },
            });
            
            {{-- used for calendar list (display week) --}}
            $('#calendar-list').fullCalendar({
                header: {
                    left: 'prev',
                    center: 'title',
                    right: 'next'
                },
                defaultView: 'agendaWeek',
                navLinks: false,
                editable: false,
                selectable: true,
                unselectAuto: false,
                selectOverlap: function(event) {
                    return false;
                },
                select: function(start, end, jsEvent, view) {
                    // If this event is triggered by us, return back
                    if (!jsEvent) {
                        return;
                    }

                    // Don't allow anything before allowedBookingDate
                    var minAllowedBookingDate = moment(allowedBookingDate+" "+dayStartTime, 'YYYY-MM-DD HH:mm');
                    if(start.isBefore(minAllowedBookingDate)) {
                        $('#calendar-list').fullCalendar('unselect');
                        alert('The date chosen is not bookable');
                        return false;
                    }

                    var mStart = moment(start);
                    var mEnd = moment(end);

                    if (mStart.isSame(mEnd, 'day')) {
                        // This is an hourly booking
                        $('.nav-tabs a[href="#hourly"]').tab('show');

                        // Set the hourly data
                        $("#date").val(mStart.format('YYYY-MM-DD'));
                        $("#time_from").val(mStart.format('HH:mm'));
                        $("#time_to").val(mEnd.format('HH:mm'));
                        $("#date").validator().trigger('dp.change');
                        $("#paymentFormHourly").validator('validate');
                    }
                    else {
                        // This is a multiday booking
                        $('.nav-tabs a[href="#daily"]').tab('show');

                        var newStart = moment(start.format('YYYY-MM-DD') + ' ' + dayStartTime, 'YYYY-MM-DD HH:mm');
                        var newEnd = moment(end.format('YYYY-MM-DD') + ' ' + dayStartTime, 'YYYY-MM-DD HH:mm').add(dayDuration, 'm');
                        $('#calendar-list').fullCalendar('unselect');
                        $('#calendar-list').fullCalendar('select', newStart, newEnd);
                        $('#date_from').val(newStart.format('YYYY-MM-DD'));
                        $('#date_to').val(newEnd.format('YYYY-MM-DD'));
                        $('#date_from').validator().trigger('dp.change');
                        $("#paymentFormDaily").validator('validate');
                    }
                },
                eventLimit: true,
                allDaySlot: false,
                slotDuration: '00:30:00',
                minTime: dayStartTime,
                maxTime: maxtime,
                columnFormat: 'ddd DD/MM',
                hiddenDays: hiddenDays,
                defaultDate: allowedBookingDate,
                loading: function(isLoading, view) {
                    var viewStart = moment(view.start.format('YYYY-MM-DD')+" "+dayStartTime, 'YYYY-MM-DD HH:mm');
                    var minAllowedBookingDate = moment(allowedBookingDate+" "+dayStartTime, 'YYYY-MM-DD HH:mm');
                    if (viewStart.isBefore(minAllowedBookingDate)) {
                        // Disable the previous button
                        $('#calendar-list .fc-prev-button').prop('disabled', true);
                        $('#calendar-list .fc-prev-button').addClass('fc-state-disabled', true);
                    }
                    else {
                        $('#calendar-list .fc-prev-button').prop('disabled', false);
                        $('#calendar-list .fc-prev-button').removeClass('fc-state-disabled');
                    }
                },
                viewRender: function(view, element) {
                    var slatHeight = $("#calendar-list").find('.fc-slats').height();
                    var height = $('#calendar-list').find('.fc-time-grid-container').height();
                    if(slatHeight < height)
                    {
                        $('#calendar-list').find('.fc-time-grid-container').css('max-height',slatHeight+'px');
                    }
                },
                eventSources: [
                    {
                        url: "/api/public/calendars/spacebookings/"+"{{ $space->id }}"
                    },
                    {
                        url: "/api/public/calendars/blacklist/"+"{{ $space->id }}"
                    }
                ],
                eventAfterRender: function(event, element, view) {
                    if (authUser) {
                        $(element).attr("id","event_id_"+event._id).css('background-color', '#263032');
                        if (event.bookedById == authUser) {
                            $(element).attr("id","event_id_"+event._id).css('background-color', '#263032');
                        }
                    }
                    else {
                        $(element).attr("id","event_id_"+event._id).css('background-color', '#263032');
                    }
                }
            });

            {{-- Hourly Widget --}}
            $('#date').datetimepicker({
                format:'YYYY-MM-DD',
                minDate: allowedBookingDate,
                defaultDate: allowedBookingDate,
                daysOfWeekDisabled: hiddenDays,
                ignoreReadonly: true
            });
 
            $('#time_from').timepicker({
                'disableTextInput': true,
                'timeFormat': 'H:i',
                'show2400': true,
                'step': 30,
                'forceRoundTime': true,
                'minTime': moment(allowedBookingTime).format("H"),
                'maxTime': maxtime,
            });
            
            $('#time_to').timepicker({
                'disableTextInput': true,
                'timeFormat': 'H:i',
                'show2400': true,
                'step': 30,
                'forceRoundTime': true,
                'minTime': moment(allowedBookingTime).format("H"),
                'maxTime': maxtime
            });
            
            $("#time_from").on("change", function (e) {
                if ($('#time_to').val()=="") {
                    $('#time_to').val(moment($("#time_from").val(), 'HH:mm').add(1, 'hour').format("HH:mm"));
                }
            });

            {{-- Daily Widget --}}
            $('#date_from').datetimepicker({
                format:'YYYY-MM-DD',
                minDate: allowedBookingDate,
                defaultDate: allowedBookingDate,
                daysOfWeekDisabled: hiddenDays,
                ignoreReadonly: true
            });
            
            $('#date_to').datetimepicker({
                format:'YYYY-MM-DD',
                useCurrent: false,
                minDate: dayafterallowedBookingDateFrom,
                defaultDate: dayafterallowedBookingDateFrom,
                daysOfWeekDisabled: hiddenDays,
                ignoreReadonly: true
            });
            
            $("#date_from").on("dp.change", function (e) {
                $('#date_to').data("DateTimePicker").minDate(e.date);
            });
            
            $("#date_to").on("dp.change", function (e) {
                $('#date_from').data("DateTimePicker").maxDate(e.date);
            });
            
            $("form").click(function() {
                var formSource = $(this).attr('class');
                var form = $('form.'+formSource);
                var submitButton = form.find(":submit");
                var dangerContainer = $('.alert.alert-danger');

                form.submit(function (e) {
                    e.preventDefault();
                    submitButton.attr({disabled: true});
                    submitButton.html('<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i>');
                    $.ajax({
                        url: $(this).attr('action') || window.location.pathname,
                        type: $(this).attr('method'),
                        data: $(this).serialize(),
                        success: function (data) {
                            if (data.status == "error") {
                                if (typeof data.message == 'string') {
                                    dangerContainer.text(data.message).show();
                                } 
                                else {
                                    dangerContainer.text('').show();
                                    $.each(data.message, function (index, value) {
                                        dangerContainer.append(value + "<br />");
                                    });
                                }
                                submitButton.html('Submit').attr({disabled: false}).show();
                            }
                            else {
                                form.attr('action', $(this).attr('action')).off('submit').submit();
                            }
                        },
                        error: function (data) {
                            dangerContainer.html(data.responseJSON.message).show();
                            submitButton.html('Submit').attr({disabled: false}).show();
                        }
                    });
                });
            });

            
            $.ajax({
                url: '/api/rates/minimum/'+'{{ $space->id }}',
                type: 'get',
                dataType: 'json',
                success: function (data) {
                    $('#minimum_rate_hour').html("<span class='text-large'>$"+data.maxHourPrice+"</span> Hour");
                    $('#minimum_rate_halfday').html("<span class='text-large'>$"+data.maxHalfDayPrice+"</span> Half day");
                    $('#minimum_rate_day').html("<span class='text-large'>$"+data.maxFullDayPrice+"</span> Full day");
                    $('#minimum_rate_month').html("<span class='text-large'>$"+data.maxMonthPrice+"</span> Month");
                },
            });

            $("#time_from").on("dp.change", function (e) {
                $('#time_to').data("DateTimePicker").minDate(moment(e.date).add(1, 'hour'));
            });

            $("#date, #time_from, #time_to").on('change dp.change', function() {
                var startTime = $('#date').val()+" "+$('#time_from').val()+":00";
                var endTime = $('#date').val()+" "+$('#time_to').val()+":00";
                $('#calendar-list').fullCalendar('select', startTime, endTime);
            });

            $("#date_from, #date_to").on('change dp.change', function() {
                var start = moment($('#date_from').val() + ' ' + '{{ $space->day_start_time }}', 'YYYY-MM-DD HH:mm');
                var end = moment($('#date_to').val() + ' ' + '{{ $space->day_start_time }}', 'YYYY-MM-DD HH:mm').add(dayDuration, 'm');
                $('#calendar-list').fullCalendar('select', start, end);
            });

            $("#date").on("dp.change", function (e) {
                $('#calendar-list').fullCalendar('gotoDate', $('#date').val());
            });

            $('#date, .num_attendees_hourly, #time_from, #time_to').on('change dp.change', function() {
                $('.dayView').html('');
                
                var data = {
                    "_token": "{{ csrf_token() }}",
                    "date": $('#date').val(),
                    "num_attendees": $('.num_attendees_hourly').val(),
                    "time_from": $('#date').val()+" "+$('#time_from').val()+":00",
                    "time_to": $('#date').val()+" "+$('#time_to').val()+":00"
                };

                $.ajax({
                    url: '/api/booking/hourly/'+'{{ $space->id }}',
                    type: 'post',
                    dataType: 'json',
                    data: data,
                    success: function (data) {
                        if (data.error) {
                            $('#hourly .alert-danger').html(data.error).show();
                            $('#submitHourly').attr({disabled: true});
                        }
                        else {
                            $('#submitHourly').attr({disabled: false});
                            $('#hourly .alert-danger').html('').hide();
                            $('#rateDay').html('');
                            $('#rateAfterHours').html('');

                            if (data.hourlyTotalCost!="0.00") {
                                $('#rateHour').html('<span id="hours">'+data.totalHours+'</span> '+(data.totalHours=="1" ? "Hour" : "Hours")+'<span class="pull-right">$'+data.hourlyTotalCost+'</span>');
                            }
                            else if (data.dayTotalCost!="0.00") {
                                $('#rateHour').html('<span id="hours">'+data.totalHours+'</span> '+(data.totalHours=="1" ? "Hour" : "Hours")+'<span class="pull-right">$'+data.dayTotalCost+'</span>');
                            } 
                            else if (data.halfDayTotalCost!="0.00") {
                                $('#rateHour').html('<span id="hours">'+data.totalHours+'</span> '+(data.totalHours=="1" ? "Hour" : "Hours")+'<span class="pull-right">$'+data.halfDayTotalCost+'</span>');
                            }
                            
                            @if ($space->is_available_afterhours)
                                if (data.afterHoursTotalCost!="0.00") {
                                    $('#rateAfterHours').html('<span id="hours">'+data.totalAfterHoursHours+'</span> '+(data.totalAfterHoursHours=="1" ? "After Hour" : "After Hours")+'<span class="pull-right">$'+data.afterHoursTotalCost+'</span>');
                                }
                            @endif
                            
                            $('#total_rate_hourly').html('$'+data.totalCost);
                        }
                    },
                    error: function(data){
                        var error = JSON.parse(data.responseText);

                        $('#hourly .alert-danger').html(error.message).show();
                        $('#submitHourly').attr({disabled: true});

                    }
                });
            });
            
            $('.num_attendees_daily, #date_from, #date_to').on('change dp.change', function() {
                var data = {
                    "_token": "{{ csrf_token() }}",
                    "num_attendees": $('.num_attendees_daily').val(),
                    "date_from": $('#date_from').val(),
                    "date_to": $('#date_to').val()
                };

                $.ajax({
                    url: '/api/booking/daily/'+'{{ $space->id }}',
                    type: 'post',
                    dataType: 'json',
                    data: data,
                    success: function (data) {
                        if (data.error) {
                            $('#daily .alert-danger').html(data.error).show();
                            $('#submitDaily').attr({disabled: true});
                        }
                        else {
                            $('#submitDaily').attr({disabled: false});
                            $('#daily .alert-danger').html('').hide();
                            $('#rateDay').html('');
                            $('#rateMonth').html('');
                            
                            if (data.dayTotalCost!="0.00") {
                                $('#rateDay').html('<span id="days">'+data.totalDays+'</span> '+(data.totalDays=="1" ? "Day" : "Days")+'<span id="rateDay"><span class="pull-right">$'+data.dayTotalCost+'</span></span>');
                            } 
                            
                            if (data.monthTotalCost!="0.00") {
                                $('#rateMonth').html('<span id="months">'+data.totalMonths+'</span> '+(data.totalMonths=="1" ? "Month" : "Months")+'<span id="rateMonth"><span class="pull-right">$'+data.monthTotalCost+'</span></span>');
                            }
                            
                            $('#total_rate_daily_day').html("$"+data.dayTotalCost);
                            $('#total_rate_daily_month').html("$"+data.monthTotalCost); 
                            $('#total_rate_daily').html('$'+data.totalCost+'</span>');
                        }
                    },
                    error: function(data){
                        var error = JSON.parse(data.responseText);

                        $('#daily .alert-danger').html(error.message).show();
                        $('#submitDaily').attr({disabled: true});
                    }
                });
            });
            
            //Carousel
            $(".carousel-inner div").first().addClass("active");

            //trigger the pricing if values have been set from search screen
            if($("#time_from").val() != "" && $("#time_to").val() != "")
            {
                $("#time_from").trigger("change");
            }
            
            if($("#date_from").val() != "" && $("#date_to").val() != "")
            {
                $("#date_to").trigger("dp.change");
            }


        });
      
    </script>
    @yield('message-form-script')
@stop

@section('content')
    @include('_partials.hero_carousel')
    
    <div class="container space-detail">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="location-details">
                        From: 
                        @if ($space->pricing_hourly_enabled)<span class="m-left-40" id="minimum_rate_hour"></span>@endif
                        @if ($space->pricing_halfdaily_enabled)<span class="m-left-40" id="minimum_rate_halfday"></span>@endif
                        @if ($space->pricing_daily_enabled)<span class="m-left-40" id="minimum_rate_day"></span>@endif
                        @if ($space->pricing_monthly_enabled)<span class="m-left-40" id="minimum_rate_month"></span>@endif
                        @if ($space->is_available_afterhours)
                            <span class="m-left-40"><i class="fa fa-clock-o" aria-hidden="true"></i> After hours rates apply</span>
                        @endif
                        <span class="text-large m-left-40"><i class="fa fa-user" aria-hidden="true"></i></span> {{ $space->max_capacity }} Room Capacity
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-11">
                        <p class="inline-links m-top-50"><span class="detail-jump-navigation">JUMP TO: </span>
                            <a href="#availability" class="m-left-10 text-dark-blue">AVAILABILITY</a>
                            <span class="m-left-10"> | </span><a href="#features" class="m-left-10 text-dark-blue">FEATURES</a>
                            @if($space->description)<span class="m-left-10" class="m-left-10"> | </span><a href="#about" class="m-left-10 text-dark-blue">ABOUT</a>@endif 
                            @if($space->building->other_services)<span class="m-left-10"> | </span><a href="#other_services" class="m-left-10 text-dark-blue">OTHER SERVICES</a>@endif
                            @if($space->terms)<span class="m-left-10" class="m-left-10"> | </span><a href="#terms" class="m-left-10 text-dark-blue">TERMS AND CONDITIONS</a>@endif 
                            <span class="m-left-10"> | </span><a href="#map" class="m-left-10 text-dark-blue">MAP</a>
                        </p>
                        <hr />
                        <div class="row">
                            <a name="availability"></a>
                            <div class="col-md-3 detail-heading">AVAILABILITY</div>
                            <div class="col-md-9">
                                <div id='calendar-list'></div>
                                <ul class="legend m-top-20">
                                    <li><span class="available"></span> Available</li>
                                    <li><span class="unavailable"></span> Unavailable</li>
                                    <li><span class="yourtime"></span> Selected Time</li>
                                </ul>
                                <p class="m-top-10"><span class="pull-right"><a href="#"  data-toggle="modal" data-target="#calendar-modal" id="calendar-modal-button">VIEW FULL CALENDAR</a></span></p>
                            </div>
                        </div>
                        <hr />
                        <div class="row">
                            <a name="features"></a>
                            <div class="col-md-3 detail-heading">FEATURES</div>
                            <div class="col-md-9">
                                <div class="row">
                                    @foreach ($space->spacefacilities as $spacefacility)
                                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 space-facility-section">
                                            <p class="space-facility-icons"><i class="{{ $spacefacility['icon_style'] }} text-dark-blue" aria-hidden="true"></i> &nbsp;{{ $spacefacility['name'] }}</p>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                        @if($space->description)
                            <hr />
                            <div class="row">
                                <a name="about"></a>
                                <div class="col-md-12">
                                    <p>ABOUT</p>
                                    <p class="m-top-20">{!! $space->description !!}</p>
                                </div>
                            </div>
                        @endif
                        
                        @if($space->building->other_services)
                            <hr />
                            <div class="row">
                                <a name="other_services"></a>
                                <div class="col-md-12">
                                    <p>OTHER SERVICES</p>
                                    <p class="m-top-20">{!! $space->building->other_services !!}</p>
                                </div>
                            </div>
                        @endif
                        
                        @if($space->terms)
                            <hr />
                            <div class="row">
                                <a name="terms"></a>
                                <div class="col-md-12">
                                    <p>TERMS AND CONDITIONS</p>
                                    <a href="#" type="button" class="" data-toggle="modal" data-target="#termsModal">
                                        View Terms and Conditions
                                    </a>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                @yield('message-host-cta')

                <div class="row booking-section  m-top-20">
                    <ul class="nav nav-tabs">
                        @if ($space->pricing_hourly_enabled || $space->pricing_halfdaily_enabled)
                            <li role="presentation" class="{{ ($urlData['duration'] == 'pricing_hourly' || $urlData['duration'] == null) ? 'active'  : ''}}"><a href="#hourly" data-toggle="tab" aria-expanded="{{ ($urlData['duration'] == 'pricing_hourly' || $urlData['duration'] == null) ? true  : false}}"> Hourly</a></li>
                        @endif
                        @if ($space->pricing_daily_enabled || $space->pricing_monthly_enabled)
                            <li class="{{ ($urlData['duration'] != 'pricing_hourly' && $urlData['duration'] != null) ? 'active'  : ''}}"><a href="#daily" data-toggle="tab" aria-expanded="{{ ($urlData['duration'] != 'pricing_hourly' && $urlData['duration'] != null) ? true  : false}}"> Daily</a></li>
                        @endif
                    </ul>
                    
                    <div class="tab-content">
                        @if ($space->pricing_hourly_enabled || $space->pricing_halfdaily_enabled)
                            <div class="tab-pane {{ ($urlData['duration'] == 'pricing_hourly' || $urlData['duration'] == null) ? 'active'  : ''}} form-wrapper" id="hourly">
                                <div class="alert alert-danger alert-light collapse"></div>
                                {!! Form::open(['route' => ['payment', 'building_private_slug' => $space->building->private_slug, 'space_private_slug' => $space->private_slug], 'method' => 'post', 'id' => 'paymentFormHourly', 'name' => 'paymentFormHourly', 'class' => 'paymentFormHourly', 'data-toggle' => 'validator', 'role' => 'form']) !!}
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {!! Form::label('date', 'Date') !!}
                                                {!! Form::text('date', $urlData['start_date'], ['class' => 'form-control', 'id' => 'date', 'required', 'readonly' => 'readonly' ]) !!}
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {!! Form::label('num_attendees', 'People') !!}
                                                {!! Form::number('num_attendees', ($urlData['people']) ? $urlData['people'] : '' , ['class' => 'form-control num_attendees_hourly', 'placeholder' => 'e.g. 10', 'required', 'min' => '1', 'max' => $getMaxAttendees]) !!}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="dayView"></div>
                                   
                                    <div class="row m-top-10">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {!! Form::label('time_from', 'From') !!}
                                                {!! Form::text('time_from', $urlData['start_time'], ['id' => 'time_from', 'placeholder' => 'from time', 'class' => 'form-control', 'required']) !!}
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {!! Form::label('time_to', 'To') !!}
                                                {!! Form::text('time_to', $urlData['end_time'], ['id' => 'time_to', 'placeholder' => 'to time', 'class' => 'form-control', 'required']) !!}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row m-top-20">
                                        <div class="col-md-12">
                                            <p id="rateHour"></p>
                                            <p id="rateAfterHours"></p>
                                            <hr />
                                            <p>Total <span class="pull-right" id="total_rate_hourly">$0.00</span></p>
                                            <hr />
                                            <p id="disclaimer">
                                                <small>
                                                    The minimum charge increment is 
                                                    <span id="disclaimer_increment">
                                                        @if ($space->pricing_hourly_enabled)
                                                            1 Hour.
                                                        @elseif ($space->pricing_halfdaily_enabled)
                                                            Half Day.
                                                        @elseif ($space->pricing_daily_enabled)
                                                            Full Day.
                                                        @elseif ($space->pricing_monthly_enabled)
                                                            Monthly.
                                                        @endif
                                                    </span>
                                                </small>
                                            </p>
                                            <p class="m-top-10">
                                                {!! Form::hidden('widgetSource', 'hourly') !!}
                                                {!! Form::submit('Book Online', ["class" => "btn btn-dark-blue", "id" => "submitHourly"]) !!}
                                            </p>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                        @endif
                        @if ($space->pricing_daily_enabled || $space->pricing_monthly_enabled)
                            @if ($space->pricing_hourly_enabled || $space->pricing_halfdaily_enabled)
                                <div class="tab-pane {{ ($urlData['duration'] != 'pricing_hourly' && $urlData['duration'] != null) ? 'active'  : ''}} form-wrapper" id="daily">
                            @else
                                <div class="tab-pane active form-wrapper" id="daily">
                            @endif
                                <div class="alert alert-danger alert-light collapse"></div>
                                {!! Form::open(['route' => ['payment', 'building_private_slug' => $space->building->private_slug, 'space_private_slug' => $space->private_slug], 'method' => 'post', 'id' => 'paymentFormDaily', 'name' => 'paymentFormDaily', 'class' => 'paymentFormDaily', 'data-toggle' => 'validator']) !!}
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {!! Form::label('date_from', 'Date from') !!}
                                                {!! Form::text('date_from', $urlData['start_date'], ['class' => 'form-control', 'id' => 'date_from', 'required', 'readonly' => 'readonly']) !!}
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                {!! Form::label('date_to', 'to') !!}
                                                {!! Form::text('date_to', $urlData['end_date'], ['class' => 'form-control', 'id' => 'date_to', 'required', 'readonly' => 'readonly']) !!}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row m-top-20">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                {!! Form::label('num_attendees', 'People') !!}
                                                {!! Form::number('num_attendees', ($urlData['people']) ? $urlData['people'] : '', ['class' => 'form-control num_attendees_daily', 'placeholder' => 'e.g. 10', 'required', 'min' => '1', 'max' => $getMaxAttendees]) !!}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row m-top-20">
                                        <div class="col-md-12">
                                            
                                            <p id="rateDay"></p>
                                            <p id="rateMonth"></p>
                                            <hr />
                                            <p>Total <span id="days"></span> <span class="pull-right" id="total_rate_daily">$0.00</span></p>
                                            {{--
                                            <p class="m-top-20">
                                                <button class="btn btn-black" href="#">View Additional Services</button>
                                            </p>
                                            --}}
                                            <hr />
                                            <p id="disclaimer">
                                                <small>
                                                    The minimum charge increment is 
                                                    <span id="disclaimer_increment">
                                                        @if ($space->pricing_daily_enabled)
                                                            Full Day.
                                                        @elseif ($space->pricing_monthly_enabled)
                                                            Monthly.
                                                        @endif
                                                    </span>
                                                </small>
                                            </p>
                                            <p class="m-top-10">
                                                {!! Form::hidden('widgetSource', 'daily') !!}
                                                {!! Form::submit('Book Online', ["class" => "btn btn-dark-blue", "id" => "submitDaily"]) !!}
                                            </p>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <a name="map"></a>
    
    <div class="m-top-50">
        <div id="map"></div>
    </div>

    @if($space->terms)
        <div class="modal fade" id="termsModal" tabindex="-1" role="dialog" aria-labelledby="termsModalLabel">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="termsModalLabel">TERMS AND CONDITIONS</h4>
                    </div>
                    <div class="modal-body">
                        <p class="m-top-20">{!! $space->terms !!}</p>
                    </div>
                </div>
            </div>
        </div>
    @endif

    <div class="modal fade" id="calendar-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="closeButton"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fa fa-times" aria-hidden="true"></i> Close</span></button></div>
                <div id='calendar'></div>
            </div>
        </div>
    </div>

    @yield('message-host-modal')

@stop
