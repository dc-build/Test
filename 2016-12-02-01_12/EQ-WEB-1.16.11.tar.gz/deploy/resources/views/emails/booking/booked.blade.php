@extends('emails.layout')

@section('title')
    Booking Confirmation
@stop

@section('custom-css')

@stop

@section('custom-scripts')

@stop

@section('content')

    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 0 15px 0 15px;" class="section-padding">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="500">
                <tr>
                    <td align="center" valign="top" width="500">
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 733px;" class="responsive-table">
                <tr>
                    <td>
                        <!-- HERO IMAGE -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td>
                                    <!-- COPY -->
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td style="padding: 10px 0 15px 0; font-size: 14px; line-height: 24px; font-family: Helvetica, Arial, sans-serif; color: #606060;" class="padding-copy">
                                                <p>Dear {{ $booking->users->full_name }},</p>
                                                <p>You recently made the following booking online:</p>
                                                <p>
                                                    <strong>Space: </strong> {{ $booking->spaces->room_name }}, {{ $booking->spaces->building->display_name }} <br/>
                                                    <?php
                                                    $dateTimeFormat = 'Y-m-d H:i:s';
                                                    $start = \Carbon\Carbon::createFromFormat($dateTimeFormat, $booking->start_datetime);
                                                    $end = \Carbon\Carbon::createFromFormat($dateTimeFormat, $booking->end_datetime);
                                                    ?>
                                                    <strong>From Date: </strong> {{ $start->formatLocalized('%A, %d %B %Y') }} <br/>
                                                    <strong>To Date: </strong> {{ $end->formatLocalized('%A, %d %B %Y') }}
                                                </p>
                                                <p>
                                                    <strong>User: </strong> {{ $booking->users->full_name }} <br/>
                                                    <strong>Email: </strong> {{ $booking->users->email }} <br/>
                                                </p>
                                                <p>
                                                    <strong>Total Boooking Fee: </strong> {{ sprintf("$%.2f", $booking->total_price) }} <br/>
                                                    <!-- TODO: Get real Security deposit -->
                                                    <strong>Security deposit: </strong> {{ sprintf("$%.2f", 0) }} <br/>
                                                    <strong>Payment arrangement</strong> {{ $booking->payment_type }} <br/>
                                                </p>
                                                <!-- TODO: Add view booking details URL -->
                                                <p>
                                                    View <a href="">booking details</a>
                                                </p>
                                                <p>
                                                    You can message the host from the booking page
                                                </p>
                                            </td>
                                        </tr>
                                    </table>

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>

@stop





