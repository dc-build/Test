@extends('emails.layout')

@section('title')
    Message to space host
@stop

@section('custom-css')

@stop

@section('custom-scripts')

@stop

@section('content')

    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 0 15px 0 15px;" class="section-padding">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="500">
                <tr>
                    <td align="center" valign="top" width="500">
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 733px;" class="responsive-table">
                <tr>
                    <td>
                        <!-- HERO IMAGE -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td>
                                    <!-- COPY -->
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td style="padding: 10px 0 15px 0; font-size: 14px; line-height: 24px; font-family: Helvetica, Arial, sans-serif; color: #606060;" class="padding-copy">
                                                <p>Dear {{ $booking->users->full_name }},</p>
                                                <p>For your records you sent the following message to:</p>
                                                <p>
                                                    <strong>Space host: </strong> {{ $booking->spaces->host->contact_name }}
                                                </p>
                                                <p>
                                                    <strong>Message:</strong>
                                                </p>
                                                <p>{{ $message }}</p>
                                            </td>
                                        </tr>
                                    </table>

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>

@stop





