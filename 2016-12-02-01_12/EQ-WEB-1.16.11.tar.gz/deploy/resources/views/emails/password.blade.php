<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h3>Password Reset Request</h3>

<p>A request has been made to reset your password. If you did not request a password reset, you can safely ignore this email - nothing will be changed.</p>

<p>If you did request this password change, please <a href="{{ url('password/reset/'.$token) }}">click here.</a> or copy and paste the following address into your web browser.</p>

<p>{{ url('password/reset/'.$token) }}</p>

</body>
</html>