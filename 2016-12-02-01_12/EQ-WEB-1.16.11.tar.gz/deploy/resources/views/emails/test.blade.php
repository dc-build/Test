@extends('emails.layout')

@section('title')
    User Cancelled Booking
@stop

@section('custom-css')

@stop

@section('custom-scripts')

@stop

@section('content')

    <tr>
        <td bgcolor="#00b5c5" align="center" style="padding: 0 15px 0 15px;" class="section-padding">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="500">
                <tr>
                    <td align="center" valign="top" width="500">
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 733px;" class="responsive-table">
                <tr>
                    <td>
                        <!-- HERO IMAGE -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td>
                                    <!-- COPY -->
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">

                                        <tr>
                                            <td style="text-align:center;padding: 20px 0 10px 0; font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #ffffff;" class="padding-copy">
                                                <p style="font-size: 50px;margin:20px 0">TEST EMAIL</p>
                                            </td>
                                        </tr>
                                    </table>

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 0 15px 0 15px;" class="section-padding">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="500">
                <tr>
                    <td align="center" valign="top" width="500">
            <![endif]-->
            <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 733px;" class="responsive-table">
                <tr>
                    <td>
                        <!-- HERO IMAGE -->
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr>
                                <td>
                                    <!-- COPY -->
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td style="padding: 10px 0 15px 0; font-size: 14px; line-height: 24px; font-family: Helvetica, Arial, sans-serif; color: #606060;" class="padding-copy">
                                                <p>Dear {{ $user->first_name }},</p>
                                                <p>The following is a test email.</p>
                                                <p>
                                                    <strong>Last Name: </strong> {{ $user->last_name }} <br/>
                                                    <strong>Email: </strong> {{ $user->email }} <br/>
                                                </p>
                                                <p>View <a href="http://google.com">links</a></p>
                                            </td>
                                        </tr>
                                    </table>

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>

@stop





