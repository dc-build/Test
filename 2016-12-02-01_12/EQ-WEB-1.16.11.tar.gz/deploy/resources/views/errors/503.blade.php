@extends('layout')

@section('title')
   Service Temporarily Unavailable
@stop

@section('custom-scripts')
    <script>
        $("footer").hide();
        $(".navbar").hide();
    </script>
@stop

@section('content')
    <div class="page-hero-wrapper bg-home">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p>Service Temporarily Unavailable</p>
                </div>
            </div>
        </div>
    </div>

    <div class="search-body">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center text-large">Oops! The service you requested in not available. Please try again later.</p>
                </div>
            </div>
        </div>
    </div>
@stop
