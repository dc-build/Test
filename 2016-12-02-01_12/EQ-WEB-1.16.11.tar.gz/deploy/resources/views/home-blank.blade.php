<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Workabout Spaces">
    <meta name="author" content="Digital Carpenter Pty Ltd">

    <title>Workabout Spaces</title>
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}" type="image/x-icon" />
    <link rel="icon" href="{{ asset('favicon.ico') }}" type="image/x-icon" />


    <!-- build:css(public) /css/style.min.css -->
    <!-- bower:css -->
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-select/dist/css/bootstrap-select.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/fullcalendar/dist/fullcalendar.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-css-only/css/bootstrap.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/datatables.net-bs/css/dataTables.bootstrap.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/datatables.net-responsive-bs/css/responsive.bootstrap.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-toggle/css/bootstrap-toggle.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/related-selects/css/related-selects.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-combobox-blur/css/bootstrap-combobox.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap3-dialog/dist/css/bootstrap-dialog.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('/bower_components/multiselect/css/multi-select.css') }}" />
    <!-- endbower -->
    <link rel="stylesheet" href="{{ asset('/bower_components/jquery-ui/themes/base/jquery-ui.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}?d={{time()}}" type='text/css'>
    <!-- endbuild -->

    <style>
        div.middle
        {
            margin: 150px auto 0;
            width: 400px;

        }

        h1
        {
            text-align: center;
            padding: 12px;
            border: 1px solid #999;
        }
    </style>
</head>
    <body>

        <div class="middle">
            <h1>
                WORKABOUT SPACES
            </h1>
        </div>
    </body>
</html>