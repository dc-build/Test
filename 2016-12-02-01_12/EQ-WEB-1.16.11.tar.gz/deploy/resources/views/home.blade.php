@extends('layout')

@section('title')
    Home
@stop

@section('custom-scripts')
    <script>
        $(function () {

            var buildingTempl = '\
            <div class="panel panel-default">\
                <div class="panel-body">\
                    <div class="row">\
                        <div class="col-sm-4"><img class="rounded img-responsive" src="/images/uploads/{header_image}.{header_image_ext}" /></div>\
                        <div class="col-sm-8">\
                            <h1>{name} <span class="pull-right"></h1>\
                            <p class="text-light-gray"><i class="fa fa-map-marker" aria-hidden="true"></i> {locality}, {region}, {country}</p>\
                            <hr />\
                            <div class="row">\
                                <div class="col-md-4"><img src="/images/uploads/{logo_image}.{logo_image_ext}" /></div>\
                                <div class="col-md-4"><a class="btn btn-blue rounded" href="/buildings/{slug}">View</a></div>\
                            </div>\
                        </div>\
                    </div>\
                </div>\
            </div>\
            ';

            var buildingTranslations = {
                logo_image: 'logo_image.0.image_uuid',
                logo_image_ext: 'logo_image.0.file_ext',
                header_image: 'header_image.0.image_uuid',
                header_image_ext: 'header_image.0.file_ext',
                name: 'name',
                slug: 'private_slug',
                country: 'country.nicename',
                region: 'region.name',
                locality: 'locality.name'
            };


            $.ajax('/buildings', {
                success: function (data) {
                    $.each(data, function(idx, item) {
                        addBuilding($('.search-results-section'), item);
                    });
                },
                error: function () {
                    $('.search-results-section').append(
                        $('<div class="alert alert-danger alert-light">').text(
                            'No Buildings found'
                        )
                    )
                }
            });

            function addBuilding(container, data) {
                var building = $.fn.parseTempl(buildingTempl, buildingTranslations, data);
                container.append($(building));
            }

        });
    </script>
@stop

@section('content')
    <div class="page-hero-wrapper bg-home">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p>Buildings</p>
                </div>
            </div>
        </div>
    </div>

    <div class="search-body">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="search-results-section">

                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
