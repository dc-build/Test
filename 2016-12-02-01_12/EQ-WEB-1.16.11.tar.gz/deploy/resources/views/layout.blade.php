<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Workabout Spaces">
        <meta name="author" content="Digital Carpenter Pty Ltd">
        
        <title>@yield('title', '')</title>  
        <link rel="shortcut icon" href="{{ asset('favicon.ico') }}" type="image/x-icon" />
        <link rel="icon" href="{{ asset('favicon.ico') }}" type="image/x-icon" />

        @yield('custom-css-before')

        <!-- build:css(public) /css/style.min.css -->
        <!-- bower:css -->
        <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-select/dist/css/bootstrap-select.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/fullcalendar/dist/fullcalendar.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-css-only/css/bootstrap.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/datatables.net-bs/css/dataTables.bootstrap.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/datatables.net-responsive-bs/css/responsive.bootstrap.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-toggle/css/bootstrap-toggle.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/related-selects/css/related-selects.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap-combobox-blur/css/bootstrap-combobox.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/bootstrap3-dialog/dist/css/bootstrap-dialog.min.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/multiselect/css/multi-select.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/lightbox2/dist/css/lightbox.css') }}" />
        <link rel="stylesheet" href="{{ asset('/bower_components/jt.timepicker/jquery.timepicker.css') }}" />
        <!-- endbower -->
        <link rel="stylesheet" href="{{ asset('/bower_components/jquery-ui/themes/base/jquery-ui.min.css') }}">
        <link rel="stylesheet" href="{{ asset('css/style.css') }}?d={{time()}}" type='text/css'>
        <!-- endbuild -->

        @yield('custom-css')

    </head>
    <body>
        
    <!-- HEADER -->
    <nav class="navbar navbar-inverse">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                @yield('logo', '')

            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <div class="navbar-form navbar-right">

                    @yield('find-spaces-link', '')

                    @if (Auth0::getUser())
                        <a class="btn btn-clear-blue" href="{{ route('logout') }}">Logout</a>
                        @if(isset($building) || isset($space))
                            <a class="btn btn-clear-black" href="{{ route('my.bookings') }}">My Bookings</a>
                        @endif
                    @else
                        {{--<div class="form-control"><a href="#" data-toggle="modal" data-target="#login-modal">Login</a></div>--}}
                        <button class="btn btn-clear-blue" onclick="lock.show();">Login</button>
                    @endif
                    
                    @yield('return-to-portal-link', '')

                </div>
                       
            </div><!--/.navbar-collapse -->
        </div>
    </nav>

    <!-- CONTENT -->
    @yield('content')
    
    {{--@include('_partials.modal_login')--}}
    {{--@include('_partials.modal_password_reset')--}}
    @include('_partials.modal_error')

    <!-- FOOTER -->
    <footer class="footer text-center">
        <div class="footer-inner">
            <div class="footer-container">
            <p class="title tt-upper">Sign up for updates on new spaces</p>
            <p class="description m-top-20">New listings, special offers, straight to your inbox</p>
            <div class="input-group m-top-20">
                <input type="text" class="form-control form-control-input-group" placeholder="Email">
                <span class="input-group-btn">
                  <button class="btn btn-blue" type="button">Subscribe</button>
                </span>
            </div>
            </div>
        </div>
    </footer>
    
    <!-- build:js(public) /js/app.min.js -->
    <!-- bower:js -->
    <script src="{{ asset('/bower_components/jquery/dist/jquery.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrap/dist/js/bootstrap.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrap-select/dist/js/bootstrap-select.js') }}"></script>
    <script src="{{ asset('/bower_components/underscore/underscore.js') }}"></script>
    <script src="{{ asset('/bower_components/underscore.string/dist/underscore.string.js') }}"></script>
    <script src="{{ asset('/bower_components/sprintf/src/sprintf.js') }}"></script>
    <script src="{{ asset('/bower_components/moment/moment.js') }}"></script>
    <script src="{{ asset('/bower_components/fullcalendar/dist/fullcalendar.js') }}"></script>
    <script src="{{ asset('/bower_components/jquery-ui/jquery-ui.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrap3-ie10-viewport-bug-workaround/ie10-viewport-bug-workaround.js') }}"></script>
    <script src="{{ asset('/bower_components/datatables.net/js/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('/bower_components/datatables.net-responsive/js/dataTables.responsive.js') }}"></script>
    <script src="{{ asset('/bower_components/datatables.net-bs/js/dataTables.bootstrap.js') }}"></script>
    <script src="{{ asset('/bower_components/datatables.net-responsive-bs/js/responsive.bootstrap.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrapck4-skin/ckeditor.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrap-toggle/js/bootstrap-toggle.min.js') }}"></script>
    <script src="{{ asset('/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrap-validator/dist/validator.js') }}"></script>
    <script src="{{ asset('/bower_components/related-selects/js/related-selects.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrap-combobox-blur/js/bootstrap-combobox.js') }}"></script>
    <script src="{{ asset('/bower_components/bootstrap3-dialog/dist/js/bootstrap-dialog.min.js') }}"></script>
    <script src="{{ asset('/bower_components/multiselect/js/jquery.multi-select.js') }}"></script>
    <script src="{{ asset('/bower_components/js-cookie/src/js.cookie.js') }}"></script>
    <script src="{{ asset('/bower_components/js-storage/js.storage.js') }}"></script>
    <script src="{{ asset('/bower_components/lightbox2/dist/js/lightbox.js') }}"></script>
    <script src="{{ asset('/bower_components/jt.timepicker/jquery.timepicker.js') }}"></script>
    <!-- endbower -->
    <script src="{{ asset('/js/vendor/dc/utils.js') }}"></script>
    <script src="{{ asset('/js/vendor/dc/template.js') }}"></script>
    <!-- endbuild -->

    <script src="https://cdn.auth0.com/js/lock/10.0/lock.min.js"></script>
    <script type="text/javascript">
        @if(!Auth::check())
            var lock = new Auth0Lock('{{ env("AUTH0_CLIENT_ID") }}', '{{ env("AUTH0_DOMAIN") }}', {
                auth: {
                    redirectUrl: '{{ route("auth0.callback") }}',
                    responseType: 'code',
                    params: { 
                      scope: 'openid email' // Learn about scopes: https://auth0.com/docs/scopes
                    }
                },
                theme: {
                    logo: "",
                    primaryColor: '#19ace2'
                },
                languageDictionary: {
                    title: "To book a space you will need to Login or Sign up for an account"
                },
                additionalSignUpFields: [
                    {
                        name: "mobile_number",
                        placeholder: "your mobile number",
                        icon: '{{ asset("images/icons/login_mobile.png") }}',
                        validator: function(mobile_number) {
                            return {
                               valid: mobile_number.length = 10,
                               hint: "Must be your 10-digit mobile number (e.g. 0412345678)"
                            };
                        }
                    },
                    {
                        name: "first_name",
                        placeholder: "your first name"
                    },
                    {
                        name: "last_name",
                        placeholder: "your last name"
                    }
                ]
            });
        @endif
        
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
            $('[rel="tooltip"]').tooltip();
            
        });
        @if(Session::has('auth_error'))
            $('#error-modal').modal('show');
        @endif
        
        lightbox.option({
            'resizeDuration': 200,
            'wrapAround': true,
            'showImageNumberLabel': false,
            'alwaysShowNavOnTouchDevices': true
        })
        
    </script>
    @if (env('SHOW_FEEDBACK', false))
        <script type="text/javascript" src="https://digitalcarpenter.atlassian.net/s/d41d8cd98f00b204e9800998ecf8427e-T/y5xx7a/100018/c/1000.0.11/_/download/batch/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector/com.atlassian.jira.collector.plugin.jira-issue-collector-plugin:issuecollector.js?locale=en-US&collectorId=65a0386a"></script>
    @endif

    @yield('custom-scripts')
</body>
</html>
