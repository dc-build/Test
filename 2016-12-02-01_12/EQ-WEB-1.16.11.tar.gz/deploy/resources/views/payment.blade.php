@extends('layout')
@include('_partials.host_support_section')

@section('title')
    Payment | {{ $space->building->name }} {{ $space->building->street_address_1 }}  | {{ $space->room_name }}
@stop

@section('logo')
    <a class="navbar-brand" href="{{ url('buildings', $space->building->private_slug) }}"><img class="rounded img-responsive" src="{{ $space->building->logoImage[0]->filePath('logo') }}" /></a>
@stop

@section('find-spaces-link')
    <a href="{{ url('buildings', $space->building->private_slug) }}" class="btn btn-clear">Find Spaces</a>
@stop

@section('return-to-portal-link')
    <a class="btn btn-clear-black" href="{{ $space->building->direct_url }}">Return to Portal</a>
@stop

@section('custom-scripts')
    <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
    <script>
        $(document).ready(function () {
            $(".selectpicker").selectpicker();

            @if($bookingDetails['widgetSource']=="hourly")
                var data = {
                    "_token": "{{ csrf_token() }}",
                    "date": $('#date').val(),
                    "num_attendees": "{{ $bookingDetails['num_attendees'] }}",
                    "time_from": "{{ $bookingDetails['date'] }} {{ $bookingDetails['time_from'] }}:00",
                    "time_to": "{{ $bookingDetails['date'] }} {{ $bookingDetails['time_to'] }}:00"
                };
                
                function validateBooking(data) {
                    $.ajax({
                        url: '/api/booking/hourly/'+'{{ $space->id }}',
                        type: 'post',
                        dataType: 'json',
                        data: data,
                        success: function (data) {
                            if (data.error) {

                            }
                            else {
                                $('.alert-danger').each(function() {
                                    $(this).html('').hide();
                                });
                                $('[id=rateDay]').each(function() {
                                    $(this).html('');
                                });
                                $('[id=rateAfterHours]').each(function() {
                                    $(this).html('');
                                });

                                if (data.hourlyTotalCost!="0.00") {
                                    $('[id=rateHour]').each(function() {
                                        $(this).html('<span id="hours">'+data.totalHours+'</span> '+(data.totalHours=="1" ? "Hour" : "Hours")+'<span class="pull-right">$'+data.hourlyTotalCost+'</span>');
                                    });
                                }
                                else if (data.dayTotalCost!="0.00") {
                                    $('[id=rateHour]').each(function() {
                                        $(this).html('<span id="hours">'+data.totalHours+'</span> '+(data.totalHours=="1" ? "Hour" : "Hours")+'<span class="pull-right">$'+data.dayTotalCost+'</span>');
                                    });
                                } 
                                else if (data.halfDayTotalCost!="0.00") {
                                    console.log(data);
                                    $('[id=rateHour]').each(function() {
                                        $(this).html('<span id="hours">'+data.totalHours+'</span> '+(data.totalHours=="1" ? "Hour" : "Hours")+'<span class="pull-right">$'+data.halfDayTotalCost+'</span>');
                                    });
                                }

                                @if ($space->is_available_afterhours)
                                    if (data.afterHoursTotalCost!="0.00") {
                                        $('[id=rateAfterHours]').each(function() {
                                            $(this).html('<span id="hours">'+data.totalAfterHoursHours+'</span> '+(data.totalAfterHoursHours=="1" ? "After Hour" : "After Hours")+'<span class="pull-right">$'+data.afterHoursTotalCost+'</span>');
                                        });
                                    }
                                @endif

                                $('[id=payment_total]').each(function() {
                                    $(this).html('$'+data.totalCost);
                                });
                            }
                        },
                        error: function(data){
                            var error = JSON.parse(data.responseText);
                            $('.alert-danger').html(error.message).show();
                        }
                    });
                }
                
                validateBooking(data);
                
            @else
                var data = {
                    "_token": "{{ csrf_token() }}",
                    "num_attendees": "{{ $bookingDetails['num_attendees'] }}",
                    "date_from": "{{ $bookingDetails['date_from'] }}",
                    "date_to": "{{ $bookingDetails['date_to'] }}"
                };
                
                function validateBooking(data) {
                
                    $.ajax({
                        url: '/api/booking/daily/'+'{{ $space->id }}',
                        type: 'post',
                        dataType: 'json',
                        data: data,
                        success: function (data) {
                            if (data.error) {

                            }
                            else {
                                $('.alert-danger').each(function() {
                                    $(this).html('').hide();
                                });
                                $('[id=rateDay]').each(function() {
                                    $(this).html('');
                                });
                                $('[id=rateMonth]').each(function() {
                                    $(this).html('');
                                });
                                
                                if (data.dayTotalCost!="0.00") {
                                    $('[id=rateDay]').each(function() {
                                        $(this).html('<span id="days">'+data.totalDays+'</span> '+(data.totalDays=="1" ? "Day" : "Days")+'<span id="rateDay"><span class="pull-right">$'+data.dayTotalCost+'</span></span>');
                                    });
                                } 

                                if (data.monthTotalCost!="0.00") {
                                    $('[id=rateMonth]').each(function() {
                                        $(this).html('<span id="months">'+data.totalMonths+'</span> '+(data.totalMonths=="1" ? "Month" : "Months")+'<span id="rateMonth"><span class="pull-right">$'+data.monthTotalCost+'</span></span>');
                                    });
                                }
                                $('[id=payment_total]').each(function() {
                                    $(this).html('$'+data.totalCost);
                                });
                            }
                        },
                        error: function(data){
                            var error = JSON.parse(data.responseText);
                            $('.alert-danger').html(error.message).show();
                        }
                    });
                }
                
                validateBooking(data);
            @endif
            
            $("#num_attendees").on("change", function () {
                var data = null;
                
                @if($bookingDetails['widgetSource']=="hourly")
                    data = {
                        "_token": "{{ csrf_token() }}",
                        "date": $('#date').val(),
                        "num_attendees": $(this).val(),
                        "time_from": "{{ $bookingDetails['date'] }} {{ $bookingDetails['time_from'] }}:00",
                        "time_to": "{{ $bookingDetails['date'] }} {{ $bookingDetails['time_to'] }}:00"
                    };
                @else
                    data = {
                        "_token": "{{ csrf_token() }}",
                        "num_attendees": $(this).val(),
                        "date_from": "{{ $bookingDetails['date_from'] }}",
                        "date_to": "{{ $bookingDetails['date_to'] }}"
                    };
                @endif
                
                $("[id=booking-summary-attendees]").val($(this).val());
                console.log($(this).val());
                validateBooking(data);
            });
            
            
            if ($('#space_configuration > option').length !=1) {
                $("#space_configuration").prepend("<option value='' selected='selected'>Select space setup</option>");
            }
            storage = Storages.sessionStorage;
            var payment_details = storage.get('payment_details');
            
            function setStorage() {
                storage.set('payment_details', { 
                    num_attendees:  $('#num_attendees').val(),
                    space_configuration:  $('select[name=space_configuration]').val(),
                    event_title:  $('#event_title').val(),
                    event_description:  $('#event_description').val(),
                    agree_rules:  $('#agree_rules').val()
                });
                $('.selectpicker').selectpicker('refresh');
            }
            
            setStorage();

            if (payment_details) {
                if (payment_details.space_configuration!="") {
                    $("#space_configuration option[value='']").remove();
                }
                $('#num_attendees').val(payment_details.num_attendees);
                $('select[name=space_configuration]').val(payment_details.space_configuration);
                $('#event_title').val(payment_details.event_title);
                $('#event_description').val(payment_details.event_description);
                $('#agree_rules').prop('checked', payment_details.agree_rules);
            }
            
            $("#num_attendees, #space_configuration, #event_title, #event_description, #agree_rules").on("change", function () {
                setStorage();
            });
            
            if ($('#space_configuration > option').length == 1) {
                $('#space_configuration option:visible').attr('selected', true);
            }
            
            $('.selectpicker').selectpicker('refresh');
            
            $('#info_box_booking_details').on('click',function(e){
                if (e.target.id === 'info_box_content_booking_details' || e.target.id === 'button_booking_next') {

                    e.preventDefault();
                    $("#booking_details").show();
                    $('#billing_details').hide();
                    $('#payment_details').hide();
                    if (e.target.id === 'button_booking_next') {
                        $("#booking_details").hide();
                        $('#billing_details').show();
                        $('#info_box_booking_details').removeClass('info-box-active').addClass('info-box-inactive');
                        $('#info_box_billing_details').removeClass('info-box-inactive').addClass('info-box-active');
                    }
                    else {
                        $('#info_box_booking_details').removeClass('info-box-inactive').addClass('info-box-active');
                        $('#info_box_billing_details').removeClass('info-box-active').addClass('info-box-inactive');
                    }
                }
            });
            
            $('#info_box_billing_details').on('click',function(e){
                if (e.target.id === 'info_box_content_billing_details' || e.target.id === 'button_billing_next') {
                    e.preventDefault();
                    $('#billing_details').show();
                    $("#booking_details").hide();
                    $('#payment_details').hide();
                    $('#booking_summary').hide();
                    if (e.target.id === 'button_billing_next') {
                        $('#billing_details').hide();
                        $('#payment_details').show();
                        $('#booking_summary').show();
                        $('#info_box_billing_details').removeClass('info-box-active').addClass('info-box-inactive');
                        $('#info_box_payment_details').removeClass('info-box-inactive').addClass('info-box-active');
                    }
                    else {
                        $('#info_box_billing_details').removeClass('info-box-inactive').addClass('info-box-active');
                        $('#info_box_payment_details').removeClass('info-box-active').addClass('info-box-inactive');
                        $('#info_box_booking_details').removeClass('info-box-active').addClass('info-box-inactive');
                    }
                }
            });
            
            if(window.location.hash) {
                @if(Auth::check())
                    $("#booking_details").toggle();
                    $('#billing_details').toggle();
                    $('#info_box_booking_details').removeClass('info-box-active').addClass('info-box-inactive');
                    $('#info_box_billing_details').removeClass('info-box-inactive').addClass('info-box-active');
                @endif
            }
            
            var $form = $('#payment-form');
            var $modal = $('#payment-modal');
            var $paymenterrors = $('#payment-errors');
            var dangerContainer = $modal.find('.modal-body .alert-danger');
            var successContainer = $modal.find('.modal-body .success-message');
            var headerContainer = $modal.find('.modal-header');
            var footerContainer = $modal.find('.modal-footer');
            var submitButton = $form.find(":submit");
            var buttonConfirmBooking = 'Confirm Booking';
            var buttonSuccessfulBooking = 'Successful Booking';
            var buttonProcessing = 'Processing...';
            var htmlModalHeaderProcessing = '<i class="fa fa-circle-o-notch fa-spin fa-1x fa-fw margin-bottom"></i><p class="tt-upper">Processing Payment</p>';
            var htmlModalContainerProcessing = 'Please do not close this browser.';
            var htmlModalHeaderError = '<i class="fa fa-exclamation-circle" aria-hidden="true"></i><p class="tt-upper">Transaction Error</p>';
            var htmlModalFooter = '<a class=" text-center" href="#" data-dismiss="modal"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i> Close and Try Again</a>';
            var htmlModalAlert = 'Invalid Transaction. Please contact support.';
            var htmlModalSuccessHeader = '<i class="fa fa-check" aria-hidden="true"></i><p class="tt-upper">Payment Successful</p>';
            var htmlModalSuccessContainer = '<p class="m-top-20">Congratulations,</p><p>Your booking has been received and payment was successful.</p><p class="m-bot-50">You will receive a confirmation email shortly and can review your booking at any time via "My Bookings" link.</p>';
            var htmlModalSuccessFooter = '<a class=" text-center" href="'+"{{ route('my.bookings') }}"+'">View Bookings <i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></a>';
            var textCreditCardMessage = "Your credit card will be charged when you confirm this booking. We encourage you to contact the Host if you have any questions before booking.";
            
            $form.append($('<input type="hidden" name="widgetSource">').val("{{ $bookingDetails['widgetSource'] }}"));
            
            
            function submitBooking(action, method, data) {
                $.ajax({
                    url: action || window.location.pathname,
                    type: method,
                    data: data,
                    success: function (data) {
                        if (data.status == "success") {
                            submitButton.attr({disabled: true});
                            successContainer.show();
                            headerContainer.html(htmlModalSuccessHeader);
                            successContainer.html(htmlModalSuccessContainer);
                            footerContainer.html(htmlModalSuccessFooter);
                            dangerContainer.text('').hide();
                            submitButton.val(buttonSuccessfulBooking);
                            $modal.modal({backdrop: 'static', keyboard: false});
                        }
                        else {
                            headerContainer.html(htmlModalHeaderError);
                            if (typeof data.message == 'string') {
                                dangerContainer.text(data.message).show();
                            } 
                            else {
                                dangerContainer.text('').show();
                                $.each(data.message, function (index, value) {
                                    dangerContainer.append(value + "<br />");
                                });
                            }
                            successContainer.html('').hide();
                            footerContainer.html(htmlModalFooter);
                            submitButton.attr({disabled: false});
                            submitButton.val(buttonConfirmBooking);
                        }
                    },
                    error: function (data) {
                        if (data.responseText) {
                            var error = JSON.parse(data.responseText);
                            dangerContainer.html(error.message).show();
                        }
                        headerContainer.html(htmlModalHeaderError);
                        successContainer.html('').hide();
                        footerContainer.html(htmlModalFooter);
                        submitButton.attr({disabled: false});
                        submitButton.val(buttonConfirmBooking);
                    }
                });
            }
            
            var stripePayment = function() {
                Stripe.setPublishableKey('{{ env("PAYMENT_TOKEN_KEY") }}');
                
                //add credit card required fields
                $("#payment_type_creditcard input").prop('required',true);

                //remove invoice required fields
                $("#payment_type_invoice input").prop('required',false);

                function stripeResponseHandler(status, response) {
                    
                    dangerContainer.text('').hide();
                    successContainer.show();
                    headerContainer.html(htmlModalHeaderProcessing);
                    successContainer.html(htmlModalContainerProcessing);
                    $modal.modal({backdrop: 'static', keyboard: false});
                    
                    if (response.error) { // Problem!

                        // Show the errors on the form:
                        $form.find('#payment_details').focus();
                        $form.find($paymenterrors).text(response.error.message).show();
                        $form.find('.submit').prop('disabled', false); // Re-enable submission
                        $modal.modal({backdrop: 'static', keyboard: false});
                        successContainer.html('').hide;
                        dangerContainer.text(response.error.message).show();
                        headerContainer.html(htmlModalHeaderError);
                        footerContainer.html(htmlModalFooter);
                        submitButton.val(buttonConfirmBooking);
                    } 
                    else { // Token was created!

                        // Get the token ID:
                        var token = response.id;

                        // Insert the token ID into the form so it gets submitted to the server:
                        $form.append($('<input type="hidden" name="stripeToken">').val(token));

                        {{-- Submit the form: Server Side  Debug --}}
                        //$form.get(0).submit();
                        
                        {{-- Submit the form: Ajax --}}
                        submitButton.attr({disabled: true});
                        submitBooking($form.attr('action'), $form.attr('method'), $form.serialize());
                    }
                };                  

                $form.validator().submit(function(e) {
                    if (e.isDefaultPrevented()) {
                        $("#booking_details").show();
                    }
                    else {
                        // Disable the submit button to prevent repeated clicks:
                        $form.find('.submit').prop('disabled', true);
                        submitButton.val(buttonProcessing);
                        
                        // Request a token from Stripe:
                        try {
                            Stripe.card.createToken($form, stripeResponseHandler);
                        }
                        catch(err) {
                            $modal.modal('show');
                            dangerContainer.text('').show();
                            dangerContainer.text(htmlModalAlert).show();
                            headerContainer.html(htmlModalHeaderError);
                            footerContainer.html(htmlModalFooter);
                            submitButton.val(buttonConfirmBooking);
                        }

                        // Prevent the form from being submitted:
                        return false;
                    }
                });
            };
            
            var invoicePayment = function() {
                $($paymenterrors).text("").hide();

                //remove credit card required fields
                $("#payment_type_creditcard input").prop('required',false);

                //add invoice required fields
                $("#payment_type_invoice input").prop('required',true);

                //remove existing credit card message
                $("#credit_card_message").text("");

                // Submit the form:
                $form.validator().submit(function (e) {
                    if (e.isDefaultPrevented()) {
                        $("#booking_details").show();
                    }
                    else {
                        dangerContainer.text('').hide();
                        successContainer.show();
                        headerContainer.html(htmlModalHeaderProcessing);
                        successContainer.html(htmlModalContainerProcessing);
                        $modal.modal({backdrop: 'static', keyboard: false});
                        
                        submitBooking($form.attr('action'), $form.attr('method'), $form.serialize());
                        return false;
                    }
                });
            };
            
            $modal.on('hidden.bs.modal', function () {
                $($paymenterrors).hide();
            });

            
            @if ($space->payment_creditcard_allowed && $space->payment_invoice_allowed)
                $('#select_payment_type').show();
                $('#payment_type').attr('required', 'required');
            @endif
            
            @if (!$space->payment_creditcard_allowed && $space->payment_invoice_allowed)
                $('#payment_type_invoice').show();
                $('#payment_type_creditcard').remove();
                $("select[name=payment_type]").val('INVOICE').bind('load change', invoicePayment).triggerHandler('change');
            @elseif ($space->payment_creditcard_allowed && !$space->payment_invoice_allowed)
                $('#payment_type_creditcard').show();
                $("select[name=payment_type]").val('CREDITCARD').bind('load change', stripePayment).triggerHandler('change');
            @endif
            
            $('#payment_type').selectpicker('refresh');
            
            $('select[name=payment_type]').change(function() {
                if ($(this).val()=="CREDITCARD") {
                    $('#payment_type_invoice').hide();
                    $('#payment_type_creditcard').show();
                    stripePayment();
                }
                else if ($(this).val()=="INVOICE") {
                    $('#payment_type_invoice').show();
                    $('#payment_type_creditcard').hide();
                    invoicePayment();
                }
                else {
                    $('#payment_type_creditcard').hide();
                    $('#payment_type_invoice').hide();
                }
            });
            
            @if(!Auth::check())
                var lock_inline = new Auth0Lock('{{ env("AUTH0_CLIENT_ID") }}', '{{ env("AUTH0_DOMAIN") }}', {
                    container: 'auth0_loginForm',
                    theme: {
                        logo: "",
                        primaryColor: '#19ace2',
                        labeledSubmitButton: false
                    },
                    auth: {
                        redirectUrl: '{{ route("auth0.callback") }}#billing_details',
                        responseType: 'code',
                        params: { 
                          scope: 'openid email' 
                        }
                    },
                    languageDictionary: {
                        loginSubmitLabel: "Log In",
                        loginLabel: "Log In"
                    },
                    rememberLastLogin: false,
                    additionalSignUpFields: [
                        {
                            name: "mobile_number",
                            placeholder: "your mobile number",
                            icon: '{{ asset("images/icons/login_mobile.png") }}',
                        },
                        {
                            name: "first_name",
                            placeholder: "your first name"
                        },
                        {
                            name: "last_name",
                            placeholder: "your last name"
                        }
                    ]
                });
                lock_inline.show();
            @endif
            
            //Carousel
            $(".carousel-inner div").first().addClass("active");
        });
    </script>
    <style>
        
        #billing_details .auth0-lock-header {
            display: none;
        }
        #billing_details .auth0-lock.auth0-lock .auth0-lock-widget {
            width: 100%;
        }
        #billing_details .auth0-lock.auth0-lock.auth0-lock-opened-in-frame {
            width: 100%;
        }
        #billing_details .auth0-lock.auth0-lock .auth0-lock-submit {
            border-radius: 0;
            background-color: rgb(20, 98, 146) !important;
            border-radius: 0;
            height: 52px;
            padding: 0;
            margin-top: 10px;
        }
        #billing_details .auth0-lock.auth0-lock .auth0-lock-content {
            padding: 0; 
        }
        #billing_details .auth0-lock.auth0-lock .auth0-lock-form p {
            text-align: left; 
        }
        #billing_details .auth0-lock.auth0-lock .auth0-global-message.auth0-global-message-error {
            margin-bottom: 10px;
        }
        #billing_details .auth0-lock.auth0-lock .auth0-global-message.auth0-global-message-success {
            background: #7ed321;
            margin-bottom: 10px;
        }
    </style>
@stop

@section('content')
    @include('_partials.hero_carousel')
    
    <div class="container">
        {!! Form::open(['route' => ['payment.post', 'building_private_slug' => $space->building->private_slug, 'space_private_slug' => $space->private_slug], 'method' => 'post', 'data-toggle' => 'validator', 'role' => 'form', 'id' => 'payment-form']) !!}
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="location-details">
                            <span class="text-large m-left-10">Your Booking</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-11 m-top-50">
                            <p><span class="text-large">You are booking <span class="text-blue">{{ $space->room_name }}</span> at <span class="text-blue">{{ $space->building->name }}</span></span></p>
                            <p>Wrong space? <a href="{{ route('buildings.show', ['idOrSlug' => $space->building->private_slug ]) }}">Click here to go back</a></p>
                            <div class="alert alert-danger alert-light collapse"></div>
                            <div class="row">
                                <div class="col-xs-12 m-top-20">
                                    <div id="info_box_booking_details" class="info-box-active">
                                        <div id="inner">
                                            <div class="info-box">
                                                <span class="info-box-icon bg-light-blue">1</span>
                                                <div class="info-box-content" id="info_box_content_booking_details">
                                                      <span class="info-box-text text-blue text-large">Booking Details</span>
                                                </div>
                                            </div>
                                            <div id="booking_details">
                                                <div class="row m-top-20">
                                                    <div class="col-md-6">
                                                        <div class="form-group has-feedback">
                                                            {!! Form::label('num_attendees', 'Number of people') !!} 
                                                            {!! Form::number('num_attendees', $bookingDetails['num_attendees'], ['class' => 'form-control', 'id' => 'num_attendees', 'min' => '1', 'max' => $getMaxAttendees, 'required', 'data-error' => 'Number is invalid.']) !!}
                                                            <div class="help-block with-errors"></div>
                                                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row m-top-20">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            {!! Form::label('space_configuration', 'Space setup') !!} 
                                                            <select class="form-control selectpicker" id="space_configuration" name="space_configuration" required data-error ="Please select Room Setup.">
                                                                @foreach($space->spaceconfigurations as $spaceconfiguration)
                                                                    <option value="{{ $spaceconfiguration['id'] }}">{{ $spaceconfiguration['name'] }}</option>
                                                                @endforeach
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row m-top-20">
                                                    <div class="col-md-6">
                                                        <div class="form-group has-feedback">
                                                            {!! Form::label('event_title', 'Event title') !!} 
                                                            {!! Form::text('event_title', null, ['class' => 'form-control', 'id' => 'event_title', 'required', 'data-error' => 'Event Title is required.']) !!}
                                                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row m-top-20">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            {!! Form::label('event_description', 'Provide the host with a description (optional)') !!} {{--<i class="fa fa-question-circle text-blue" aria-hidden="true"></i>--}}
                                                            {!! Form::textarea('event_description', null, ['class' => 'form-control', 'id' => 'event_description', 'rows' => '6']) !!}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row m-top-20">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <div class="checkbox">
                                                                <label for="agree_rules" class="form-horizontal">
                                                                    {!! Form::checkbox('agree_rules', null, false, ['id' => 'agree_rules', 'class' => 'form-horizontal', 'required']) !!}
                                                                    I agree to the booking terms and conditions for this space. <a href="#" type="button" class="" data-toggle="modal" data-target="#termsModal">View terms and conditions</a>.
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row m-top-20">
                                                    <div class="col-md-3 pull-right">
                                                        <button class="btn btn-dark-blue" id="button_booking_next">Next</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="info_box_billing_details" class="info-box-inactive m-top-20 m-bot-20">
                                        <div class="info-box">
                                            <span class="info-box-icon bg-light-blue">2</span>
                                            <div class="info-box-content" id="info_box_content_billing_details">
                                                  <span class="info-box-text text-blue text-large">Billing Details</span>
                                            </div>
                                        </div>
                                        <div id="billing_details" class="collapse">
                                            <a name="billing_details"></a>
                                            <div class="row m-top-20">
                                                <div class="col-md-12">
                                                        @if (Auth::check())
                                                            <p><strong>Account Details</strong></p>
                                                            <p>{{Auth::user()->first_name }} {{Auth::user()->last_name }}</p>
                                                            <p>{{Auth::user()->email }}</p>
                                                            <hr />
                                                            {!! Form::label('sent_to_email', 'I would like to send confirmation of this booking to the following people.') !!} 
                                                            {!! Form::textarea('sent_to_email', null, ['placeholder' => 'Provide email addresses separated by commas', 'class' => 'form-control', 'id' => 'sent_to_email', 'rows' => '6']) !!}
                                                        @else
                                                            <p>To book a space you need a login which is separate to your portal login.</p>
                                                            <div class="col-md-8"><div class="row"><div id="auth0_loginForm"></div></div></div>
                                                        @endif
                                                </div>
                                            </div>
                                            @if (Auth::check())
                                                <div class="row m-top-20">
                                                    <div class="col-md-3 pull-right">
                                                        <button class="btn btn-dark-blue" id="button_billing_next">Next</button>
                                                    </div>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hidden-xs hidden-sm col-md-3">
                    @yield('message-host-cta')
                </div>
            </div>
            <div class="row">
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-11">
                            <div class="row">
                                <div class="col-xs-12">
                                    <div id="info_box_payment_details" class="info-box-inactive">
                                        <div class="info-box">
                                            <span class="info-box-icon bg-light-blue">3</span>
                                            <div class="info-box-content" id="info_box_content_payment_details">
                                                  <span class="info-box-text text-blue text-large">Payment Details</span>
                                            </div>
                                        </div>
                                        @if (Auth::check())
                                            <div id="payment_details" class="collapse">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="hidden-md hidden-lg">
                                                            @include('_partials.booking_summary_section')
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="alert alert-danger collapse" id="payment-errors"><span class="payment-errors"></span></div>

                                                
                                                <div class="row m-top-20 collapse" id="select_payment_type">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            {!! Form::label('payment_type', 'Payment type') !!} 
                                                            {!! Form::select('payment_type', [
                                                                '' => 'Please Select', 
                                                                'CREDITCARD' => 'Credit Card', 
                                                                'INVOICE' => 'Invoice'
                                                            ]
                                                            , null, ['class' => 'form-control selectpicker payment_type', 'id' => 'payment_type', 'data-error' => 'Please select payment type.']) !!}
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                

                                                <div>
                                                    <div class="collapse" id="payment_type_invoice">
                                                        <div class="row m-top-20">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <div class="checkbox">
                                                                        <label for="agree_invoice_authority" class="form-horizontal">
                                                                            {!! Form::checkbox('agree_invoice_authority', null, false, ['id' => 'agree_invoice_authority', 'class' => 'form-horizontal']) !!} 
                                                                            I have the authority to book spaces for the total amount of this booking for my organisation. I will be responsible for ensuring that the invoice for this room booking is paid on time and in full.
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row m-top-20">
                                                            <div class="col-md-6">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('company_name', 'Company Name') !!} 
                                                                    {!! Form::text('company_name', null, ['id' => 'company_name', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Company Name.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row m-top-20">
                                                            <div class="col-md-6">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('company_address', 'Address') !!} 
                                                                    {!! Form::text('company_address', null, ['id' => 'company_address', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Company Address.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row m-top-20">
                                                            <div class="col-md-3">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('company_city', 'City') !!} 
                                                                    {!! Form::text('company_city', null, ['id' => 'address', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter City.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('company_postcode', 'Postcode') !!} 
                                                                    {!! Form::number('company_postcode', null, ['id' => 'company_postcode', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Postcode.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row m-top-20">
                                                            <div class="col-md-3">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('company_state', 'State') !!} 
                                                                    {!! Form::text('company_state', null, ['id' => 'company_state', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter State.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('company_country', 'Country') !!} 
                                                                    {!! Form::text('company_country', null, ['id' => 'company_country', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Country.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row m-top-20">
                                                            <div class="col-md-6">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('contact_name', 'Person responsible for paying invoice (if different to person logged in') !!} 
                                                                    {!! Form::text('contact_name', Auth::user()->first_name.' '.Auth::user()->last_name, ['id' => 'contact_name', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Name.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback m-top-20" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row m-top-20">
                                                            <div class="col-md-6">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('purchase_order', 'Purchase Order') !!} 
                                                                    {!! Form::text('purchase_order', null, ['id' => 'purchase_order', 'class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter Purchase Order.']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="collapse" id="payment_type_creditcard">
                                                        <div class="row m-top-20">
                                                            <div class="col-md-6">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('card_number', 'Card number') !!} 
                                                                    {!! Form::number(null, null, ['id' => 'number', 'class' => 'form-control', 'placeholder' => '', 'data-stripe' => 'number', 'data-error' => 'Please enter valid card number']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row m-top-20">
                                                            <div class="col-md-6">
                                                                <div class="form-group has-feedback">
                                                                    {!! Form::label('name', 'Card Holder') !!}
                                                                    {!! Form::text('name', null, ['class' => 'form-control', 'placeholder' => '', 'data-error' => 'Please enter exact Name on Card']) !!}
                                                                    <div class="help-block with-errors"></div>
                                                                    <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row m-top-20">
                                                            <div class="col-md-6">
                                                                <div class="row">
                                                                    <div class="col-md-8">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    {!! Form::label('exp_month', 'Expiry Month') !!} 
                                                                                    {!!
                                                                                        Form::select(
                                                                                            null,
                                                                                            array_reduce(
                                                                                                range(1,12),
                                                                                                function($result, $item){
                                                                                                    $result[sprintf("%02d", $item)] = sprintf("%02d", $item);
                                                                                                    return $result;
                                                                                                }
                                                                                            ),
                                                                                            null,
                                                                                            ['class' => 'form-control selectpicker', 'id' => 'exp_month', 'data-stripe' => 'exp_month']
                                                                                        )
                                                                                    !!}
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                    {!! Form::label('exp_year', 'Expiry Year') !!} 
                                                                                    {!!
                                                                                        Form::select(
                                                                                            null,
                                                                                            array_reduce(
                                                                                                range(intval(date('Y', strtotime('+0 years'))), intval(date('Y', strtotime('+10 years'))), -1),
                                                                                                function($result, $item) {
                                                                                                    $result[$item] = $item;
                                                                                                    return $result;
                                                                                                }
                                                                                            ),
                                                                                            null,
                                                                                            ['class' => 'form-control selectpicker', 'id' => 'exp_year', 'data-stripe' => 'exp_year']
                                                                                        )
                                                                                    !!}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group has-feedback">
                                                                            {!! Form::label('cvc', 'Security code') !!}
                                                                            {!! Form::number(null, null, ['id' => 'cvc', 'class' => 'form-control', 'placeholder' => 'CVV', 'data-stripe' => 'cvc', 'data-error' => 'Please enter valid security code', 'min' => '0']) !!}
                                                                            <div class="help-block with-errors"></div>
                                                                            <span class="glyphicon form-control-feedback" aria-hidden="true"></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        

                                                    </div>

                                                    <div class="row m-top-20 m-bot-20">
                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-6 m-bot-20"></div>
                                                                <div class="col-md-6">
                                                                    {!! Form::submit('Confirm Booking', ["class" => "btn btn-blue form-control", "id" => "confirm-booking"]) !!}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 hidden-sm hidden-xs collapse" id="booking_summary">
                    <div class="row">
                        @include('_partials.booking_summary_section')
                    </div>
                </div>
            </div>
        {!! Form::close() !!}
    </div>
    
    @if($space->terms)
        <div class="modal fade" id="termsModal" tabindex="-1" role="dialog" aria-labelledby="termsModalLabel">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="termsModalLabel">Terms and Conditions</h4>
                    </div>
                    <div class="modal-body">
                        <p class="m-top-20">{!! $space->terms !!}</p>
                    </div>
                </div>
            </div>
        </div>
    @endif
    
    <div class="modal fade" id="payment-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    
                </div>
                <div class="modal-body">
                    <div class="m-top-20 alert alert-danger alert-light collapse"></div>
                    <div class="m-top-20 success-message collapse"></div>
                </div>
                <div class="modal-footer"></div>
            </div>
        </div>
    </div>
    
    @yield('message-host-modal')

@stop
