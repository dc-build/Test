@extends('layout')

@section('title')
    Home
@stop

@section('custom-scripts')
    <script>
        $(function() {
            $(".selectpicker").selectpicker();
        });
    </script>
@stop

@section('content')
    <div class="page-hero-wrapper bg-home">
        <div class="page-hero-inner">
            <div class="cover-container">
                <div class="cover">
                    <p>Register</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container registration-form">
        <div class="row m-top-20 m-bot-50">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                {!! Form::open(array('url' => '/register/'. $user->invitation_code, 'id' => 'register_form')) !!}
                    <h2>Complete your registration by entering your password below</h2>
                    @if(session()->has('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                            <br />
                        </div>
                    @endif
                    <div class="m-top-20">
                        {!! Form::label('signup-email', 'Email Address') !!} 
                        {!! Form::text('email', $user->email, ['class' => 'form-control', 'placeholder' => '', 'id' => 'signup-email', 'disabled', 'readonly']) !!}
                    </div>
                    <div class="m-top-10  {{ ($errors->has('password')) ? 'has-error' : '' }}">
                        {!! Form::label('signup-password', 'Password') !!} 
                        {!! Form::password('password', null, ['class' => 'form-control', 'placeholder' => '', 'id' => 'signup-password']) !!}
                        <span class='label label-danger text-center'>{{ ($errors->has('password') ? $errors->first('password') : '') }}</span>
                    </div>
                    <div class="m-top-10  {{ ($errors->has('first_name')) ? 'has-error' : '' }}">
                        {!! Form::label('first_name', 'First Name') !!} 
                        {!! Form::text('first_name', $user->first_name, ['class' => 'form-control', 'placeholder' => '', 'id' => 'first_name']) !!}
                        <span class='label label-danger text-center'>{{ ($errors->has('first_name') ? $errors->first('first_name') : '') }}</span>
                    </div>
                    <div class="m-top-10  {{ ($errors->has('last_name')) ? 'has-error' : '' }}">
                        {!! Form::label('last_name', 'Last Name') !!} 
                        {!! Form::text('last_name', $user->last_name, ['class' => 'form-control', 'placeholder' => '', 'id' => 'last_name']) !!}
                        <span class='label label-danger text-center'>{{ ($errors->has('last_name') ? $errors->first('last_name') : '') }}</span>
                    </div>
                    <div class="m-top-10  {{ ($errors->has('mobile_number')) ? 'has-error' : '' }}">
                        {!! Form::label('mobile_number', 'Mobile Number') !!} 
                        {!! Form::text('mobile_number', $user->mobile_number, ['class' => 'form-control', 'placeholder' => '', 'id' => 'mobile_number']) !!}
                        <span class='label label-danger text-center'>{{ ($errors->has('mobile_number') ? $errors->first('mobile_number') : '') }}</span>
                    </div>
                    <div class="m-top-20">
                        {!! Form::hidden('isActive', $user->isActive) !!}
                        {!! Form::submit('Register', ['class' => 'btn btn-blue form-control']) !!} 
                    </div>
                {!! Form::close() !!}
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>

    
@stop
